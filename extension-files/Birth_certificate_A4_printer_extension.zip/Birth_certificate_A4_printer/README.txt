Birth Registration A4 Printer - v1.3.0

This extension adds a Print Certificate button to the Chrome extension popup.

Images included inside the extension:
- header_logo.png = small header logo shown at the top center
- watermark.png = separate large center watermark

The existing A4 layout, QR, barcode, Bangla/English extraction, Date of Birth in Words, and alignment are unchanged.

Install:
1. Extract the ZIP.
2. Open chrome://extensions/
3. Enable Developer mode.
4. Click Load unpacked.
5. Select this folder.
6. Open the birth registration result page.
7. Click the extension and press Print Certificate.

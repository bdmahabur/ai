const btn = document.getElementById("printBtn");
const status = document.getElementById("status");

btn.addEventListener("click", async () => {
  btn.disabled = true;
  status.textContent = "Preparing print...";

  try {
    const [tab] = await chrome.tabs.query({
      active: true,
      currentWindow: true
    });

    if (!tab || !tab.id) {
      throw new Error("No active tab found.");
    }

    const watermarkUrl = chrome.runtime.getURL("watermark.png");
    const headerLogoUrl = chrome.runtime.getURL("header_logo.png");

    const watermarkDataUrl = await fetch(watermarkUrl)
      .then(r => r.blob())
      .then(blob => new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsDataURL(blob);
      }));

    const headerLogoDataUrl = await fetch(headerLogoUrl)
      .then(r => r.blob())
      .then(blob => new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsDataURL(blob);
      }));

    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: "MAIN",
      func: runBirthRegistrationPrinter,
      args: [watermarkDataUrl, headerLogoDataUrl]
    });

    status.textContent = "Print window prepared.";
    setTimeout(() => window.close(), 500);

  } catch (error) {
    console.error(error);
    status.textContent =
      "Could not run here. Open the birth-registration page first.";
    btn.disabled = false;
  }
});


function runBirthRegistrationPrinter(watermarkDataUrl, headerLogoDataUrl) {
  (async () => {

    // =========================================================
    // REMOVE PREVIOUS VERSION
    // =========================================================

    document.getElementById("BR_A4_PRINT")?.remove();
    document.getElementById("BR_A4_STYLE")?.remove();


    // =========================================================
    // HELPERS
    // =========================================================

    const clean = s =>
      (s || "")
        .replace(/\s+/g, " ")
        .trim();

    const rows = [...document.querySelectorAll("tr")];

    function cells(row) {
      return [...(row?.querySelectorAll("th,td") || [])]
        .map(x =>
          clean(
            x.innerText ||
            x.textContent ||
            ""
          )
        )
        .filter(Boolean);
    }

    function findRow(text) {
      return rows.find(r =>
        clean(r.innerText || r.textContent)
          .toUpperCase()
          .includes(text.toUpperCase())
      );
    }


    // =========================================================
    // REGISTRATION INFORMATION
    // =========================================================

    let registrationDate = "";
    let registrationOffice = "";
    let issuanceDate = "";

    let birthDate = "";
    let registrationNumber = "";
    let sex = "";

    const regHeader = findRow("REGISTRATION DATE");

    if (regHeader) {
      const v = cells(regHeader.nextElementSibling);

      if (v.length >= 3) {
        registrationDate = v[0];
        registrationOffice = v[1];
        issuanceDate = v[2];
      }
    }

    const birthHeader = findRow("DATE OF BIRTH");

    if (birthHeader) {
      const v = cells(birthHeader.nextElementSibling);

      if (v.length >= 3) {
        birthDate = v[0];
        registrationNumber = v[1];
        sex = v[2];
      }
    }


    // =========================================================
    // DATE OF BIRTH IN WORDS
    // =========================================================

    function numberToWords(num) {

      const ones = [
        "",
        "One",
        "Two",
        "Three",
        "Four",
        "Five",
        "Six",
        "Seven",
        "Eight",
        "Nine",
        "Ten",
        "Eleven",
        "Twelve",
        "Thirteen",
        "Fourteen",
        "Fifteen",
        "Sixteen",
        "Seventeen",
        "Eighteen",
        "Nineteen"
      ];

      const tens = [
        "",
        "",
        "Twenty",
        "Thirty",
        "Forty",
        "Fifty",
        "Sixty",
        "Seventy",
        "Eighty",
        "Ninety"
      ];

      num = parseInt(num, 10);

      if (isNaN(num)) return "";

      if (num < 20) return ones[num];

      if (num < 100) {
        return tens[Math.floor(num / 10)] +
          (num % 10 ? " " + ones[num % 10] : "");
      }

      if (num < 1000) {
        return ones[Math.floor(num / 100)] +
          " Hundred" +
          (num % 100 ? " " + numberToWords(num % 100) : "");
      }

      if (num < 1000000) {
        return numberToWords(Math.floor(num / 1000)) +
          " Thousand" +
          (num % 1000 ? " " + numberToWords(num % 1000) : "");
      }

      return "";
    }


    // =========================================================
    // ORDINAL DAY
    // =========================================================

    function ordinalWord(num) {

      const ordinal = {
        1: "First",
        2: "Second",
        3: "Third",
        4: "Fourth",
        5: "Fifth",
        6: "Sixth",
        7: "Seventh",
        8: "Eighth",
        9: "Ninth",
        10: "Tenth",
        11: "Eleventh",
        12: "Twelfth",
        13: "Thirteenth",
        14: "Fourteenth",
        15: "Fifteenth",
        16: "Sixteenth",
        17: "Seventeenth",
        18: "Eighteenth",
        19: "Nineteenth",
        20: "Twentieth",
        21: "Twenty First",
        22: "Twenty Second",
        23: "Twenty Third",
        24: "Twenty Fourth",
        25: "Twenty Fifth",
        26: "Twenty Sixth",
        27: "Twenty Seventh",
        28: "Twenty Eighth",
        29: "Twenty Ninth",
        30: "Thirtieth",
        31: "Thirty First"
      };

      return ordinal[num] || "";
    }


    // =========================================================
    // YEAR IN WORDS
    // =========================================================

    function yearToWords(year) {

      year = parseInt(year, 10);

      if (isNaN(year)) return "";

      if (year >= 2000 && year < 2100) {
        if (year === 2000) return "Two Thousand";

        return "Two Thousand " + numberToWords(year - 2000);
      }

      if (year >= 1900 && year < 2000) {
        const lastTwo = year - 1900;

        if (lastTwo === 0) return "Nineteen Hundred";

        return "Nineteen " + numberToWords(lastTwo);
      }

      if (year >= 1800 && year < 1900) {
        const lastTwo = year - 1800;

        if (lastTwo === 0) return "Eighteen Hundred";

        return "Eighteen " + numberToWords(lastTwo);
      }

      return numberToWords(year);
    }


    // =========================================================
    // DATE IN WORDS
    // =========================================================

    function dateInWords(dateString) {

      if (!dateString) return "";

      dateString = clean(dateString);

      let day = 0;
      let month = 0;
      let year = 0;

      let match = dateString.match(
        /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/
      );

      if (match) {
        day = parseInt(match[1], 10);
        month = parseInt(match[2], 10);
        year = parseInt(match[3], 10);
      }

      if (!day) {
        match = dateString.match(
          /^(\d{1,2})-(\d{1,2})-(\d{4})$/
        );

        if (match) {
          day = parseInt(match[1], 10);
          month = parseInt(match[2], 10);
          year = parseInt(match[3], 10);
        }
      }

      if (!day) {
        match = dateString.match(
          /^(\d{1,2})\.(\d{1,2})\.(\d{4})$/
        );

        if (match) {
          day = parseInt(match[1], 10);
          month = parseInt(match[2], 10);
          year = parseInt(match[3], 10);
        }
      }

      if (!day) {
        match = dateString.match(
          /^(\d{1,2})\s+([A-Za-z]+)\s+(\d{4})$/i
        );

        if (match) {
          day = parseInt(match[1], 10);

          const monthName = match[2].toLowerCase();

          year = parseInt(match[3], 10);

          const monthNames = {
            january: 1,
            february: 2,
            march: 3,
            april: 4,
            may: 5,
            june: 6,
            july: 7,
            august: 8,
            september: 9,
            october: 10,
            november: 11,
            december: 12
          };

          month = monthNames[monthName] || 0;
        }
      }

      const months = [
        "",
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December"
      ];

      if (!day || !month || !year || !months[month]) {
        console.warn(
          "Could not convert DOB:",
          dateString
        );
        return "";
      }

      const dayWords = ordinalWord(day);
      const yearWords = yearToWords(year);

      if (!dayWords || !yearWords) return "";

      return (
        dayWords +
        " of " +
        months[month] +
        " " +
        yearWords
      );
    }

    const birthDateWords = dateInWords(birthDate);


    // =========================================================
    // BILINGUAL DATA
    // =========================================================

    function bilingual(label) {

      const target =
        clean(label)
          .toUpperCase()
          .replace(/\s+/g, " ");

      for (const row of rows) {

        const rowCells = [
          ...row.querySelectorAll("th, td")
        ];

        if (!rowCells.length) continue;

        const texts = rowCells.map(cell =>
          clean(
            cell.innerText ||
            cell.textContent ||
            ""
          )
        );

        const englishIndex =
          texts.findIndex(text =>
            text
              .toUpperCase()
              .replace(/\s+/g, " ")
              .includes(target)
          );

        if (englishIndex === -1) continue;

        let bn = "";
        let en = "";

        if (englishIndex > 0) {
          bn = clean(
            rowCells[englishIndex - 1].innerText ||
            rowCells[englishIndex - 1].textContent ||
            ""
          );
        }

        if (englishIndex + 1 < rowCells.length) {
          en = clean(
            rowCells[englishIndex + 1].innerText ||
            rowCells[englishIndex + 1].textContent ||
            ""
          );
        }

        console.log(
          "BILINGUAL:",
          label,
          "=> BN:",
          bn,
          "EN:",
          en
        );

        return { bn, en };
      }

      console.warn(
        "Field not found:",
        label
      );

      return {
        bn: "",
        en: ""
      };
    }


    const name =
      bilingual("REGISTERED PERSON NAME");

    const mother =
      bilingual("MOTHER'S NAME");

    const motherNat =
      bilingual("MOTHER'S NATIONALITY");

    const father =
      bilingual("FATHER'S NAME");

    const fatherNat =
      bilingual("FATHER'S NATIONALITY");

    const place =
      bilingual("PLACE OF BIRTH");

    const address =
      bilingual("PERMANENT ADDRESS");


    // =========================================================
    // REGISTER OFFICE LOCATION
    // =========================================================

    const bodyText =
      document.body.innerText || "";

    let location = "";

    const locationMatch =
      bodyText.match(
        /Location\s+of\s+the\s+Register\s+office\s*:\s*([^.\n]+)\./i
      );

    if (locationMatch) {
      location =
        clean(locationMatch[1]);
    }

    location =
      location
        .replace(
          /everify\.bdris\.gov\.bd.*$/i,
          ""
        )
        .replace(
          /bdris\.gov\.bd.*$/i,
          ""
        )
        .trim();


    let location1 = "";
    let location2 = "";

    const locationParts =
      location
        .split(",")
        .map(clean)
        .filter(Boolean);

    if (locationParts.length >= 3) {
      location2 = locationParts.pop();
      location1 = locationParts.join(", ");
    } else {
      location1 = location;
    }


    // =========================================================
    // LOAD BARCODE LIBRARY
    // =========================================================

    function loadBarcode() {

      if (window.JsBarcode) {
        return Promise.resolve();
      }

      return new Promise(
        (resolve, reject) => {

          const script =
            document.createElement("script");

          script.src =
            "https://cdn.jsdelivr.net/npm/jsbarcode@3.11.6/dist/JsBarcode.all.min.js";

          script.onload = resolve;
          script.onerror = reject;

          document.head.appendChild(script);
        }
      );
    }


    try {
      await loadBarcode();
    } catch (e) {
      alert(
        "Barcode library could not be loaded."
      );
      return;
    }


    // =========================================================
    // FIND ORIGINAL QR
    // =========================================================

    const images =
      [...document.images];

    let qr =
      images.find(
        img =>
          /qr/i.test(
            (img.src || "") +
            " " +
            (img.alt || "") +
            " " +
            (img.className || "")
          )
      );


    if (!qr) {

      qr =
        images
          .map(img => {

            const w =
              img.naturalWidth ||
              img.width ||
              0;

            const h =
              img.naturalHeight ||
              img.height ||
              0;

            return {
              img,
              w,
              h,
              area: w * h
            };

          })
          .filter(x =>
            x.w > 100 &&
            x.h > 100 &&
            Math.abs(x.w - x.h) <
              Math.max(x.w, x.h) * 0.30
          )
          .sort(
            (a, b) =>
              b.area - a.area
          )[0]?.img;
    }


    // =========================================================
    // FIELD FUNCTION
    // =========================================================

    function field(
      bnLabel,
      enLabel,
      bnValue,
      enValue,
      extra = ""
    ) {

      return `
        <div class="data-row ${extra}">

          <div class="bn-label">
            ${bnLabel}
          </div>

          <div class="colon">
            :
          </div>

          <div class="bn-value">
            ${bnValue || ""}
          </div>

          <div class="en-label">
            ${enLabel}
          </div>

          <div class="colon">
            :
          </div>

          <div class="en-value">
            ${enValue || ""}
          </div>

        </div>
      `;
    }


    // =========================================================
    // CREATE PAGE
    // =========================================================

    const page =
      document.createElement("div");

    page.id =
      "BR_A4_PRINT";

    page.innerHTML = `

      <div class="certificate">

        <div class="content">

                <img class="certificate-watermark" src="${watermarkDataUrl || ""}" alt="">

          <div class="top-area">

            <div class="header-logo-area">

              <img
                src="${headerLogoDataUrl || ""}"
                class="header-logo"
                alt=""
              >

            </div>

            <div class="qr-area">

              ${
                qr
                ? `
                  <img
                    src="${qr.src}"
                    class="qr"
                  >
                `
                : ""
              }

            </div>

            <div class="barcode-area">

              <svg
                id="BR_BARCODE"
                class="barcode"
              ></svg>

            </div>

          </div>


          <div class="header-text">

            <div class="gov-title">
              Government of the People's Republic of Bangladesh
            </div>

            <div class="office-title">
              Office of the Registrar, Birth and Death Registration
            </div>

            ${
              registrationOffice
              ? `
                <div class="union-title">
                  ${registrationOffice}
                </div>
              `
              : ""
            }

            ${
              location1
              ? `
                <div class="location-title">
                  ${location1}
                </div>
              `
              : ""
            }

            ${
              location2
              ? `
                <div class="location-title">
                  ${location2}
                </div>
              `
              : ""
            }

            <div class="rules">
              (Rule 9, 10)
            </div>

          </div>


          <div class="certificate-title">

            জন্ম নিবন্ধন সনদ /
            <span>
              Birth Registration Certificate
            </span>

          </div>


          <div class="registration-info">

            <div class="reg-left">

              <div class="reg-label">
                Date of Registration
              </div>

              <div class="reg-value">
                ${registrationDate}
              </div>

            </div>


            <div class="reg-center">

              <div class="reg-label">
                Birth Registration Number
              </div>

              <div class="reg-number">
                ${registrationNumber}
              </div>

            </div>


            <div class="reg-right">

              <div class="reg-label">
                Date of Issuance
              </div>

              <div class="reg-value">
                ${issuanceDate}
              </div>

            </div>

          </div>


          <!-- DATE OF BIRTH + SEX -->

          <div class="birth-info">

            <div class="birth-date-row">

              <div class="birth-label">
                <b>Date of Birth</b>
              </div>

              <div class="birth-colon">
                :
              </div>

              <div class="birth-value">
                ${birthDate}
              </div>

            </div>


            <div class="sex-row">

              <b>Sex</b>

              <span>
                :
              </span>

              ${sex}

            </div>

          </div>


          <!-- IN WORD: EXACT SAME ALIGNMENT -->

          <div class="birth-in-words">

            <div class="birth-label">
              <b>In Word</b>
            </div>

            <div class="birth-colon">
              :
            </div>

            <div class="birth-value">
              ${birthDateWords}
            </div>

          </div>


          <div class="details">

            ${field(
              "নাম",
              "Name",
              name.bn,
              name.en
            )}

            ${field(
              "মাতা",
              "Mother",
              mother.bn,
              mother.en
            )}

            ${field(
              "মাতার জাতীয়তা",
              "Nationality",
              motherNat.bn,
              motherNat.en
            )}

            ${field(
              "পিতা",
              "Father",
              father.bn,
              father.en
            )}

            ${field(
              "পিতার জাতীয়তা",
              "Nationality",
              fatherNat.bn,
              fatherNat.en
            )}

            ${field(
              "জন্মস্থান",
              "Place of Birth",
              place.bn,
              place.en
            )}

            ${
              address.bn ||
              address.en
              ? field(
                  "স্থায়ী ঠিকানা",
                  "Permanent Address",
                  address.bn,
                  address.en,
                  "address-row"
                )
              : ""
            }

          </div>


          <div class="footer">

            This unofficial certificate was generated from everify.bdris.gov.bd. Please verify the information through the official service.<br>
              (এই অনানুষ্ঠানিক সনদটি everify.bdris.gov.bd থেকে তৈরি করা হয়েছে। অনুগ্রহ করে অফিসিয়াল সেবার মাধ্যমে তথ্য যাচাই করুন। )



          </div>

        </div>

      </div>
    `;


    // =========================================================
    // CSS
    // =========================================================

    const style =
      document.createElement("style");

    style.id =
      "BR_A4_STYLE";

    style.textContent = `

      @page {
        size: A4 portrait;
        margin: 0;
      }

      #BR_A4_PRINT {
        display: none;
      }

      @media print {

        html,
        body {

          margin: 0 !important;
          padding: 0 !important;

          width: 210mm !important;
          height: 297mm !important;

          background: white !important;

        }

        body > * {
          display: none !important;
        }

        #BR_A4_PRINT {
          display: block !important;
        }


        /* A4 */

        .certificate {

          position: relative;

          width: 210mm;
          height: 297mm;

          box-sizing: border-box;

          padding:
            14mm
            14mm
            14mm
            14mm;

          background: white;

          overflow: hidden;

          font-family:
            Arial,
            "Kalpurush",
            sans-serif;

          color: #111;

        }


        /* WATERMARK */

        .watermark {

          position: absolute;

          z-index: 0;

          top: 112mm;
          left: -30mm;

          width: 270mm;

          text-align: center;

          white-space: nowrap;

          font-family:
            Arial,
            sans-serif;

          font-size: 40px;

          font-weight: 900;

          letter-spacing: 2px;

          color:
            rgba(
              0,
              0,
              0,
              0.045
            );

          transform:
            rotate(-35deg);

          pointer-events: none;

        }


        .content {

          position: relative;

          z-index: 2;

          width: 100%;
          height: 100%;

        }


        /* =====================================================
           CENTER WATERMARK IMAGE
        ===================================================== */

        .certificate-watermark {

          position: absolute;

          left: 50%;

          top: 55%;

          width: 150mm;

          height: 150mm;

          object-fit: contain;

          transform: translate(-50%, -50%);

          opacity: 0.10;

          z-index: 1;

          pointer-events: none;

          user-select: none;

          -webkit-print-color-adjust: exact;

          print-color-adjust: exact;

        }


        /* TOP */

        .top-area {

          position: relative;

          width: 100%;

          height: 16mm;

        }


        /* CENTER HEADER LOGO
           Uses the logo image stored inside the extension.
           Positioned in the existing top area so the rest of
           the certificate layout does not move. */

        .header-logo-area {

          position: absolute;

          top: 0;

          left: 50%;

          width: 16mm;

          height: 16mm;

          transform: translateX(-50%);

          display: flex;

          align-items: center;

          justify-content: center;

          z-index: 5;

        }


        .header-logo {

          display: block;

          width: 14mm;

          height: 14mm;

          object-fit: contain;

        }


        /* QR */

        .qr-area {

          position: absolute;

          top: 0;
          left: 0;

          width: 32mm;
          height: 32mm;

          z-index: 3;

        }


        .qr {

          display: block;

          width: 30mm;
          height: 30mm;

          object-fit: contain;

          margin: 0;

        }


        /* BARCODE */

        .barcode-area {

          position: absolute;

          top: 0;
          right: 0;

          width: 55mm;
          height: 16mm;

          display: flex;

          align-items:
            flex-start;

          justify-content:
            flex-end;

          z-index: 3;

        }


        .barcode {

          display: block;

          width: 55mm;
          height: 13mm;

          margin: 0;

        }


        /* HEADER */

        .header-text {

          position: relative;

          z-index: 4;

          width: 100%;

          text-align: center;

          margin-top: 0;

          padding-top: 0;

          line-height: 1.15;

        }


        .gov-title {

          font-family:
            Arial,
            sans-serif;

          font-size: 19px;

          font-weight: 400;

          line-height: 1.2;

          white-space: nowrap;

          margin: 0;

        }


        .office-title {

          font-family:
            Arial,
            sans-serif;

          font-size: 15px;

          font-weight: 400;

          line-height: 1.2;

          white-space: nowrap;

          margin-top: 1.0mm;

        }


        .union-title {

          font-family:
            Arial,
            sans-serif;

          font-size: 15px;

          font-weight: 400;

          line-height: 1.2;

          white-space: nowrap;

          margin-top: 1.5mm;

        }


        .location-title {

          font-family:
            Arial,
            sans-serif;

          font-size: 14px;

          font-weight: 400;

          line-height: 1.2;

          white-space: nowrap;

          margin-top: 1mm;

        }


        .rules {

          font-family:
            Arial,
            sans-serif;

          font-size: 13.5px;

          line-height: 1.2;

          margin-top: 1mm;

        }


        /* TITLE */

        .certificate-title {

          position: relative;

          z-index: 4;

          text-align: center;

          font-family:
            "Kalpurush",
            Georgia,
            serif;

          font-size: 23px;

          font-weight: 700;

          line-height: 1.3;

          white-space: nowrap;

          margin-top: 6mm;

          margin-bottom: 6mm;

        }


        .certificate-title span {

          font-family:
            Georgia,
            "Times New Roman",
            serif;

        }


        /* REGISTRATION */

        .registration-info {

          position: relative;

          z-index: 4;

          display: grid;

          grid-template-columns:
            1fr
            1.5fr
            1fr;

          width: 100%;

          margin-bottom: 8mm;

        }


        .reg-label {

          font-size: 15px;

          margin-bottom: 2mm;

        }


        .reg-value {

          font-size: 15px;

        }


        .reg-number {

          font-size: 15px;

          font-weight: 700;

        }


        .reg-center {

          text-align: center;

        }


        .reg-right {

          text-align: right;

          padding-right: 3mm;

        }


        /* DOB */

        .birth-info {

          position: relative;

          z-index: 4;

          display: grid;

          grid-template-columns:
            1fr
            1fr;

          width: 100%;

          margin-bottom: 1mm;

        }


        /*
         * EXACT ALIGNMENT
         *
         * Label = 30mm
         * Colon = 5mm
         * Value = remaining
         */

        .birth-date-row {

          display: grid;

          grid-template-columns:
            30mm
            5mm
            1fr;

          align-items: start;

          font-size: 15px;

          line-height: 1.45;

        }


        .birth-label {

          white-space: nowrap;

        }


        .birth-colon {

          text-align: center;

        }


        .birth-value {

          white-space: nowrap;

        }


        /* SEX */

        .sex-row {

          text-align: right;

          padding-right: 17mm;

          font-size: 15px;

          line-height: 1.45;

          white-space: nowrap;

        }


        .sex-row span {

          padding: 0 3mm;

        }


        /* IN WORD */

        .birth-in-words {

          position: relative;

          z-index: 4;

          display: grid;

          grid-template-columns:
            30mm
            5mm
            1fr;

          width: 100%;

          align-items: start;

          font-size: 17px;

          line-height: 1.45;

          margin-bottom: 5mm;

        }


        /* DETAILS */

        .details {

          position: relative;

          z-index: 4;

        }


        .data-row {

          display: grid;

          grid-template-columns:
            30mm
            5mm
            50mm
            30mm
            5mm
            1fr;

          min-height: 13mm;

          align-items: start;

          font-size: 17px;

          line-height: 1.45;

        }


        .bn-label,
        .bn-value {

          font-family:
            "Kalpurush",
            sans-serif;

          font-size: 19px;

        }


        .en-label,
        .en-value {

          font-family:
            Arial,
            sans-serif;

          font-size: 16px;

        }


        .colon {

          text-align: center;

        }


        .address-row {

          margin-top: 3mm;

        }


        /* FOOTER */

        .footer {

          position: absolute;

          z-index: 4;

          left: 0;
          right: 0;

          bottom: 14mm;

          text-align: center;

          font-size: 11px;

          line-height: 1.5;

        }

      }

    `;


    document.head.appendChild(style);
    document.body.appendChild(page);


    // =========================================================
    // BARCODE
    // =========================================================

    if (
      /^\d{17}$/.test(
        registrationNumber
      )
    ) {

      JsBarcode(
        "#BR_BARCODE",
        registrationNumber,
        {

          format: "CODE128",

          width: 2.00,

          height: 35,

          displayValue: false,

          margin: 0,

          background: "#ffffff",

          lineColor: "#000000"

        }
      );

    } else {

      console.warn(
        "17 digit registration number not found:",
        registrationNumber
      );

    }


    // =========================================================
    // PRINT
    // =========================================================

    setTimeout(
      () => {
        window.print();
      },
      800
    );


    // =========================================================
    // CLEANUP
    // =========================================================

    window.addEventListener(
      "afterprint",
      function cleanup() {

        document
          .getElementById(
            "BR_A4_PRINT"
          )
          ?.remove();

        document
          .getElementById(
            "BR_A4_STYLE"
          )
          ?.remove();

        window.removeEventListener(
          "afterprint",
          cleanup
        );

      }
    );

  })();
}

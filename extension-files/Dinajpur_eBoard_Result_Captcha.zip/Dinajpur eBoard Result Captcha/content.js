(() => {
"use strict";

console.log("🚀 Dinajpur eBoard Result Captcha v1 loaded by Mahabur");

let lastQuestion = "";

function calculate(s) {
  s = s.replace(/\s+/g, "");

  if (!/^\d+(?:[+\-*/]\d+)+$/.test(s)) return null;

  const nums = s.split(/[+\-*/]/).map(Number);
  const ops = s.match(/[+\-*/]/g);

  const values = [nums[0]];
  const addOps = [];

  for (let i = 0; i < ops.length; i++) {
    if (ops[i] === "*") {
      values[values.length - 1] *= nums[i + 1];
    } else if (ops[i] === "/") {
      if (nums[i + 1] === 0) return null;
      values[values.length - 1] /= nums[i + 1];
    } else {
      values.push(nums[i + 1]);
      addOps.push(ops[i]);
    }
  }

  let result = values[0];

  for (let i = 0; i < addOps.length; i++) {
    if (addOps[i] === "+") {
      result += values[i + 1];
    } else {
      result -= values[i + 1];
    }
  }

  return Number.isFinite(result) ? result : null;
}

function findQuestion() {
  for (const el of document.querySelectorAll("body *")) {
    if (["SCRIPT", "STYLE", "INPUT", "TEXTAREA"].includes(el.tagName)) continue;

    const text = (el.textContent || "")
      .replace(/\u00a0/g, " ")
      .replace(/\s+/g, " ")
      .trim();

    const match = text.match(
      /(\d+(?:\s*[+\-*/]\s*\d+)*)\s*=\s*\?/
    );

    if (match) {
      return {
        element: el,
        question: match[0],
        expression: match[1]
      };
    }
  }

  return null;
}

// IMPORTANT:
// Find the input whose placeholder says "Answer".
// We do NOT use the first input on the page.
function findAnswerInput() {
  const inputs = document.querySelectorAll(
    'input:not([type="hidden"]):not([type="submit"]):not([type="button"]):not([type="checkbox"]):not([type="radio"]), textarea'
  );

  // First priority: exact "Answer" placeholder.
  for (const input of inputs) {
    const placeholder = (input.getAttribute("placeholder") || "")
      .trim()
      .toLowerCase();

    if (
      placeholder === "answer" &&
      !input.disabled &&
      !input.readOnly
    ) {
      return input;
    }
  }

  // Second priority: placeholder containing "answer".
  for (const input of inputs) {
    const placeholder = (input.getAttribute("placeholder") || "")
      .trim()
      .toLowerCase();

    if (
      placeholder.includes("answer") &&
      !input.disabled &&
      !input.readOnly
    ) {
      return input;
    }
  }

  return null;
}

function fillInput(input, value) {
  const stringValue = String(value);

  if (input instanceof HTMLInputElement) {
    const setter = Object.getOwnPropertyDescriptor(
      HTMLInputElement.prototype,
      "value"
    )?.set;

    if (setter) {
      setter.call(input, stringValue);
    } else {
      input.value = stringValue;
    }
  } else {
    input.value = stringValue;
  }

  input.dispatchEvent(new Event("input", { bubbles: true }));
  input.dispatchEvent(new Event("change", { bubbles: true }));
  input.dispatchEvent(new Event("blur", { bubbles: true }));
}

function solve() {
  const found = findQuestion();

  if (!found) return;

  if (found.question === lastQuestion) return;

  console.log("🔎 Question found:", found.question);
  console.log("➡️ Expression:", found.expression);

  const answer = calculate(found.expression);

  if (answer === null) {
    console.log("❌ Could not calculate:", found.question);
    return;
  }

  // ONLY target the Answer placeholder field.
  const input = findAnswerInput();

  if (!input) {
    console.log('❌ Input with placeholder="Answer" not found');
    return;
  }

  console.log(
    '🎯 Answer field found:',
    input.getAttribute("placeholder")
  );

  fillInput(input, answer);

  lastQuestion = found.question;

  console.log(`✅ ${found.question} → ${answer}`);
}

solve();

new MutationObserver(() => {
  solve();
}).observe(document.documentElement, {
  childList: true,
  subtree: true,
  characterData: true
});

setInterval(solve, 1000);

})();
(() => {
  if (window.__aiChatCleanerV3Installed) return;
  window.__aiChatCleanerV3Installed = true;

  let running = false;
  let stopRequested = false;
  let lastResult = null;
  let state = { running:false, status:"Idle", deleted:0, target:0, detail:"Ready." };

  const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
  const isVisible = el => {
    if (!el || !el.isConnected || !el.getClientRects().length) return false;
    const css = getComputedStyle(el);
    return css.display !== "none" && css.visibility !== "hidden" && Number(css.opacity) !== 0;
  };
  const norm = value => (value || "").replace(/\s+/g, " ").trim();
  const accessibleName = el => norm([
    el.getAttribute?.("aria-label"),
    el.getAttribute?.("title"),
    el.getAttribute?.("data-testid"),
    el.innerText,
    el.textContent
  ].filter(Boolean).join(" "));

  const site = location.hostname === "gemini.google.com" ? "gemini"
             : location.hostname === "chatgpt.com" ? "chatgpt" : null;

  function getChatLinks() {
    const selector = site === "gemini"
      ? 'a[href*="/app/"]'
      : 'a[href*="/c/"]';

    const found = [...document.querySelectorAll(selector)].filter(a => {
      if (!isVisible(a)) return false;
      try {
        const u = new URL(a.href, location.href);
        return site === "gemini"
          ? /^\/app\/[^/?#]+/.test(u.pathname)
          : /^\/c\/[^/?#]+/.test(u.pathname);
      } catch { return false; }
    });

    const unique = new Map();
    for (const a of found) {
      const u = new URL(a.href, location.href);
      const key = u.origin + u.pathname;
      if (!unique.has(key)) unique.set(key, a);
    }
    return [...unique.values()];
  }

  function findRowAndMenu(link) {
    // Site-specific row hints first, then progressively search ancestors.
    const rowSelectors = site === "chatgpt"
      ? ['[data-testid^="conversation"]','[data-testid*="history-item"]','li']
      : ['[data-testid*="conversation"]','[data-testid*="chat"]','li'];

    for (const selector of rowSelectors) {
      const row = link.closest(selector);
      if (row) {
        const button = findMenuInside(row);
        if (button) return { row, button };
      }
    }

    let node = link;
    for (let depth = 0; depth < 12 && node; depth++, node = node.parentElement) {
      const button = findMenuInside(node);
      if (button) return { row: node, button };
    }
    return { row: link.parentElement, button: null };
  }

  function findMenuInside(root) {
    if (!root) return null;
    const buttons = [...root.querySelectorAll('button,[role="button"]')];
    return buttons.find(button => {
      if (!isVisible(button)) return false;
      const name = accessibleName(button).toLowerCase();
      const testid = (button.getAttribute("data-testid") || "").toLowerCase();
      return /more|option|menu|action|setting|overflow/.test(name) ||
             /more|option|menu|action|overflow/.test(testid);
    }) || null;
  }

  function getVisibleMenuRoots() {
    return [...document.querySelectorAll(
      '[role="menu"],[role="dialog"],[data-radix-menu-content],[data-state="open"],[data-testid*="menu"]'
    )].filter(isVisible);
  }

  function isDeleteControl(el) {
    if (!isVisible(el)) return false;
    const name = norm(el.innerText || el.textContent || el.getAttribute("aria-label"));
    return /^(delete|delete chat|delete conversation|remove chat)$/i.test(name);
  }

  function findDeleteMenuItem() {
    const roots = getVisibleMenuRoots();
    const searchRoots = roots.length ? roots : [document];
    const selectors = '[role="menuitem"],button,[role="button"],[role="option"],[data-testid]';
    for (const root of searchRoots) {
      const match = [...root.querySelectorAll(selectors)].find(isDeleteControl);
      if (match) return match;
    }
    // Compatibility fallback: menu portals are sometimes rendered without role=menu.
    const candidates = [...document.querySelectorAll(
      '[role="menuitem"],button,[role="button"],[role="option"]'
    )].filter(isDeleteControl);
    return candidates.length === 1 ? candidates[0] : null;
  }

  function findConfirmationControl() {
    const dialogs = [...document.querySelectorAll(
      '[role="dialog"],[role="alertdialog"],[aria-modal="true"]'
    )].filter(isVisible);

    for (const dialog of dialogs) {
      const btn = [...dialog.querySelectorAll('button,[role="button"]')].find(isDeleteControl);
      if (btn) return btn;
    }

    // Some versions render a confirmation panel without dialog semantics.
    const candidates = [...document.querySelectorAll('button,[role="button"]')]
      .filter(el => isDeleteControl(el) &&
        (el.closest('[data-state="open"]') || el.closest('[data-testid*="confirm"]')));
    return candidates.length === 1 ? candidates[0] : null;
  }

  function emit(type, payload={}) {
    chrome.runtime.sendMessage({ type, ...payload }).catch(() => {});
  }

  function progress(status, deleted, target, detail) {
    state = { running, status, deleted, target, detail };
    emit("AI_CLEANER_PROGRESS", state);
  }

  async function clickAndWait(el, ms=500) {
    if (!el || !isVisible(el)) throw new Error("A required control is no longer visible.");
    el.click();
    await wait(ms);
  }

  async function deleteConversation(link) {
    const u = new URL(link.href, location.href);
    const key = u.origin + u.pathname;
    const title = norm(link.innerText || link.getAttribute("aria-label")) || "Untitled conversation";
    const { button: menuButton } = findRowAndMenu(link);

    if (!menuButton) {
      throw new Error(`Could not find the options button for "${title}".`);
    }

    await clickAndWait(menuButton, 500);

    let deleteItem = findDeleteMenuItem();
    if (!deleteItem) {
      // Escape an opened menu and fail safely; never guess another control.
      document.dispatchEvent(new KeyboardEvent("keydown", {key:"Escape", bubbles:true}));
      throw new Error(`Delete menu item was not identified for "${title}".`);
    }

    await clickAndWait(deleteItem, 550);

    // If a confirmation dialog appears, click its Delete button automatically.
    const confirmation = findConfirmationControl();
    if (confirmation) {
      await clickAndWait(confirmation, 650);
    }

    // Verify that the matching sidebar item is gone.
    for (let i=0; i<32; i++) {
      await wait(350);
      const stillPresent = getChatLinks().some(a => {
        const x = new URL(a.href, location.href);
        return x.origin + x.pathname === key;
      });
      if (!stillPresent) return title;
    }
    throw new Error(`Could not verify that "${title}" was deleted. Stopping safely.`);
  }

  async function execute(options) {
    if (running) return;
    running = true;
    stopRequested = false;
    let deleted = 0;
    let errors = 0;
    let target = 0;

    try {
      const initial = getChatLinks();
      target = options.mode === "all"
        ? initial.length
        : Math.min(Math.max(1, Number(options.count)||1), initial.length);

      if (!target) {
        const result = {running:false,status:"No chats found",deleted:0,target:0,
          detail:"No matching conversations are loaded. Open/expand the sidebar, then try again."};
        lastResult = result; state = result; emit("AI_CLEANER_FINISHED", result); return;
      }

      progress("Starting", 0, target,
        `Detected ${initial.length} loaded ${site === "gemini" ? "Gemini" : "ChatGPT"} conversations.`);

      while (deleted < target && !stopRequested) {
        const current = getChatLinks();
        if (!current.length) break;
        try {
          const title = await deleteConversation(current[0]);
          deleted++;
          progress("Deleting", deleted, target, `Deleted ${deleted} of ${target}: ${title}`);
          await wait(350);
        } catch (error) {
          errors++;
          progress("Stopped safely", deleted, target, error.message);
          break;
        }
      }

      const remaining = getChatLinks().length;
      const result = {
        running:false,
        status:stopRequested ? "Stopped" : errors ? "Stopped safely" : "Finished",
        deleted,target,
        detail:stopRequested
          ? `Stopped by request. Deleted ${deleted}; ${remaining} loaded conversations remain.`
          : errors
            ? `Stopped because the site UI could not be verified. Deleted ${deleted}; ${remaining} remain.`
            : `Finished. Deleted ${deleted}; ${remaining} loaded conversations remain.`
      };
      lastResult = result;
      state = result;
      emit("AI_CLEANER_FINISHED", result);
    } finally {
      running = false;
      state.running = false;
    }
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "AI_CLEANER_GET_STATUS") {
      sendResponse({...state, running, lastResult});
      return false;
    }
    if (message.type === "AI_CLEANER_START") {
      if (!site) {
        sendResponse({message:"Open Gemini or ChatGPT first."});
        return false;
      }
      if (running) {
        sendResponse({message:"A deletion task is already running."});
        return false;
      }
      sendResponse({message:"Deletion started. Keep this tab open."});
      execute(message);
      return false;
    }
    if (message.type === "AI_CLEANER_STOP") {
      stopRequested = true;
      sendResponse({message:"Stop requested. The current action will finish first."});
      return false;
    }
  });
})();
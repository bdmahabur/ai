const $ = id => document.getElementById(id);
const countInput = $("count");
const startButton = $("start");
const stopButton = $("stop");
const footer = $("footerStatus");
const modal = $("confirmModal");
let activeTabId = null;
let site = null;
let busy = false;

function mode() {
  return document.querySelector('input[name="mode"]:checked').value;
}
function setFooter(text) { footer.textContent = text; }

function setModeCards() {
  const custom = mode() === "number";
  $("allCard").classList.toggle("selected", !custom);
  $("customCard").classList.toggle("selected", custom);
  $("numberWrap").hidden = !custom;
}
document.querySelectorAll('input[name="mode"]').forEach(el =>
  el.addEventListener("change", setModeCards)
);
setModeCards();

$("minus").addEventListener("click", () => {
  countInput.value = Math.max(1, Number(countInput.value || 1) - 1);
});
$("plus").addEventListener("click", () => {
  countInput.value = Math.min(500, Number(countInput.value || 1) + 1);
});
document.querySelectorAll("[data-count]").forEach(button =>
  button.addEventListener("click", () => { countInput.value = button.dataset.count; })
);
countInput.addEventListener("change", () => {
  countInput.value = Math.max(1, Math.min(500, Math.floor(Number(countInput.value) || 1)));
});

function setSiteUI(tab) {
  const url = tab?.url || "";
  if (url.startsWith("https://gemini.google.com/")) {
    site = "Gemini";
    $("platformName").textContent = "Google Gemini";
    $("platformHint").textContent = "Gemini conversation sidebar";
    $("platformMark").textContent = "G";
    $("platformMark").className = "platform-mark gemini";
    $("siteDot").classList.add("ready");
    startButton.disabled = false;
    setFooter("Ready. Keep the Gemini tab open while it runs.");
  } else if (url.startsWith("https://chatgpt.com/")) {
    site = "ChatGPT";
    $("platformName").textContent = "ChatGPT";
    $("platformHint").textContent = "ChatGPT conversation sidebar";
    $("platformMark").textContent = "GPT";
    $("platformMark").className = "platform-mark chatgpt";
    $("siteDot").classList.add("ready");
    startButton.disabled = false;
    setFooter("Ready. Keep the ChatGPT tab open while it runs.");
  } else {
    site = null;
    $("platformName").textContent = "Unsupported website";
    $("platformHint").textContent = "Open Gemini or ChatGPT in this tab";
    $("platformMark").textContent = "AI";
    $("platformMark").className = "platform-mark";
    $("siteDot").classList.remove("ready");
    startButton.disabled = true;
    setFooter("This extension only runs on gemini.google.com and chatgpt.com.");
  }
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  activeTabId = tab?.id ?? null;
  setSiteUI(tab);
  return tab;
}

function showModal() {
  const custom = mode() === "number";
  const amount = custom ? Number(countInput.value) : "All currently loaded";
  $("modalSite").textContent = site || "—";
  $("modalRange").textContent = custom ? `${amount} conversations (top of sidebar)` : "All currently loaded conversations";
  $("modalText").textContent = `You are about to permanently delete ${custom ? amount : "all currently loaded"} ${site} conversations. This cannot be undone.`;
  $("ack").checked = false;
  $("confirm").disabled = true;
  modal.classList.add("open");
  modal.setAttribute("aria-hidden", "false");
}
function hideModal() {
  modal.classList.remove("open");
  modal.setAttribute("aria-hidden", "true");
}
$("ack").addEventListener("change", () => {
  $("confirm").disabled = !$("ack").checked;
});
$("cancel").addEventListener("click", hideModal);
modal.addEventListener("click", event => {
  if (event.target === modal) hideModal();
});
document.addEventListener("keydown", event => {
  if (event.key === "Escape") hideModal();
});

function updateProgress(message) {
  $("progressPanel").hidden = false;
  $("progressTitle").textContent = message.status || "Working…";
  $("progressCount").textContent = `${message.deleted || 0} / ${message.target || 0}`;
  const pct = message.target ? Math.min(100, (message.deleted / message.target) * 100) : 0;
  $("progressBar").style.width = `${pct}%`;
  $("progressDetail").textContent = message.detail || "Keep this tab open while deletion runs.";
}
function setBusy(value) {
  busy = value;
  startButton.disabled = value || !site;
  stopButton.disabled = !value;
}

async function send(message) {
  if (!activeTabId) throw new Error("No active tab found.");

  // First try the normally registered content script. If Chrome reports that
  // no receiver exists (for example, the tab was open before installation),
  // inject content.js into this tab and retry once.
  try {
    return await chrome.tabs.sendMessage(activeTabId, message);
  } catch (firstError) {
    const msg = String(firstError?.message || firstError);
    const noReceiver = /receiving end does not exist|could not establish connection|message port closed/i.test(msg);
    if (!noReceiver) throw firstError;

    await chrome.scripting.executeScript({
      target: { tabId: activeTabId },
      files: ["content.js"]
    });
    await new Promise(resolve => setTimeout(resolve, 150));
    return await chrome.tabs.sendMessage(activeTabId, message);
  }
}

startButton.addEventListener("click", () => {
  if (!site) return;
  if (mode() === "number") {
    const n = Number(countInput.value);
    if (!Number.isInteger(n) || n < 1 || n > 500) {
      setFooter("Enter a whole number from 1 to 500.");
      return;
    }
  }
  showModal();
});
$("confirm").addEventListener("click", async () => {
  hideModal();
  setBusy(true);
  $("progressPanel").hidden = false;
  updateProgress({ status: "Starting…", deleted: 0, target: mode() === "all" ? 0 : Number(countInput.value) });
  try {
    const result = await send({
      type: "AI_CLEANER_START",
      mode: mode(),
      count: mode() === "all" ? null : Number(countInput.value)
    });
    setFooter(result?.message || "Deletion started.");
  } catch (error) {
    setBusy(false);
    setFooter(error.message || "Could not connect. Refresh the website and try again.");
  }
});
stopButton.addEventListener("click", async () => {
  try {
    await send({ type: "AI_CLEANER_STOP" });
    setFooter("Stop requested. The current deletion action will finish first.");
    stopButton.disabled = true;
  } catch (error) {
    setFooter(error.message || String(error));
  }
});

chrome.runtime.onMessage.addListener(message => {
  if (message.type === "AI_CLEANER_PROGRESS") {
    updateProgress(message);
    setFooter(message.detail || "Deletion in progress…");
  }
  if (message.type === "AI_CLEANER_FINISHED") {
    updateProgress(message);
    setBusy(false);
    setFooter(message.detail || "Task finished.");
  }
});

(async () => {
  const tab = await getActiveTab();
  if (tab?.id) {
    try {
      const status = await chrome.tabs.sendMessage(tab.id, { type: "AI_CLEANER_GET_STATUS" });
      if (status?.running) {
        setBusy(true);
        updateProgress(status);
        setFooter("A deletion task is already running in this tab.");
      } else if (status?.lastResult) {
        updateProgress(status.lastResult);
      }
    } catch {
      // Content script may not yet be injected; a page refresh usually resolves this.
    }
  }
})();

// Prevent mouse-wheel scrolling from changing the single page number.
document.addEventListener('wheel', function (e) {
    const input = e.target.closest('input[type="number"]');

    if (input && document.activeElement === input) {
        input.blur();
    }
});
# Dropdown Autofill Presets (Chrome Extension)

## Install in Chrome
1. Download and unzip `dropdown_autofill_extension.zip`.
2. Open `chrome://extensions`.
3. Turn on **Developer mode**.
4. Click **Load unpacked** and choose the extracted `dropdown_autofill_extension` folder.
5. Pin the extension from the puzzle-piece menu if you want quick access.

## Use
1. Open the website with the dropdowns.
2. Choose the options you want on the page.
3. Click the extension icon, optionally type a preset name, then click **Save current dropdowns**.
4. Later, open the relevant page, click the extension icon, and choose **Apply to current page** under the preset.
5. To delete a preset, click the trash icon beside its name and confirm the prompt.

## Notes
- Presets are stored locally in Chrome using `chrome.storage.local`.
- Applying changes form fields but does not click Submit.
- The extension needs access to the active tab only when you click it.
- Some websites use dependent dropdowns or custom controls; those may need site-specific adjustments.
- Do not use it to bypass access controls, site restrictions, or server-side validation.

const nameInput = document.getElementById("presetName");
const saveButton = document.getElementById("save");
const presetsDiv = document.getElementById("presets");
const statusDiv = document.getElementById("status");

function setStatus(message, isError = false) {
  statusDiv.textContent = message;
  statusDiv.style.color = isError ? "#b3261e" : "#137333";
}

async function activeTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tabs[0] || !tabs[0].id) throw new Error("No active tab found.");
  return tabs[0];
}

async function readDropdowns() {
  const tab = await activeTab();
  const results = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => [...document.querySelectorAll("select")].map((select, index) => ({
      index,
      value: select.value,
      text: select.options[select.selectedIndex]?.text?.trim() || "",
      optionsCount: select.options.length
    }))
  });
  return { tab, dropdowns: results?.[0]?.result || [] };
}

async function getPresets() {
  const data = await chrome.storage.local.get({ presets: [] });
  return data.presets;
}

async function saveCurrent() {
  try {
    const { tab, dropdowns } = await readDropdowns();
    if (!dropdowns.length) {
      setStatus("No dropdowns found on this page.", true);
      return;
    }
    const name = nameInput.value.trim() || `Preset ${new Date().toLocaleString()}`;
    const presets = await getPresets();
    const pageUrl = new URL(tab.url);
    presets.push({
      id: (crypto.randomUUID ? crypto.randomUUID() : String(Date.now())),
      name,
      urlPattern: pageUrl.origin + pageUrl.pathname,
      dropdowns,
      savedAt: Date.now()
    });
    await chrome.storage.local.set({ presets });
    nameInput.value = "";
    setStatus(`Saved ${dropdowns.length} dropdowns.`);
    renderPresets();
  } catch (e) {
    setStatus("Could not read this page. Try a normal website tab, not a browser settings page.", true);
  }
}

async function applyPreset(preset) {
  try {
    const tab = await activeTab();
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      args: [preset.dropdowns],
      func: async (savedDropdowns) => {
        const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
        const report = [];
        for (const saved of savedDropdowns) {
          const selects = [...document.querySelectorAll("select")];
          const select = selects[saved.index];
          if (!select) {
            report.push(`Dropdown ${saved.index + 1}: not found`);
            continue;
          }
          let option = [...select.options].find(o => o.value === saved.value);
          if (!option && saved.text) {
            option = [...select.options].find(o => o.text.trim() === saved.text);
          }
          if (!option) {
            report.push(`Dropdown ${saved.index + 1}: option not available (${saved.text || saved.value})`);
            continue;
          }
          select.value = option.value;
          select.dispatchEvent(new Event("input", { bubbles: true }));
          select.dispatchEvent(new Event("change", { bubbles: true }));
          report.push(`Dropdown ${saved.index + 1}: ${option.text.trim() || option.value}`);
          await sleep(350);
        }
        return report;
      }
    });
    const report = results?.[0]?.result || [];
    setStatus(report.length ? report.join(" · ") : "No dropdowns were changed.");
  } catch (e) {
    setStatus("Could not apply preset on this page. Refresh the page and try again.", true);
  }
}

async function deletePreset(id, name) {
  const confirmed = window.confirm(`Delete the preset "${name}"?\nThis cannot be undone.`);
  if (!confirmed) {
    setStatus("Deletion cancelled.");
    return;
  }
  const presets = await getPresets();
  await chrome.storage.local.set({ presets: presets.filter(p => p.id !== id) });
  setStatus(`Deleted "${name}".`);
  renderPresets();
}

async function renderPresets() {
  const presets = await getPresets();
  presetsDiv.replaceChildren();
  if (!presets.length) {
    const empty = document.createElement("p");
    empty.textContent = "No saved presets yet.";
    presetsDiv.appendChild(empty);
    return;
  }
  for (const preset of presets.slice().reverse()) {
    const card = document.createElement("div");
    card.className = "preset";

    const header = document.createElement("div");
    header.className = "preset-header";

    const title = document.createElement("div");
    title.className = "preset-name";
    title.textContent = preset.name;

    const remove = document.createElement("button");
    remove.className = "delete-icon";
    remove.type = "button";
    remove.title = `Delete ${preset.name}`;
    remove.setAttribute("aria-label", `Delete ${preset.name}`);
    remove.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="m19 6-1 14H6L5 6"/><path d="M10 10v6M14 10v6"/></svg>`;
    remove.addEventListener("click", () => deletePreset(preset.id, preset.name));

    header.append(title, remove);

    const details = document.createElement("div");
    details.className = "details";
    details.textContent = preset.dropdowns
       .filter(d => d.text)
       .map(d => d.text)
      .join(" ⬩ ");

    const apply = document.createElement("button");
    apply.className = "apply";
    apply.type = "button";
    apply.textContent = "Apply to current page";
    apply.addEventListener("click", () => applyPreset(preset));

    card.append(header, details, apply);
    presetsDiv.appendChild(card);
  }
}

saveButton.addEventListener("click", saveCurrent);
renderPresets();

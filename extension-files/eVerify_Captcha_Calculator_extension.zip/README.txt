eVerify Arithmetic Calculator

Purpose:
- Runs only on https://everify.bdris.gov.bd/*
- Adds a "Test calculation" field immediately before the existing CAPTCHA answer field.
- Calculates simple +, -, *, / expressions.
- Displays the result in its own calculator result line.
- Does NOT read, solve, or populate the CAPTCHA answer field.

Installation:
1. Extract the ZIP.
2. Open chrome://extensions
3. Enable Developer mode.
4. Click "Load unpacked".
5. Select the extracted extension folder.
6. Open https://everify.bdris.gov.bd/

Examples:
97-8
25+10
12*4
100/5

(() => {
    document.querySelector("#myArithmeticTest")?.remove();

    const answer = document.querySelector("#CaptchaInputText");

    if (!answer) {
        console.error("❌ #CaptchaInputText not found");
        return;
    }

    const box = document.createElement("div");
    box.id = "myArithmeticTest";

    box.style.cssText = `
        margin: 10px 0;
        font-family: Arial, sans-serif;
    `;

    const label = document.createElement("div");
    label.textContent = "Calculate Captcha";
    label.style.cssText = `
        margin-bottom: 5px;
        font-weight: bold;
    `;

    const input = document.createElement("input");
    input.type = "text";
    input.placeholder = "Calculator";
    input.autocomplete = "off";
    input.autofocus = false;

    input.style.cssText = `
        width: 180px;
        padding: 2px;
        font-size: 12px;
        box-sizing: border-box;
    `;

    box.appendChild(label);
    box.appendChild(input);

    // Put calculator immediately before the CAPTCHA answer field
    answer.parentNode.insertBefore(box, answer);

    function calculate(text) {
        const m = text.match(
            /^\s*(-?\d+(?:\.\d+)?)\s*([+\-*/])\s*(-?\d+(?:\.\d+)?)\s*$/
        );

        if (!m) return "";

        const a = Number(m[1]);
        const op = m[2];
        const b = Number(m[3]);

        let result;

        switch (op) {
            case "+":
                result = a + b;
                break;

            case "-":
                result = a - b;
                break;

            case "*":
                result = a * b;
                break;

            case "/":
                if (b === 0) return "";
                result = a / b;
                break;

            default:
                return "";
        }

        // Remove unnecessary .0
        return Number.isInteger(result)
            ? String(result)
            : String(result);
    }

    function setAnswer(value) {
        // Use the native setter so frameworks/page scripts detect it
        const prototype = Object.getPrototypeOf(answer);
        const descriptor = Object.getOwnPropertyDescriptor(
            prototype,
            "value"
        );

        if (descriptor && descriptor.set) {
            descriptor.set.call(answer, value);
        } else {
            answer.value = value;
        }

        answer.dispatchEvent(
            new Event("input", {
                bubbles: true
            })
        );

        answer.dispatchEvent(
            new Event("change", {
                bubbles: true
            })
        );
    }

    input.addEventListener("input", () => {
        const expression = input.value.trim();
        const result = calculate(expression);

        if (result === "") {
            setAnswer("");
            console.log("⏳ Waiting for valid expression...");
            return;
        }

        setAnswer(result);

        console.log(
            `✅ ${expression} = ${result}`
        );
        console.log(
            `📝 Answer field value: ${answer.value}`
        );
    });

    input.focus();

    console.log("✅ Test calculator injected");
})();
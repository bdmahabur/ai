SSC Result A4 Print v1.1

The extension does NOT automatically open print preview when visiting eboardresults.com.

It adds a "🖨 Print A4" button in the top-right corner.

Click the button to:
- Apply the A4 portrait print layout
- Use the larger readable fonts and table spacing
- Hide the extension button and print controls during printing
- Open Chrome's normal print preview

Only matches:
https://eboardresults.com/*

Installation:
1. Extract the ZIP.
2. Open chrome://extensions/
3. Enable Developer mode.
4. Click Load unpacked.
5. Select the extracted ssc_a4_print_extension_click folder.

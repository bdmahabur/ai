(() => {

    // ==================================================
    // SSC / HSC / OTHER RESULT A4 PRINT EXTENSION
    // ==================================================

    const STYLE_ID = "RESULT_A4_PRINT_STYLE";
    const BUTTON_ID = "RESULT_A4_PRINT_BUTTON";


    // ==================================================
    // DON'T CREATE BUTTON TWICE
    // ==================================================

    if (document.getElementById(BUTTON_ID)) {
        return;
    }


    // ==================================================
    // FIND THE ACTUAL RESULT HEADING
    // ==================================================

    function getResultHeading() {

        const headings = [
            ...document.querySelectorAll(
                "h1, h2, h3, h4, h5, h6"
            )
        ];

        for (const heading of headings) {

            const text = (
                heading.innerText ||
                heading.textContent ||
                ""
            )
            .replace(/\s+/g, " ")
            .trim();

            if (
                /RESULT\s+OF/i.test(text)
            ) {
                return text;
            }
        }

        return null;
    }


    // ==================================================
    // DETECT RESULT TYPE
    // ==================================================

    function detectResultType() {

        // ----------------------------------------------
        // FIRST PRIORITY:
        // ACTUAL RESULT HEADING
        // ----------------------------------------------

        const heading =
            getResultHeading();


        if (heading) {

            const text =
                heading.toUpperCase();


            // SSC or Equivalent
            if (
                /\bSSC\b/.test(text)
            ) {
                return "SSC";
            }


            // HSC or Equivalent
            if (
                /\bHSC\b/.test(text)
            ) {
                return "HSC";
            }


            // JSC
            if (
                /\bJSC\b/.test(text)
            ) {
                return "JSC";
            }


            // JDC
            if (
                /\bJDC\b/.test(text)
            ) {
                return "JDC";
            }


            // Dakhil
            if (
                /\bDAKHIL\b/.test(text)
            ) {
                return "DAKHIL";
            }


            // Alim
            if (
                /\bALIM\b/.test(text)
            ) {
                return "ALIM";
            }
        }


        // ----------------------------------------------
        // SECOND PRIORITY:
        // SELECTED EXAMINATION
        // ----------------------------------------------

        const selects = [
            ...document.querySelectorAll("select")
        ];


        for (const select of selects) {

            const option =
                select.options[
                    select.selectedIndex
                ];


            if (!option) {
                continue;
            }


            const text = (
                option.textContent ||
                option.innerText ||
                ""
            )
            .replace(/\s+/g, " ")
            .trim()
            .toUpperCase();


            const value = (
                option.value ||
                ""
            )
            .replace(/\s+/g, " ")
            .trim()
            .toUpperCase();


            const combined =
                `${text} ${value}`;


            if (
                /\bSSC\b/.test(combined)
            ) {
                return "SSC";
            }


            if (
                /\bHSC\b/.test(combined)
            ) {
                return "HSC";
            }


            if (
                /\bJSC\b/.test(combined)
            ) {
                return "JSC";
            }


            if (
                /\bJDC\b/.test(combined)
            ) {
                return "JDC";
            }


            if (
                /\bDAKHIL\b/.test(combined)
            ) {
                return "DAKHIL";
            }


            if (
                /\bALIM\b/.test(combined)
            ) {
                return "ALIM";
            }
        }


        // ----------------------------------------------
        // THIRD PRIORITY:
        // PAGE TITLE
        // ----------------------------------------------

        const title = (
            document.title ||
            ""
        )
        .replace(/\s+/g, " ")
        .trim()
        .toUpperCase();


        if (
            /RESULT\s+OF.*\bSSC\b/.test(title)
        ) {
            return "SSC";
        }


        if (
            /RESULT\s+OF.*\bHSC\b/.test(title)
        ) {
            return "HSC";
        }


        if (
            /RESULT\s+OF.*\bJSC\b/.test(title)
        ) {
            return "JSC";
        }


        if (
            /RESULT\s+OF.*\bJDC\b/.test(title)
        ) {
            return "JDC";
        }


        if (
            /RESULT\s+OF.*\bDAKHIL\b/.test(title)
        ) {
            return "DAKHIL";
        }


        if (
            /RESULT\s+OF.*\bALIM\b/.test(title)
        ) {
            return "ALIM";
        }


        // ----------------------------------------------
        // IF NOTHING IS CERTAIN
        // ----------------------------------------------

        return "RESULT";
    }


    // ==================================================
    // FIND YEAR
    // ==================================================

    function findYear() {

        // ----------------------------------------------
        // FIRST PRIORITY:
        // ACTUAL RESULT HEADING
        // ----------------------------------------------

        const heading =
            getResultHeading();


        if (heading) {

            // Example:
            // Result of SSC or Equivalent Examination - 2016

            const match =
                heading.match(
                    /\b((?:19|20)\d{2})\b/
                );


            if (match) {

                return match[1];
            }
        }


        // ----------------------------------------------
        // SECOND PRIORITY:
        // PAGE TITLE
        // ----------------------------------------------

        const title =
            document.title || "";


        const titleMatch =
            title.match(
                /\b((?:19|20)\d{2})\b/
            );


        if (titleMatch) {

            return titleMatch[1];
        }


        // ----------------------------------------------
        // THIRD PRIORITY:
        // EXPLICIT YEAR LABEL
        // ----------------------------------------------

        const pageText =
            document.body.innerText
                .replace(/\s+/g, " ");


        const yearPatterns = [

            /EXAMINATION\s+YEAR\s*[:\-]?\s*((?:19|20)\d{2})/i,

            /EXAM\s+YEAR\s*[:\-]?\s*((?:19|20)\d{2})/i,

            /RESULT\s+YEAR\s*[:\-]?\s*((?:19|20)\d{2})/i,

            /\bYEAR\s*[:\-]\s*((?:19|20)\d{2})/i
        ];


        for (
            const pattern
            of yearPatterns
        ) {

            const match =
                pageText.match(pattern);


            if (match) {

                return match[1];
            }
        }


        // ----------------------------------------------
        // FOURTH PRIORITY:
        // URL
        // ----------------------------------------------

        const url =
            window.location.href;


        const urlMatch =
            url.match(
                /\b((?:19|20)\d{2})\b/
            );


        if (urlMatch) {

            return urlMatch[1];
        }


        // ----------------------------------------------
        // UNKNOWN
        // ----------------------------------------------

        return null;
    }


    // ==================================================
    // FIND ROLL NUMBER
    // ==================================================

    function findRollNumber() {

        // ----------------------------------------------
        // FIRST:
        // SEARCH TABLE ROWS
        // ----------------------------------------------

        const rows = [
            ...document.querySelectorAll("tr")
        ];


        for (const row of rows) {

            const cells = [
                ...row.querySelectorAll(
                    "th, td"
                )
            ];


            for (
                let i = 0;
                i < cells.length;
                i++
            ) {

                const label = (
                    cells[i].innerText ||
                    cells[i].textContent ||
                    ""
                )
                .replace(/\s+/g, " ")
                .trim()
                .toUpperCase();


                if (
                    label === "ROLL" ||
                    label === "ROLL NO" ||
                    label === "ROLL NO." ||
                    label === "ROLL NUMBER"
                ) {

                    // ----------------------------------
                    // NEXT CELL
                    // ----------------------------------

                    if (cells[i + 1]) {

                        const value =
                            cells[i + 1]
                                .innerText
                                .trim();


                        const match =
                            value.match(
                                /\b\d{4,10}\b/
                            );


                        if (match) {

                            return match[0];
                        }
                    }


                    // ----------------------------------
                    // SAME ROW
                    // ----------------------------------

                    const rowText =
                        row.innerText
                            .replace(
                                /\s+/g,
                                " "
                            );


                    const match =
                        rowText.match(
                            /ROLL(?:\s*NO\.?|\s*NUMBER)?\s*[:\-]?\s*(\d{4,10})/i
                        );


                    if (match) {

                        return match[1];
                    }
                }
            }
        }


        // ----------------------------------------------
        // SECOND:
        // SEARCH PAGE TEXT
        // ----------------------------------------------

        const text =
            document.body.innerText
                .replace(
                    /\s+/g,
                    " "
                );


        const patterns = [

            /ROLL\s*NO\.?\s*[:\-]?\s*(\d{4,10})/i,

            /ROLL\s*NUMBER\s*[:\-]?\s*(\d{4,10})/i,

            /\bROLL\s*[:\-]\s*(\d{4,10})/i
        ];


        for (
            const pattern
            of patterns
        ) {

            const match =
                text.match(pattern);


            if (match) {

                return match[1];
            }
        }


        return null;
    }


    // ==================================================
    // CREATE PRINT BUTTON
    // ==================================================

    const button =
        document.createElement("button");


    button.id =
        BUTTON_ID;


    button.type =
        "button";


    button.textContent =
        "🖨 Print A4";


    button.title =
        "Print result as A4";


    Object.assign(
        button.style,
        {

            position:
                "fixed",

            top:
                "20px",

            right:
                "20px",

            zIndex:
                "2147483647",

            padding:
                "10px 18px",

            border:
                "1px solid #333",

            borderRadius:
                "6px",

            background:
                "#ffffff",

            color:
                "#111111",

            fontSize:
                "15px",

            fontWeight:
                "600",

            fontFamily:
                "Arial, sans-serif",

            cursor:
                "pointer",

            boxShadow:
                "0 2px 8px rgba(0,0,0,.2)"
        }
    );


    // ==================================================
    // BUTTON HOVER
    // ==================================================

    button.addEventListener(
        "mouseenter",
        () => {

            button.style.background =
                "#eeeeee";
        }
    );


    button.addEventListener(
        "mouseleave",
        () => {

            button.style.background =
                "#ffffff";
        }
    );


    // ==================================================
    // PRINT BUTTON CLICK
    // ==================================================

    button.addEventListener(
        "click",
        () => {

            // ------------------------------------------
            // DETECT INFORMATION
            // ------------------------------------------

            const resultType =
                detectResultType();


            const roll =
                findRollNumber();


            const year =
                findYear();


            // ------------------------------------------
            // SAFE VALUES
            // ------------------------------------------

            const safeType =
                String(resultType)
                    .toUpperCase()
                    .replace(
                        /[^A-Z0-9_]/g,
                        ""
                    );


            const safeRoll =
                roll
                    ? String(roll)
                        .replace(
                            /\D/g,
                            ""
                        )
                    : "UNKNOWN";


            const safeYear =
                year
                    ? String(year)
                        .replace(
                            /\D/g,
                            ""
                        )
                    : "UNKNOWN";


            // ------------------------------------------
            // FILE NAME
            // ------------------------------------------

            const fileName =
                `${safeType}_${safeRoll}_${safeYear}.pdf`;


            // ------------------------------------------
            // SHOW DETECTION IN CONSOLE
            // ------------------------------------------

            console.log(
                "======================================"
            );

            console.log(
                "RESULT TYPE:",
                resultType
            );

            console.log(
                "ROLL NUMBER:",
                safeRoll
            );

            console.log(
                "RESULT YEAR:",
                safeYear
            );

            console.log(
                "PDF FILE NAME:",
                fileName
            );

            console.log(
                "======================================"
            );


            // ------------------------------------------
            // Set page title
            // Chrome may use this for PDF filename
            // ------------------------------------------

            document.title =
                fileName.replace(
                    ".pdf",
                    ""
                );


            // ------------------------------------------
            // APPLY PRINT STYLE
            // ------------------------------------------

            preparePrint();
        }
    );


    // ==================================================
    // ADD BUTTON TO PAGE
    // ==================================================

    function addButton() {

        if (
            document.body &&
            !document.getElementById(
                BUTTON_ID
            )
        ) {

            document.body.appendChild(
                button
            );
        }
    }


    if (document.body) {

        addButton();

    } else {

        window.addEventListener(
            "DOMContentLoaded",
            addButton,
            {
                once: true
            }
        );
    }


    // ==================================================
    // PREPARE A4 PRINT
    // ==================================================

    function preparePrint() {

        document
            .getElementById(
                STYLE_ID
            )
            ?.remove();


        const style =
            document.createElement(
                "style"
            );


        style.id =
            STYLE_ID;


        // ==============================================
        // A4 SETTINGS
        // ==============================================

        const A4_HEIGHT =
            297;


        const TOP =
            15;


        const BOTTOM =
            7;


        const mmToPx =
            mm =>
                mm * 96 / 25.4;


        const availableHeight =
            mmToPx(
                A4_HEIGHT -
                TOP -
                BOTTOM
            );


        // ==============================================
        // FIND VISIBLE CONTENT
        // ==============================================

        const elements = [

            ...document.querySelectorAll(
                "img, h1, h2, h3, h4, h5, h6, p, table"
            )

        ].filter(
            el => {

                const r =
                    el.getBoundingClientRect();


                return (
                    r.width > 0 &&
                    r.height > 0
                );
            }
        );


        let top =
            Infinity;


        let bottom =
            0;


        elements.forEach(
            el => {

                const r =
                    el.getBoundingClientRect();


                top =
                    Math.min(
                        top,
                        r.top
                    );


                bottom =
                    Math.max(
                        bottom,
                        r.bottom
                    );
            }
        );


        const currentHeight =
            bottom - top;


        // ==============================================
        // CALCULATE EXTRA SPACE
        // ==============================================

        let extra =
            availableHeight -
            currentHeight;


        if (extra < 0) {

            extra =
                0;
        }


        // ==============================================
        // FIND TABLE ROWS
        // ==============================================

        const rows = [

            ...document.querySelectorAll(
                "table tr"
            )

        ].filter(
            row => {

                return (
                    row
                        .getBoundingClientRect()
                        .height > 0
                );
            }
        );


        const rowCount =
            Math.max(
                rows.length,
                1
            );


        // ==============================================
        // DISTRIBUTE EXTRA SPACE
        // ==============================================

        let extraPerRow =
            extra /
            rowCount;


        extraPerRow =
            Math.min(
                extraPerRow,
                12
            );


        const paddingExtra =
            extraPerRow /
            2;


        // ==============================================
        // PRINT CSS
        // ==============================================

        style.textContent = `

            @page {

                size:
                    A4 portrait;

                margin:
                    15mm
                    15mm
                    7mm
                    15mm;
            }


            @media print {

                /* ======================================
                   PAGE
                   ====================================== */

                html,
                body {

                    width:
                        100% !important;

                    height:
                        auto !important;

                    margin:
                        0 !important;

                    padding:
                        0 !important;

                    overflow:
                        visible !important;

                    zoom:
                        1 !important;

                    transform:
                        none !important;
                }


                /* ======================================
                   HIDE PRINT BUTTON
                   ====================================== */

                #${BUTTON_ID} {

                    display:
                        none !important;
                }


                /* ======================================
                   MAIN CONTAINER
                   ====================================== */

                .container,
                .container-fluid {

                    width:
                        100% !important;

                    max-width:
                        100% !important;

                    margin:
                        0 !important;

                    padding-left:
                        0 !important;

                    padding-right:
                        0 !important;
                }


                .row {

                    margin-left:
                        0 !important;

                    margin-right:
                        0 !important;
                }


                [class*="col-"] {

                    padding-left:
                        5px !important;

                    padding-right:
                        5px !important;
                }


                /* ======================================
                   HEADER
                   ====================================== */

                header {

                    margin-top:
                        3mm !important;

                    margin-bottom:
                        4mm !important;
                }


                /* ======================================
                   LOGO
                   ====================================== */

                img:first-of-type {

                    margin-left:
                        5mm !important;

                    margin-top:
                        3mm !important;
                }


                /* ======================================
                   MAIN TITLE
                   ====================================== */

                h1 {

                    font-size:
                        23px !important;

                    line-height:
                        1.25 !important;

                    margin-top:
                        5px !important;

                    margin-bottom:
                        7px !important;
                }


                /* ======================================
                   SECTION TITLE
                   ====================================== */

                h2 {

                    font-size:
                        21px !important;

                    line-height:
                        1.25 !important;

                    margin-top:
                        5px !important;

                    margin-bottom:
                        6px !important;
                }


                h3 {

                    font-size:
                        19px !important;

                    line-height:
                        1.25 !important;

                    margin-top:
                        4px !important;

                    margin-bottom:
                        5px !important;
                }


                h4,
                h5,
                h6 {

                    margin-top:
                        4px !important;

                    margin-bottom:
                        4px !important;
                }


                /* ======================================
                   TABLES
                   ====================================== */

                table {

                    width:
                        100% !important;

                    max-width:
                        100% !important;

                    border-collapse:
                        collapse !important;

                    margin-top:
                        3px !important;

                    margin-bottom:
                        3px !important;

                    page-break-inside:
                        avoid !important;

                    break-inside:
                        avoid !important;
                }


                /* ======================================
                   TABLE HEADER
                   ====================================== */

                th {

                    font-size:
                        15px !important;

                    font-weight:
                        bold !important;

                    padding-left:
                        15px !important;

                    padding-right:
                        15px !important;

                    padding-top:
                        ${6 + paddingExtra}px !important;

                    padding-bottom:
                        ${6 + paddingExtra}px !important;

                    line-height:
                        1.15 !important;
                }


                /* ======================================
                   TABLE DATA
                   ====================================== */

                td {

                    font-size:
                        15px !important;

                    padding-left:
                        15px !important;

                    padding-right:
                        15px !important;

                    padding-top:
                        ${5 + paddingExtra}px !important;

                    padding-bottom:
                        ${5 + paddingExtra}px !important;

                    line-height:
                        1.15 !important;

                    height:
                        auto !important;
                }


                /* ======================================
                   STUDENT INFORMATION
                   ====================================== */

                table:first-of-type td {

                    font-size:
                        15px !important;

                    padding-left:
                        15px !important;

                    padding-right:
                        15px !important;

                    padding-top:
                        ${5 + paddingExtra}px !important;

                    padding-bottom:
                        ${5 + paddingExtra}px !important;
                }


                /* ======================================
                   SUBJECT TABLE
                   ====================================== */

                table:last-of-type th {

                    font-size:
                        15px !important;

                    padding-left:
                        15px !important;

                    padding-right:
                        15px !important;

                    padding-top:
                        ${7 + paddingExtra}px !important;

                    padding-bottom:
                        ${7 + paddingExtra}px !important;
                }


                table:last-of-type td {

                    font-size:
                        15px !important;

                    padding-left:
                        15px !important;

                    padding-right:
                        15px !important;

                    padding-top:
                        ${5 + paddingExtra}px !important;

                    padding-bottom:
                        ${5 + paddingExtra}px !important;
                }


                /* ======================================
                   PARAGRAPHS
                   ====================================== */

                p {

                    font-size:
                        15px !important;

                    line-height:
                        1.2 !important;

                    margin-top:
                        2px !important;

                    margin-bottom:
                        2px !important;
                }


                /* ======================================
                   HIDE WEBSITE CONTROLS
                   ====================================== */

                button,
                input,
                select,
                .btn,
                .no-print {

                    display:
                        none !important;
                }


                /* ======================================
                   HIDE FOOTER
                   ====================================== */

                footer {

                    display:
                        none !important;
                }


                /* ======================================
                   PREVENT PAGE BREAKS
                   ====================================== */

                table,
                tbody,
                tr,
                .panel,
                .panel-body,
                .panel-heading {

                    page-break-inside:
                        avoid !important;

                    break-inside:
                        avoid !important;
                }


                /* ======================================
                   REMOVE FORCED PAGE BREAKS
                   ====================================== */

                * {

                    page-break-before:
                        auto !important;

                    page-break-after:
                        auto !important;
                }
            }
        `;


        // ==============================================
        // ADD PRINT STYLE
        // ==============================================

        document.head.appendChild(
            style
        );


        // ==============================================
        // OPEN CHROME PRINT PREVIEW
        // ==============================================

        setTimeout(
            () => {

                window.print();

            },
            300
        );
    }

})();
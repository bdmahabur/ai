# Firebase Anonymous User Cleaner

Chrome Manifest V3 extension for deleting Firebase Authentication anonymous users one at a time from the currently open Firebase Console Authentication → Users page.

## Icon

The extension uses the Firebase mark as its extension and popup icon.

## Features

- Scan visible anonymous users
- Delete anonymous users one at a time
- Configurable maximum deletion count
- Maximum deletion count is saved with `chrome.storage.local`
- Configurable delay between deletions
- STOP button
- Stops automatically if the expected Firebase Console UI is not found
- Does not contain Firebase service-account credentials

## Install locally

1. Download/clone this repository.
2. Open Chrome.
3. Go to `chrome://extensions`.
4. Enable **Developer mode**.
5. Click **Load unpacked**.
6. Select this project directory.
7. Open your Firebase project.
8. Go to **Authentication → Users**.
9. Click the extension icon.
10. Click **Scan**.
11. Set the maximum number of users to delete.
12. Click **Save settings**.
13. Click **Start deletion**.

## Settings

The extension saves:

- Maximum users to delete
- Delay between users

These values are stored locally in Chrome using `chrome.storage.local`.

## Safety

The extension only targets table rows containing `(anonymous)`.

It does not use Firebase Admin credentials and does not call a Firebase backend API.

Before using a large limit, test with a small value such as 5.

## Important limitation

This version operates on the anonymous users currently rendered in the Firebase Console table. It does not automatically change Firebase Console pagination.

The Firebase Console UI is not a stable public API, so a future Firebase Console UI change may require updating the selectors in `content.js`.

(() => {
  let running = false;
  let stopRequested = false;
  let deleted = 0;

  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

  function isUsersPage() {
    const url = location.href;
    return (
      url.includes("console.firebase.google.com") &&
      /\/authentication\/users/.test(url)
    );
  }

  function getAnonymousRows() {
    return [...document.querySelectorAll('tr[role="row"]')]
      .filter(row =>
        row.innerText.trim().toLowerCase().includes("(anonymous)")
      );
  }

  function getAnonymousRow() {
    return getAnonymousRows()[0] || null;
  }

  function visible(el) {
    return !!el &&
      el.offsetParent !== null &&
      el.getClientRects().length > 0;
  }

  function sendProgress(message) {
    chrome.runtime.sendMessage({
      type: "PROGRESS",
      deleted,
      message
    }).catch(() => {});
  }

  function getMenuButton(row) {
    return [...row.querySelectorAll("button")]
      .find(button => {
        const aria = (button.getAttribute("aria-label") || "").toLowerCase();
        return aria.includes("view more options");
      });
  }

  function getMenuDeleteButton() {
    return [...document.querySelectorAll('[role="menuitem"]')]
      .find(el =>
        visible(el) &&
        el.innerText.trim().toLowerCase() === "delete account"
      );
  }

  function getConfirmationDeleteButton() {
    const overlays = [
      ...document.querySelectorAll(
        ".cdk-overlay-pane, mat-dialog-container, [role='dialog'], [role='alertdialog']"
      )
    ].filter(visible);

    for (const overlay of overlays) {
      const button = [...overlay.querySelectorAll("button")]
        .find(b =>
          visible(b) &&
          b.innerText.trim().toLowerCase() === "delete"
        );

      if (button) return button;
    }

    return [...document.querySelectorAll("button")]
      .find(b =>
        visible(b) &&
        b.innerText.trim().toLowerCase() === "delete"
      ) || null;
  }

  async function waitForMenuDelete(timeout = 3000) {
    const end = Date.now() + timeout;

    while (Date.now() < end) {
      const button = getMenuDeleteButton();
      if (button) return button;
      await sleep(100);
    }

    return null;
  }

  async function waitForConfirmationDelete(timeout = 4000) {
    const end = Date.now() + timeout;

    while (Date.now() < end) {
      const button = getConfirmationDeleteButton();
      if (button) return button;
      await sleep(100);
    }

    return null;
  }

  async function waitForRowCountToDecrease(beforeCount, timeout = 10000) {
    const end = Date.now() + timeout;

    while (Date.now() < end) {
      const currentCount = getAnonymousRows().length;

      if (currentCount < beforeCount) {
        return true;
      }

      await sleep(200);
    }

    return false;
  }

  async function deleteOneAnonymousUser(delay) {
    const beforeCount = getAnonymousRows().length;
    const row = getAnonymousRow();

    if (!row) {
      return {
        ok: false,
        reason: "No anonymous user is currently visible."
      };
    }

    const menuButton = getMenuButton(row);

    if (!menuButton) {
      return {
        ok: false,
        reason: "Could not find the View more options button."
      };
    }

    menuButton.click();

    const menuDelete = await waitForMenuDelete();

    if (!menuDelete) {
      return {
        ok: false,
        reason: "Could not find Delete account in the menu."
      };
    }

    menuDelete.click();

    const confirmDelete = await waitForConfirmationDelete();

    if (!confirmDelete) {
      return {
        ok: false,
        reason: "Could not find the confirmation Delete button."
      };
    }

    confirmDelete.click();

    const removed = await waitForRowCountToDecrease(beforeCount);

    if (!removed) {
      return {
        ok: false,
        reason: "The anonymous row did not disappear. Stopping for safety."
      };
    }

    await sleep(delay);

    return { ok: true };
  }

  async function start(maxDelete, delay) {
    if (running) {
      return {
        deleted,
        message: "A deletion run is already active."
      };
    }

    if (!isUsersPage()) {
      return {
        deleted,
        message: "Open Firebase Console → Authentication → Users first."
      };
    }

    running = true;
    stopRequested = false;
    deleted = 0;

    try {
      for (let i = 0; i < maxDelete; i++) {
        if (stopRequested) {
          return {
            deleted,
            message: `Stopped. Deleted ${deleted} user(s).`
          };
        }

        const remaining = getAnonymousRows().length;

        if (remaining === 0) {
          return {
            deleted,
            message: `Finished. No anonymous users remain on the current page. Deleted ${deleted}.`
          };
        }

        sendProgress(
          `Processing ${i + 1}/${maxDelete}. ${remaining} anonymous user(s) visible.`
        );

        const result = await deleteOneAnonymousUser(delay);

        if (!result.ok) {
          return {
            deleted,
            message: `Stopped after ${deleted}: ${result.reason}`
          };
        }

        deleted++;

        sendProgress(
          `Deleted ${deleted}/${maxDelete}.`
        );
      }

      return {
        deleted,
        message: `Finished. Deleted ${deleted} user(s).`
      };
    } finally {
      running = false;
      stopRequested = false;
    }
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "SCAN") {
      sendResponse({
        onUsersPage: isUsersPage(),
        anonymousCount: isUsersPage()
          ? getAnonymousRows().length
          : 0
      });
      return true;
    }

    if (message.type === "GET_STATE") {
      sendResponse({
        running,
        deleted
      });
      return true;
    }

    if (message.type === "STOP") {
      stopRequested = true;
      sendResponse({
        ok: true,
        message: "Stop requested."
      });
      return true;
    }

    if (message.type === "START") {
      start(
        Math.max(1, Math.min(10000, Number(message.maxDelete) || 5)),
        Math.max(1000, Math.min(30000, Number(message.delay) || 2500))
      ).then(result => {
        sendProgress(result.message);
      });

      sendResponse({
        ok: true,
        message: "Deletion started."
      });

      return true;
    }
  });
})();

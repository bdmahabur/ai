const DEFAULTS = {
  maxDelete: 5,
  delay: 2500
};

let currentTabId = null;

const $ = id => document.getElementById(id);

function setStatus(text) {
  $("statusText").textContent = text;
}

async function getSettings() {
  return await chrome.storage.local.get(DEFAULTS);
}

async function saveSettings() {
  const maxDelete = Math.max(1, Math.min(10000, Number($("maxDelete").value) || DEFAULTS.maxDelete));
  const delay = Math.max(1000, Math.min(30000, Number($("delay").value) || DEFAULTS.delay));

  $("maxDelete").value = maxDelete;
  $("delay").value = delay;

  await chrome.storage.local.set({ maxDelete, delay });

  $("saved").textContent = "Saved.";
  setTimeout(() => $("saved").textContent = "", 1200);
}

async function send(message) {
  if (!currentTabId) {
    throw new Error("No active tab.");
  }

  return await chrome.tabs.sendMessage(currentTabId, message);
}

async function refreshScan() {
  try {
    const result = await send({ type: "SCAN" });

    $("pageWarning").classList.toggle("hidden", result.onUsersPage);
    $("anonymousCount").textContent = result.anonymousCount;

    if (!result.onUsersPage) {
      setStatus("Open Firebase Console → Authentication → Users.");
    }
  } catch (e) {
    $("pageWarning").classList.remove("hidden");
    setStatus("Open the Firebase Authentication → Users page, then click Scan.");
  }
}

async function init() {
  const settings = await getSettings();

  $("maxDelete").value = settings.maxDelete;
  $("delay").value = settings.delay;

  const tabs = await chrome.tabs.query({
    active: true,
    currentWindow: true
  });

  currentTabId = tabs[0]?.id ?? null;

  await refreshScan();

  try {
    const state = await send({ type: "GET_STATE" });

    $("deletedCount").textContent = state.deleted;
    $("stop").disabled = !state.running;
    $("start").disabled = state.running;
  } catch (_) {}
}

$("save").addEventListener("click", saveSettings);

$("scan").addEventListener("click", async () => {
  setStatus("Scanning...");
  await refreshScan();
});

$("start").addEventListener("click", async () => {
  await saveSettings();

  const maxDelete = Number($("maxDelete").value);
  const delay = Number($("delay").value);

  const count = Number($("anonymousCount").textContent);

  if (!Number.isFinite(count) || count <= 0) {
    setStatus("No anonymous users are visible.");
    return;
  }

  if (!confirm(
    `Start deleting up to ${maxDelete} anonymous user(s) on the current page?`
  )) {
    return;
  }

  try {
    $("start").disabled = true;
    $("stop").disabled = false;

    const result = await send({
      type: "START",
      maxDelete,
      delay
    });

    $("deletedCount").textContent = result.deleted;
    setStatus(result.message);
  } catch (e) {
    setStatus(`Error: ${e.message}`);
  } finally {
    $("start").disabled = false;
    $("stop").disabled = true;
    await refreshScan();
  }
});

$("stop").addEventListener("click", async () => {
  try {
    await send({ type: "STOP" });
    setStatus("Stop requested.");
    $("stop").disabled = true;
  } catch (e) {
    setStatus(`Error: ${e.message}`);
  }
});

chrome.runtime.onMessage.addListener(message => {
  if (message.type === "PROGRESS") {
    $("deletedCount").textContent = message.deleted;
    setStatus(message.message);
  }
});

init();

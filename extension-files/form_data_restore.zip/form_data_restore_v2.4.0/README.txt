FORM DATA RESTORE — VERSION 2.4.0
CLOUD ID + SECRET KEY EDITION
No npm required.

IMPORTANT BEFORE PUBLISHING
The extension contains CLOUD_API_BASE in BOTH dashboard.js and background.js.
Replace:
  https://YOUR-WORKER-NAME.YOUR-SUBDOMAIN.workers.dev
with your actual deployed Cloudflare Worker URL in both files.

CLOUDFLARE SETUP
1. Create a private Cloudflare R2 bucket, e.g. form-data-restore-backups.
2. Create a Cloudflare D1 database, e.g. form-data-restore-users.
3. Open the D1 database Console and run the complete contents of d1-schema.sql.
4. Create a Worker in Cloudflare Dashboard and paste cloudflare-worker.js.
5. In Worker Settings > Bindings, add:
   - R2 bucket binding: variable name BACKUPS; select your private bucket.
   - D1 database binding: variable name USERS; select your D1 database.
6. No API_TOKEN secret is required in this edition.
7. Deploy the Worker.
8. Copy its workers.dev URL.
9. Replace CLOUD_API_BASE in dashboard.js and background.js with that URL.
10. Reload the unpacked extension.

HOW USERS CREATE AN ACCOUNT
1. Open the extension dashboard.
2. Click Create new Cloud ID.
3. The Worker generates a Cloud ID and a random Secret Key.
4. The extension saves both locally and displays them once.
5. User must click Copy my Cloud ID + Secret Key and save them in a password manager
   or another secure place. The Secret Key cannot be retrieved from the server.
6. Users can now back up and restore cloud data.

REINSTALL / NEW DEVICE
Chrome extension storage is deleted when an extension is uninstalled.
After reinstalling or installing on another device:
1. Open the Cloud Backup section.
2. Paste the previously saved Cloud ID and Secret Key.
3. Click Save / connect Cloud ID.
4. The existing cloud backup list will load.

LOST SECRET KEY
The Worker stores only a SHA-256 hash of the Secret Key, not the original key.
The key cannot be shown or recovered later. If it is lost, the user must create a
new Cloud ID. Old backups remain under the old Cloud ID and cannot be accessed
without its Secret Key. Keep the credentials safe.

CLOUD STORAGE
- R2 bucket remains private.
- Backups are isolated under users/<Cloud ID>/.
- Latest five backups are retained per Cloud ID.
- Record and website counts are calculated from actual backup JSON.
- Manual and scheduled cloud backup are supported.
- Restore merges cloud records with local-only records.

SECURITY / PRODUCTION NOTES
- The extension does not contain a shared master API token or R2 credentials.
- Each account gets an independent random Secret Key. D1 stores only its SHA-256 hash.
- The Secret Key is a bearer credential: anyone who obtains it can access that user's
  backups. Users should treat it like a password.
- Add Cloudflare rate limiting and preferably Turnstile/bot protection to POST /register
  before making the service widely public. Add per-account storage/backup quotas and
  monitoring to control abuse and R2 costs.
- CORS is not authentication. The Worker authenticates every backup/list/restore call.
- This version does not automatically migrate old v2.3.x backups stored under old
  random installation IDs. Keep the old Worker/credentials available until those
  backups have been migrated or exported.

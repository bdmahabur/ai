// ============================================================
// FORM DATA RESTORE - BACKGROUND SERVICE WORKER
// Cloud ID + Secret Key authentication
// ============================================================

const ALARM = "sfr-cloud-auto-backup";
const DEFAULT_HOURS = 6;

// IMPORTANT: Replace this URL with your deployed Cloudflare Worker URL.
const CLOUD_API_BASE = "https://YOUR-WORKER-NAME.YOUR-SUBDOMAIN.workers.dev";

async function cloudBackup() {
  const cfg = await chrome.storage.local.get([
    "sfr:cloudId",
    "sfr:cloudSecret"
  ]);

  const cloudId = String(cfg["sfr:cloudId"] || "").trim();
  const secret = String(cfg["sfr:cloudSecret"] || "").trim();

  if (!cloudId || !secret) {
    throw new Error("Create or connect your Cloud ID in the dashboard.");
  }

  if (CLOUD_API_BASE.includes("YOUR-WORKER-NAME")) {
    throw new Error("Cloud Worker URL has not been configured by the extension publisher.");
  }

  const all = await chrome.storage.local.get(null);

  const records = Object.fromEntries(
    Object.entries(all).filter(([key, value]) =>
      key.startsWith("sfr:") &&
      ![
        "sfr:cloudId",
        "sfr:cloudSecret",
        "sfr:cloudAutoEnabled",
        "sfr:cloudIntervalHours",
        "sfr:cloudLastBackupAt",
        "sfr:cloudLastBackupStatus"
      ].includes(key) &&
      value &&
      typeof value === "object"
    )
  );

  const payload = {
    format: "Form Data Restore Full Backup",
    version: 2,
    exportedAt: new Date().toISOString(),
    records
  };

  const response = await fetch(`${CLOUD_API_BASE}/backups`, {
    method: "POST",
    headers: {
      "X-Cloud-ID": cloudId,
      "Authorization": `Bearer ${secret}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify(payload)
  });

  if (!response.ok) {
    throw new Error(
      `Cloud backup failed (${response.status}): ${(await response.text()).slice(0, 180)}`
    );
  }

  const result = await response.json();

  await chrome.storage.local.set({
    "sfr:cloudLastBackupAt": result.createdAt,
    "sfr:cloudLastBackupStatus": "success"
  });

  return result;
}

async function configureAlarm() {
  const cfg = await chrome.storage.local.get([
    "sfr:cloudAutoEnabled",
    "sfr:cloudIntervalHours"
  ]);

  await chrome.alarms.clear(ALARM);

  if (cfg["sfr:cloudAutoEnabled"] !== true) return;

  const hours = Math.max(
    1,
    Math.min(168, Number(cfg["sfr:cloudIntervalHours"]) || DEFAULT_HOURS)
  );

  chrome.alarms.create(ALARM, {
    delayInMinutes: 1,
    periodInMinutes: hours * 60
  });
}

chrome.runtime.onInstalled.addListener(configureAlarm);
chrome.runtime.onStartup.addListener(configureAlarm);

chrome.storage.onChanged.addListener((changes, area) => {
  if (
    area === "local" &&
    (changes["sfr:cloudAutoEnabled"] || changes["sfr:cloudIntervalHours"])
  ) {
    configureAlarm();
  }
});

chrome.alarms.onAlarm.addListener(async alarm => {
  if (alarm.name !== ALARM) return;

  try {
    await cloudBackup();
  } catch (error) {
    await chrome.storage.local.set({
      "sfr:cloudLastBackupStatus": "error: " + String(error.message || error)
    });
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "SFR_CLOUD_BACKUP") {
    cloudBackup()
      .then(data => sendResponse({ ok: true, data }))
      .catch(error => sendResponse({
        ok: false,
        error: String(error.message || error)
      }));
    return true;
  }

  if (message?.type === "SFR_CLOUD_CONFIGURE") {
    chrome.storage.local.set({
      "sfr:cloudAutoEnabled": message.autoEnabled === true,
      "sfr:cloudIntervalHours": Number(message.intervalHours) || DEFAULT_HOURS
    })
      .then(configureAlarm)
      .then(() => sendResponse({ ok: true }))
      .catch(error => sendResponse({
        ok: false,
        error: String(error.message || error)
      }));
    return true;
  }
});

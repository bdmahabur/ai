// ============================================================
// FORM DATA RESTORE - MULTI-USER CLOUDFLARE WORKER
// Version: 2.4.0
//
// Required bindings:
//   R2 bucket: BACKUPS
//   D1 database: USERS
//
// Public routes:
//   GET  /health
//   POST /register              Create Cloud ID + Secret Key
//   GET  /backups               List backups
//   GET  /backups?id=BACKUP_ID  Download/restore backup
//   POST /backups               Upload backup
//
// No shared API_TOKEN is placed in the extension.
// ============================================================

const MAX_BACKUPS = 5;

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Authorization, Content-Type, X-Cloud-ID",
  "Access-Control-Max-Age": "86400"
};

function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      ...CORS_HEADERS,
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store"
    }
  });
}

function isValidCloudId(value) {
  return typeof value === "string" &&
    /^CLOUD-[a-f0-9-]{36}$/i.test(value);
}

function isValidBackupId(value) {
  return typeof value === "string" &&
    /^[0-9]+-[a-f0-9-]+$/i.test(value);
}

function toHex(buffer) {
  return [...new Uint8Array(buffer)]
    .map(byte => byte.toString(16).padStart(2, "0"))
    .join("");
}

function base64Url(bytes) {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary)
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/g, "");
}

async function hashSecret(secret) {
  const bytes = new TextEncoder().encode(secret);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return toHex(digest);
}

function constantTimeEqual(a, b) {
  if (typeof a !== "string" || typeof b !== "string" || a.length !== b.length) {
    return false;
  }
  let mismatch = 0;
  for (let i = 0; i < a.length; i++) {
    mismatch |= a.charCodeAt(i) ^ b.charCodeAt(i);
  }
  return mismatch === 0;
}

async function authenticate(request, env) {
  const cloudId = request.headers.get("X-Cloud-ID") || "";
  const authorization = request.headers.get("Authorization") || "";
  const secret = authorization.startsWith("Bearer ")
    ? authorization.slice(7).trim()
    : "";

  if (!isValidCloudId(cloudId) || secret.length < 40 || secret.length > 200) {
    return null;
  }

  const row = await env.USERS.prepare(
    "SELECT secret_hash FROM cloud_users WHERE cloud_id = ?1"
  ).bind(cloudId).first();

  if (!row?.secret_hash) return null;

  const suppliedHash = await hashSecret(secret);

  if (!constantTimeEqual(suppliedHash, row.secret_hash)) {
    return null;
  }

  // Update activity timestamp without blocking the request.
  await env.USERS.prepare(
    "UPDATE cloud_users SET last_used_at = ?1 WHERE cloud_id = ?2"
  ).bind(new Date().toISOString(), cloudId).run();

  return cloudId;
}

function getBackupStats(records) {
  const websites = new Set();
  let recordCount = 0;

  for (const [key, value] of Object.entries(records || {})) {
    if (
      !key.startsWith("sfr:") ||
      !value ||
      typeof value !== "object" ||
      Array.isArray(value)
    ) continue;

    recordCount++;

    try {
      const parsed = new URL(key.slice(4));
      if (parsed.protocol === "http:" || parsed.protocol === "https:") {
        const host = parsed.hostname.toLowerCase().replace(/^www\./, "");
        if (host) websites.add(host);
      }
    } catch {
      // Count record even if its URL cannot be parsed.
    }
  }

  return { recordCount, websiteCount: websites.size };
}

async function listAllBackupObjects(bucket, prefix) {
  const objects = [];
  let cursor;

  do {
    const page = await bucket.list({
      prefix,
      limit: 1000,
      include: ["customMetadata"],
      ...(cursor ? { cursor } : {})
    });

    objects.push(...page.objects.filter(item => item.key.endsWith(".json")));
    cursor = page.truncated ? page.cursor : undefined;
  } while (cursor);

  return objects;
}

async function enforceRetention(bucket, prefix) {
  const objects = await listAllBackupObjects(bucket, prefix);

  objects.sort((a, b) =>
    new Date(b.uploaded).getTime() - new Date(a.uploaded).getTime()
  );

  const obsolete = objects.slice(MAX_BACKUPS);

  for (let i = 0; i < obsolete.length; i += 1000) {
    const keys = obsolete.slice(i, i + 1000).map(item => item.key);
    if (keys.length) await bucket.delete(keys);
  }

  return {
    retained: Math.min(objects.length, MAX_BACKUPS),
    deleted: obsolete.length
  };
}

async function statsFromR2(bucket, object) {
  try {
    const stored = await bucket.get(object.key);
    if (!stored) return { recordCount: 0, websiteCount: 0 };
    const backup = await stored.json();
    return getBackupStats(backup.records || {});
  } catch {
    return { recordCount: 0, websiteCount: 0 };
  }
}

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") {
      return new Response(null, { headers: CORS_HEADERS });
    }

    if (!env.BACKUPS || !env.USERS) {
      return jsonResponse({
        error: "Missing Cloudflare bindings. Configure BACKUPS (R2) and USERS (D1)."
      }, 500);
    }

    const url = new URL(request.url);

    if (url.pathname === "/health" && request.method === "GET") {
      return jsonResponse({
        ok: true,
        service: "Form Data Restore Cloud",
        version: "2.4.0",
        maxBackups: MAX_BACKUPS,
        accountSystem: "Cloud ID + Secret Key"
      });
    }

    // --------------------------------------------------------
    // CREATE ACCOUNT: issue a Cloud ID and one-time Secret Key
    // --------------------------------------------------------
    if (url.pathname === "/register" && request.method === "POST") {
      // A simple registration endpoint is public. Add Cloudflare
      // rate limiting / Turnstile before a large public launch.
      const cloudId = `CLOUD-${crypto.randomUUID()}`;
      const randomSecret = new Uint8Array(32);
      crypto.getRandomValues(randomSecret);
      const secretKey = `sfr_${base64Url(randomSecret)}`;
      const secretHash = await hashSecret(secretKey);
      const createdAt = new Date().toISOString();

      try {
        await env.USERS.prepare(
          "INSERT INTO cloud_users (cloud_id, secret_hash, created_at, last_used_at) VALUES (?1, ?2, ?3, ?3)"
        ).bind(cloudId, secretHash, createdAt).run();
      } catch (error) {
        return jsonResponse({ error: "Could not create Cloud ID. Please try again." }, 500);
      }

      // Secret is returned once. Only its hash is stored in D1.
      return jsonResponse({
        ok: true,
        cloudId,
        secretKey,
        createdAt,
        warning: "Save your Secret Key now. It cannot be displayed again."
      }, 201);
    }

    if (url.pathname !== "/backups") {
      return jsonResponse({ error: "Not found" }, 404);
    }

    const cloudId = await authenticate(request, env);

    if (!cloudId) {
      return jsonResponse({
        error: "Invalid Cloud ID or Secret Key. Check your saved credentials."
      }, 401);
    }

    // Each Cloud ID gets a separate private R2 prefix.
    const prefix = `users/${cloudId}/`;

    // --------------------------------------------------------
    // UPLOAD BACKUP
    // --------------------------------------------------------
    if (request.method === "POST") {
      const body = await request.json().catch(() => null);

      if (
        !body ||
        body.format !== "Form Data Restore Full Backup" ||
        !body.records ||
        typeof body.records !== "object" ||
        Array.isArray(body.records)
      ) {
        return jsonResponse({ error: "Invalid backup payload" }, 400);
      }

      const cleanRecords = {};

      for (const [key, value] of Object.entries(body.records)) {
        if (
          key.startsWith("sfr:") &&
          value &&
          typeof value === "object" &&
          !Array.isArray(value)
        ) {
          cleanRecords[key] = value;
        }
      }

      const stats = getBackupStats(cleanRecords);
      const id = `${Date.now()}-${crypto.randomUUID()}`;
      const createdAt = new Date().toISOString();
      const objectKey = `${prefix}${id}.json`;

      const backup = {
        id,
        createdAt,
        format: "Form Data Restore Full Backup",
        version: 2,
        recordCount: stats.recordCount,
        websiteCount: stats.websiteCount,
        records: cleanRecords
      };

      await env.BACKUPS.put(objectKey, JSON.stringify(backup), {
        httpMetadata: { contentType: "application/json" },
        customMetadata: {
          createdAt,
          recordCount: String(stats.recordCount),
          websiteCount: String(stats.websiteCount)
        }
      });

      let retention;

      try {
        retention = await enforceRetention(env.BACKUPS, prefix);
      } catch {
        return jsonResponse({
          ok: true,
          id,
          createdAt,
          recordCount: stats.recordCount,
          websiteCount: stats.websiteCount,
          retentionWarning: "Backup uploaded, but old-backup cleanup failed."
        });
      }

      return jsonResponse({
        ok: true,
        id,
        createdAt,
        recordCount: stats.recordCount,
        websiteCount: stats.websiteCount,
        retention: {
          maximum: MAX_BACKUPS,
          retained: retention.retained,
          deleted: retention.deleted
        }
      });
    }

    // --------------------------------------------------------
    // LIST BACKUPS OR RESTORE ONE
    // --------------------------------------------------------
    if (request.method === "GET") {
      const backupId = url.searchParams.get("id");

      if (backupId) {
        if (!isValidBackupId(backupId)) {
          return jsonResponse({ error: "Invalid backup ID" }, 400);
        }

        const object = await env.BACKUPS.get(`${prefix}${backupId}.json`);

        if (!object) {
          return jsonResponse({ error: "Backup not found" }, 404);
        }

        return new Response(object.body, {
          headers: {
            ...CORS_HEADERS,
            "Content-Type": "application/json; charset=utf-8",
            "Cache-Control": "no-store"
          }
        });
      }

      let retentionWarning = null;

      try {
        await enforceRetention(env.BACKUPS, prefix);
      } catch {
        retentionWarning = "Could not complete old-backup cleanup.";
      }

      const objects = await listAllBackupObjects(env.BACKUPS, prefix);

      objects.sort((a, b) =>
        new Date(b.uploaded).getTime() - new Date(a.uploaded).getTime()
      );

      const latestFive = objects.slice(0, MAX_BACKUPS);
      const backups = [];

      for (const object of latestFive) {
        const stats = await statsFromR2(env.BACKUPS, object);

        backups.push({
          id: object.key.slice(prefix.length).replace(/\.json$/, ""),
          createdAt: object.customMetadata?.createdAt || object.uploaded.toISOString(),
          size: object.size,
          recordCount: stats.recordCount,
          websiteCount: stats.websiteCount
        });
      }

      return jsonResponse({
        backups,
        total: backups.length,
        maxBackups: MAX_BACKUPS,
        retentionWarning
      });
    }

    return jsonResponse({ error: "Method not allowed" }, 405);
  }
};

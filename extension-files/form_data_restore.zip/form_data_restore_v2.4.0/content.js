(() => {
  if (window.__shopFormRecoveryLoadedV2) return;
  window.__shopFormRecoveryLoadedV2 = true;

  const PREFIX = "sfr:";
  const ENABLE_KEY = "sfr:globalEnabled";
  const AUTOSAVE_KEY = "sfr:autoSaveEnabled";
  const pageKey = (() => {
    try { const u = new URL(location.href); return PREFIX + u.origin + u.pathname; }
    catch { return PREFIX + location.hostname; }
  })();
  const excludedType = new Set(["password","hidden","file","submit","button","reset","image"]);
  const sensitiveWords = /pass(word)?|otp|one.?time|pin|cvv|cvc|card.?number|credit.?card|debit.?card|security.?code|secret|token|captcha|auth.?code/i;

  let enabled = true; // Global extension switch.
  let autoSaveEnabled = true; // Independent auto-save switch; default ON.
  let timer = null;
  let restoreTimer = null;
  let restoreBar = null;

  function isSafe(el) {
    if (!(el instanceof HTMLElement)) return false;
    const tag = el.tagName.toLowerCase();
    if (!["input","textarea","select"].includes(tag) || el.disabled || el.readOnly) return false;
    if (tag === "input" && excludedType.has((el.type || "text").toLowerCase())) return false;
    const meta = [el.name,el.id,el.autocomplete,el.getAttribute("aria-label"),el.placeholder].join(" ");
    if (sensitiveWords.test(meta)) return false;
    if (el.closest("[autocomplete='cc-number'],[autocomplete='cc-csc'],[autocomplete='current-password'],[autocomplete='new-password']")) return false;
    return true;
  }
  function esc(s) { return window.CSS?.escape ? CSS.escape(s) : String(s).replace(/[^a-zA-Z0-9_-]/g,"\\$&"); }
  function selectorFor(el) {
    if (el.id) return `#${esc(el.id)}`;
    if (el.name) {
      const tag=el.tagName.toLowerCase(), list=[...document.querySelectorAll(`${tag}[name="${String(el.name).replace(/\\/g,"\\\\").replace(/"/g,'\\"')}"]`)];
      const idx=list.indexOf(el);
      return `${tag}[name="${String(el.name).replace(/\\/g,"\\\\").replace(/"/g,'\\"')}"]${list.length>1?`:nth-of-type(${idx+1})`:""}`;
    }
    const parts=[]; let node=el;
    while(node && node!==document.body && parts.length<6){
      let p=node.tagName.toLowerCase(); const parent=node.parentElement;
      if(node.id){parts.unshift(`#${esc(node.id)}`);break;}
      if(parent){const siblings=[...parent.children].filter(x=>x.tagName===node.tagName);if(siblings.length>1)p+=`:nth-of-type(${siblings.indexOf(node)+1})`;}
      parts.unshift(p);node=parent;
    }
    return parts.join(" > ");
  }
  function fieldValue(el) {
    const t=(el.type||"").toLowerCase();
    if(t==="checkbox") return {kind:"checkbox",value:!!el.checked};
    if(t==="radio") return {kind:"radio",value:!!el.checked};
    if(el.tagName==="SELECT"&&el.multiple) return {kind:"multiple",value:[...el.options].filter(o=>o.selected).map(o=>o.value)};
    return {kind:"value",value:el.value};
  }
  function collect() {
    return {
      pageKey, url:location.href.split("#")[0], title:document.title||location.hostname,
      savedAt:Date.now(),
      fields:[...document.querySelectorAll("input,textarea,select")].filter(isSafe).slice(0,800).map(el=>({
        selector:selectorFor(el),tag:el.tagName.toLowerCase(),type:(el.type||"").toLowerCase(),
        name:el.name||"",id:el.id||"",...fieldValue(el)
      }))
    };
  }
  async function getRecord(){const d=await chrome.storage.local.get(pageKey);return d[pageKey]||{auto:null,saved:[]};}
  async function saveAuto(){
    if (!enabled || !autoSaveEnabled) return;
    const rec=await getRecord();rec.auto=collect();await chrome.storage.local.set({[pageKey]:rec});
    announce("Draft saved");
  }
  function schedule(){if (!enabled || !autoSaveEnabled) return;clearTimeout(timer);timer=setTimeout(()=>saveAuto().catch(()=>{}),450);}
  function findField(f){
    try{const el=f.selector?document.querySelector(f.selector):null;if(el&&isSafe(el))return el;}catch{}
    if(f.id){const el=document.getElementById(f.id);if(el&&isSafe(el))return el;}
    if(f.name){const a=[...document.querySelectorAll("input,textarea,select")].filter(x=>isSafe(x)&&x.name===f.name);if(a.length===1)return a[0];}
    return null;
  }
  function apply(snapshot){
    if(!snapshot||!Array.isArray(snapshot.fields))return {restored:0,skipped:0};
    let restored=0,skipped=0;
    for(const f of snapshot.fields){
      const el=findField(f);if(!el){skipped++;continue;}
      try{
        if(f.kind==="checkbox")el.checked=!!f.value;
        else if(f.kind==="radio"){if(f.value)el.checked=true;}
        else if(f.kind==="multiple"&&el.tagName==="SELECT"){const v=new Set(f.value||[]);[...el.options].forEach(o=>o.selected=v.has(o.value));}
        else if("value" in f)el.value=f.value??"";
        el.dispatchEvent(new Event("input",{bubbles:true}));
        el.dispatchEvent(new Event("change",{bubbles:true}));restored++;
      }catch{skipped++;}
    }
    return {restored,skipped};
  }
  function announce(msg){
    let n=document.getElementById("__sfr_status_v2");
    if(!n){n=document.createElement("div");n.id="__sfr_status_v2";n.style.cssText="position:fixed;right:16px;bottom:16px;z-index:2147483647;background:#172033;color:#fff;padding:9px 13px;border-radius:8px;font:13px Arial;box-shadow:0 3px 14px #0005;opacity:0;transition:opacity .2s;pointer-events:none";document.documentElement.append(n);}
    n.textContent=msg;n.style.opacity="1";clearTimeout(n._t);n._t=setTimeout(()=>n.style.opacity="0",1800);
  }
  function onInput(e){if(isSafe(e.target))schedule();}
  function onChange(e){if(isSafe(e.target))schedule();}

  function checkRestorePrompt() {
    clearTimeout(restoreTimer);
    restoreTimer = setTimeout(async()=>{
      if (!enabled) return;
      try{
        const rec=await getRecord(),snap=rec.auto;if(!snap?.fields?.length)return;
        const current=collect();
        const populated=current.fields.some(f=>f.kind==="checkbox"||f.kind==="radio"?!!f.value:f.kind==="multiple"?f.value?.length:String(f.value||"").length>0);
        if(Date.now()-(snap.savedAt||0)>2500&&!populated){
          if (restoreBar?.isConnected) restoreBar.remove();
          const bar=document.createElement("div");
          bar.style.cssText="position:fixed;top:12px;right:12px;z-index:2147483647;background:#172033;color:white;padding:12px;border-radius:10px;box-shadow:0 5px 22px #0005;font:13px Arial;max-width:340px;display:flex;gap:10px;align-items:center";
          const label=document.createElement("span");label.textContent=`Saved form found (${snap.fields.length} fields). Restore?`;
          const yes=document.createElement("button");yes.textContent="Restore";yes.style.cssText="border:0;border-radius:6px;padding:7px 10px;background:#22c55e;color:#06210f;font-weight:bold;cursor:pointer";
          yes.onclick=()=>{if(!enabled)return;const r=apply(snap);bar.remove();announce(`Restored ${r.restored} fields`);};
          const no=document.createElement("button");no.textContent="×";no.style.cssText="border:0;background:transparent;color:white;font-size:18px;cursor:pointer";no.onclick=()=>bar.remove();
          bar.append(label,yes,no);document.documentElement.append(bar);restoreBar=bar;
        }
      }catch{}
    },1200);
  }

  function startMonitoring() {
    if (enabled) return;
    enabled = true;
    document.addEventListener("input",onInput,true);
    document.addEventListener("change",onChange,true);
    checkRestorePrompt();
  }
  function stopMonitoring() {
    enabled = false;
    clearTimeout(timer); clearTimeout(restoreTimer);
    document.removeEventListener("input",onInput,true);
    document.removeEventListener("change",onChange,true);
    if (restoreBar?.isConnected) restoreBar.remove();
    restoreBar = null;
  }

  chrome.runtime.onMessage.addListener((msg,sender,reply)=>{
    if(msg?.type==="SFR_STATUS"){reply({ok:true,active:enabled});return true;}
    if(msg?.type==="SFR_CAPTURE"){
      if (!enabled) { reply({ok:false,error:"Extension is OFF. Turn it ON first."}); return true; }
      const snap=collect();getRecord().then(r=>{r.auto=snap;return chrome.storage.local.set({[pageKey]:r});})
        .then(()=>reply({ok:true,snapshot:snap})).catch(e=>reply({ok:false,error:String(e)}));return true;
    }
    if(msg?.type==="SFR_RESTORE"){
      if (!enabled) { reply({ok:false,error:"Extension is OFF. Turn it ON first."}); return true; }
      const r=apply(msg.snapshot);announce(`Restored ${r.restored} fields`);reply({ok:true,...r});return true;
    }
    if(msg?.type==="SFR_PAGE_INFO"){reply({pageKey,title:document.title||location.hostname,url:location.href});return true;}
  });

  document.addEventListener("input",onInput,true);
  document.addEventListener("change",onChange,true);
  chrome.storage.onChanged.addListener((changes,area)=>{
    if(area!=="local") return;
    if(changes[ENABLE_KEY]){
      const next = changes[ENABLE_KEY].newValue !== false;
      if(next) startMonitoring(); else stopMonitoring();
    }
    if(changes[AUTOSAVE_KEY]){
      autoSaveEnabled = changes[AUTOSAVE_KEY].newValue !== false;
      if(!autoSaveEnabled) clearTimeout(timer);
    }
  });

  chrome.storage.local.get([ENABLE_KEY,AUTOSAVE_KEY]).then(data=>{
    enabled = data[ENABLE_KEY] !== false;
    autoSaveEnabled = data[AUTOSAVE_KEY] !== false;
    if(enabled){checkRestorePrompt();}
    else stopMonitoring();
  }).catch(()=>{enabled=true;autoSaveEnabled=true;checkRestorePrompt();});
})();

-- Run once in your Cloudflare D1 database console.
CREATE TABLE IF NOT EXISTS cloud_users (
  cloud_id TEXT PRIMARY KEY,
  secret_hash TEXT NOT NULL,
  created_at TEXT NOT NULL,
  last_used_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_cloud_users_created_at
ON cloud_users(created_at);


const PREFIX="sfr:",$=id=>document.getElementById(id);let allRecords=[];let currentPage=1;let pageSize=10;
const fmt=t=>new Date(t||Date.now()).toLocaleString();
function safeText(s){return String(s??"");}
async function readAll(){
 const data=await chrome.storage.local.get(null);
 allRecords=Object.entries(data).filter(([k,v])=>k.startsWith(PREFIX)&&v&&typeof v==="object").map(([key,record])=>({key,record}));
 render();
}
function buildItems(){
 const items=[];
 for(const {key,record} of allRecords){
  const auto=record.auto;
  if(auto?.fields?.length)items.push({key,type:"auto",name:"Automatic draft",snapshot:auto,id:"auto",count:auto.fields.length,when:auto.savedAt||0,title:auto.title||key,url:auto.url||""});
  (Array.isArray(record.saved)?record.saved:[]).forEach(s=>{
   if(s?.snapshot)items.push({key,type:"named",name:s.name||"Unnamed session",snapshot:s.snapshot,id:s.id,count:s.snapshot.fields?.length||0,when:s.snapshot.savedAt||0,title:s.snapshot.title||key,url:s.snapshot.url||""});
  });
 }
 return items.sort((a,b)=>b.when-a.when);
}
function render(){
 const items=buildItems(),q=$("search").value.trim().toLowerCase(),filter=$("filter").value;
 const sites=new Set(items.map(x=>{
  try{
   const raw=x.snapshot?.url||x.key.slice(PREFIX.length);
   const host=new URL(raw).hostname.toLowerCase().replace(/^www\./,"");
   return host||x.key;
  }catch{
   try{
    const host=new URL("https://"+x.key.slice(PREFIX.length)).hostname.toLowerCase().replace(/^www\./,"");
    return host||x.key;
   }catch{return x.key;}
  }
 }));
 $("countSessions").textContent=items.filter(x=>x.type==="named").length;
 $("countDrafts").textContent=items.filter(x=>x.type==="auto").length;
 $("countSites").textContent=sites.size;
 $("countFields").textContent=items.reduce((n,x)=>n+x.count,0);

 const visible=items.filter(x=>(filter==="all"||filter===x.type)&&[x.name,x.title,x.url,x.key].join(" ").toLowerCase().includes(q));
 const totalPages=Math.max(1,Math.ceil(visible.length/pageSize));
 currentPage=Math.min(currentPage,totalPages);
 const pageItems=visible.slice((currentPage-1)*pageSize,currentPage*pageSize);
 const host=$("records");host.innerHTML="";
 if(!visible.length){
  host.innerHTML='<div class="empty">No saved forms match your search.</div>';
  renderPagination(0,0);
  return;
 }
 const groups=new Map();
 pageItems.forEach(item=>{if(!groups.has(item.key))groups.set(item.key,[]);groups.get(item.key).push(item);});
 for(const [key,list] of groups){
  const section=document.createElement("section");section.className="group";
  const head=document.createElement("div");head.className="group-head";
  const label=document.createElement("strong");label.textContent=list[0].title||key;
  const sub=document.createElement("small");sub.textContent=`${list.length} saved item${list.length===1?"":"s"} · ${key.replace(PREFIX,"")}`;
  head.append(label,sub);section.append(head);
  list.forEach(item=>{
   const row=document.createElement("div");row.className="entry";
   const info=document.createElement("div");info.className="entry-info";
   const name=document.createElement("strong");name.textContent=item.name;
   const meta=document.createElement("small");meta.textContent=`${item.count} fields · ${fmt(item.when)}${item.url?" · "+item.url:""}`;
   const tag=document.createElement("span");tag.className="tag";tag.textContent=item.type==="auto"?"Auto draft":"Customer session";
   info.append(tag,name,meta);
   const actions=document.createElement("div");actions.className="entry-actions";
   const restore=document.createElement("button");restore.textContent="Restore";restore.onclick=()=>restoreItem(item);
   const exportOne=document.createElement("button");exportOne.textContent="Export";exportOne.onclick=()=>download({format:"Shop Form Recovery Backup",version:2,exportedAt:new Date().toISOString(),records:{[item.key]:allRecords.find(x=>x.key===item.key).record}},`form-data-restore-${item.type}-backup.json`);
   const del=document.createElement("button");del.className="danger";del.textContent="Delete";del.onclick=()=>deleteItem(item);
   actions.append(restore,exportOne,del);row.append(info,actions);section.append(row);
  });
  host.append(section);
 }
 renderPagination(visible.length,totalPages);
}
function renderPagination(total,totalPages){
 const host=$("pagination");
 if(!host)return;
 host.innerHTML="";
 if(total===0)return;
 const start=(currentPage-1)*pageSize+1;
 const end=Math.min(currentPage*pageSize,total);
 const info=document.createElement("span");
 info.className="pagination-info";
 info.textContent=`Showing ${start}–${end} of ${total} saved items`;
 const controls=document.createElement("div");
 controls.className="pagination-controls";
 const sizeLabel=document.createElement("label");
 sizeLabel.textContent="Per page ";
 const size=document.createElement("select");
 [10,15,20,25].forEach(n=>{
  const option=document.createElement("option");
  option.value=String(n);option.textContent=String(n);
  option.selected=n===pageSize;size.append(option);
 });
 size.onchange=async()=>{
  pageSize=Number(size.value)||10;currentPage=1;
  await chrome.storage.local.set({"sfr:dashboardPageSize":pageSize});
  render();
 };
 sizeLabel.append(size);
 const previous=document.createElement("button");
 previous.textContent="Previous";previous.disabled=currentPage<=1;
 previous.onclick=()=>{currentPage--;render();};
 const page=document.createElement("button");
 page.className="page-current";page.textContent=`${currentPage} / ${totalPages}`;page.disabled=true;
 const next=document.createElement("button");
 next.textContent="Next";next.disabled=currentPage>=totalPages;
 next.onclick=()=>{currentPage++;render();};
 controls.append(sizeLabel,previous,page,next);
 host.append(info,controls);
}
async function restoreItem(item){
 let tabs=await chrome.tabs.query({active:true,currentWindow:true}),tab=tabs[0];
 try{
  if(!tab?.url||!tab.url.startsWith(new URL(item.url).origin)){
   tab=await chrome.tabs.create({url:item.url,active:true});
   await new Promise(resolve=>setTimeout(resolve,1300));
  }else if(new URL(tab.url).origin+new URL(tab.url).pathname!==new URL(item.url).origin+new URL(item.url).pathname){
   tab=await chrome.tabs.create({url:item.url,active:true});
   await new Promise(resolve=>setTimeout(resolve,1300));
  }
  let result;
  for(let i=0;i<5;i++){
   try{result=await chrome.tabs.sendMessage(tab.id,{type:"SFR_RESTORE",snapshot:item.snapshot});break;}
   catch{await new Promise(resolve=>setTimeout(resolve,700));}
  }
  if(!result)throw Error("Could not connect to the page. Refresh it and try again.");
  alert(`Restored ${result.restored} fields. ${result.skipped} fields could not be matched. Review the form before submitting.`);
 }catch(e){alert("Restore failed: "+(e.message||"Open the saved website and try again."));}
}
function confirmDialog(title,message,confirmLabel="Delete"){
 return new Promise(resolve=>{
  const dialog=$("confirmDialog"),titleEl=$("confirmTitle"),messageEl=$("confirmMessage"),confirmBtn=$("confirmDelete"),cancelBtn=$("cancelDelete");
  titleEl.textContent=title;messageEl.textContent=message;confirmBtn.textContent=confirmLabel;
  const cleanup=value=>{dialog.close();confirmBtn.removeEventListener("click",yes);cancelBtn.removeEventListener("click",no);dialog.removeEventListener("cancel",onCancel);resolve(value);};
  const yes=()=>cleanup(true),no=()=>cleanup(false),onCancel=e=>{e.preventDefault();no();};
  confirmBtn.addEventListener("click",yes);cancelBtn.addEventListener("click",no);dialog.addEventListener("cancel",onCancel);dialog.showModal();cancelBtn.focus();
 });
}
async function deleteItem(item){
 if(!await confirmDialog("Delete saved form?",`“${item.name}” will be permanently removed from this Chrome profile.`))return;
 const d=await chrome.storage.local.get(item.key),r=d[item.key]||{auto:null,saved:[]};
 if(item.type==="auto")r.auto=null;else r.saved=(r.saved||[]).filter(s=>s.id!==item.id);
 if(!r.auto&&!r.saved.length)await chrome.storage.local.remove(item.key);else await chrome.storage.local.set({[item.key]:r});
 await readAll();
}
function download(obj,name){
 const blob=new Blob([JSON.stringify(obj,null,2)],{type:"application/json"}),url=URL.createObjectURL(blob),a=document.createElement("a");
 a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
$("refresh").onclick=readAll;$("search").oninput=()=>{currentPage=1;render();};$("filter").onchange=()=>{currentPage=1;render();};
$("exportAll").onclick=()=>download({format:"Form Data Restore Full Backup",version:2,exportedAt:new Date().toISOString(),records:Object.fromEntries(allRecords.map(x=>[x.key,x.record]))},"form-data-restore-full-backup.json");
$("importAll").onchange=async e=>{
 const f=e.target.files[0];if(!f)return;
 try{
  const obj=JSON.parse(await f.text()),records=obj.records;
  if(!records||typeof records!=="object")throw Error();
  const clean={};for(const [k,v] of Object.entries(records)){if(k.startsWith(PREFIX)&&v&&typeof v==="object")clean[k]=v;}
  await chrome.storage.local.set(clean);await readAll();alert(`Imported ${Object.keys(clean).length} website record(s).`);
 }catch{alert("This backup file is invalid or unsupported.");}
 e.target.value="";
};
$("deleteAll").onclick=async()=>{
 if(!allRecords.length)return;
 if(!await confirmDialog("Delete all saved data?","All saved forms and customer sessions in this Chrome profile will be permanently deleted. Export a backup first if you may need this data.","Delete all"))return;
 const keys=allRecords.map(x=>x.key);if(keys.length)await chrome.storage.local.remove(keys);await readAll();
};
$("saveCurrent").onclick=async()=>{
 const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
 if(!tab?.url||!/^https?:/.test(tab.url)){alert("Open a normal website first.");return;}
 try{
  const r=await chrome.tabs.sendMessage(tab.id,{type:"SFR_CAPTURE"});
  if(!r?.ok)throw Error();
  await readAll();alert(`Saved ${r.snapshot.fields.length} fields from the current tab.`);
 }catch{alert("Could not read this page. Refresh it and try again.");}
};
// Restore the user's preferred page size from extension local storage.
chrome.storage.local.get("sfr:dashboardPageSize").then(data=>{
 const saved=Number(data["sfr:dashboardPageSize"]);
 pageSize=[10,15,20,25].includes(saved)?saved:10;
 render();
}).catch(()=>{pageSize=10;render();});

// Settings modal controls
$("openSettings").onclick=()=> $("settingsModal").showModal();
$("closeSettings").onclick=()=> $("settingsModal").close();
$("settingsModal").addEventListener("click",event=>{
 if(event.target===$("settingsModal")) $("settingsModal").close();
});

readAll().catch(e=>{ $("records").textContent="Could not load local saved data."; });


// ============================================================
// CLOUD BACKUP - CLOUD ID + SECRET KEY ACCOUNT SYSTEM
// Set this once to your deployed Cloudflare Worker URL.
// ============================================================

const CLOUD_API_BASE = "https://YOUR-WORKER-NAME.YOUR-SUBDOMAIN.workers.dev";

const CLOUD_KEYS = [
 "sfr:cloudId",
 "sfr:cloudSecret",
 "sfr:cloudAutoEnabled",
 "sfr:cloudIntervalHours",
 "sfr:cloudLastBackupAt",
 "sfr:cloudLastBackupStatus"
];

const cloud$ = id => document.getElementById(id);

function cloudSay(message, bad = false) {
 const node = cloud$("cloudMessage");
 node.textContent = message;
 node.style.color = bad ? "#b42318" : "#64748b";
}

async function cloudConfig() {
 return chrome.storage.local.get(CLOUD_KEYS);
}

function cloudCredentialsFromUI() {
 return {
  cloudId: cloud$("cloudId").value.trim(),
  secret: cloud$("cloudSecret").value.trim()
 };
}

async function cloudRequest(path, options = {}) {
 const cfg = await cloudConfig();
 const cloudId = String(cfg["sfr:cloudId"] || "").trim();
 const secret = String(cfg["sfr:cloudSecret"] || "").trim();

 if (!cloudId || !secret) {
  throw Error("Create a Cloud ID or enter your existing Cloud ID and Secret Key first.");
 }

 if (CLOUD_API_BASE.includes("YOUR-WORKER-NAME")) {
  throw Error("Extension setup incomplete: replace CLOUD_API_BASE in dashboard.js and background.js with your deployed Worker URL.");
 }

 const url = new URL(path, CLOUD_API_BASE);
 const response = await fetch(url, {
  ...options,
  headers: {
   ...(options.headers || {}),
   "X-Cloud-ID": cloudId,
   "Authorization": `Bearer ${secret}`,
   "Content-Type": "application/json"
  }
 });

 if (!response.ok) {
  const message = await response.text();
  throw Error(`Cloud request failed (${response.status}): ${message.slice(0, 220)}`);
 }

 return response.json();
}

async function createCloudAccount() {
 const button = cloud$("createCloudAccount");
 button.disabled = true;

 try {
  if (CLOUD_API_BASE.includes("YOUR-WORKER-NAME")) {
   throw Error("Set your deployed Worker URL in CLOUD_API_BASE in dashboard.js and background.js first.");
  }

  cloudSay("Creating your Cloud ID and Secret Key…");

  const response = await fetch(new URL("/register", CLOUD_API_BASE), {
   method: "POST",
   headers: { "Content-Type": "application/json" },
   body: JSON.stringify({})
  });

  const result = await response.json();

  if (!response.ok || !result.ok) {
   throw Error(result.error || "Could not create Cloud ID.");
  }

  cloud$("cloudId").value = result.cloudId;
  cloud$("cloudSecret").value = result.secretKey;

  await chrome.storage.local.set({
   "sfr:cloudId": result.cloudId,
   "sfr:cloudSecret": result.secretKey
  });

  cloud$("newCloudId").textContent = result.cloudId;
  cloud$("newCloudSecret").textContent = result.secretKey;
  cloud$("newCloudCredentials").hidden = false;
  cloud$("cloudStatus").textContent = "Cloud ID created";

  cloudSay("Cloud ID created. Copy and safely save BOTH credentials before leaving this page.");
 } catch (error) {
  cloudSay(error.message, true);
 } finally {
  button.disabled = false;
 }
}

async function connectCloudAccount() {
 const { cloudId, secret } = cloudCredentialsFromUI();

 if (!/^CLOUD-[a-f0-9-]{36}$/i.test(cloudId)) {
  throw Error("Enter a valid Cloud ID.");
 }

 if (!/^sfr_[A-Za-z0-9_-]{40,60}$/.test(secret)) {
  throw Error("Enter the complete Secret Key.");
 }

 await chrome.storage.local.set({
  "sfr:cloudId": cloudId,
  "sfr:cloudSecret": secret
 });

 // Verify credentials by requesting the backup list.
 await loadCloudBackups();

 cloud$("cloudStatus").textContent = "Connected";
 cloudSay("Cloud ID connected. Your cloud backups are available.");
}

async function copyCloudCredentials() {
 const { cloudId, secret } = cloudCredentialsFromUI();

 if (!cloudId || !secret) {
  throw Error("Create or enter your Cloud ID and Secret Key first.");
 }

 const text = `Form Data Restore Cloud Credentials\nCloud ID: ${cloudId}\nSecret Key: ${secret}\n\nKeep these credentials private.`;
 await navigator.clipboard.writeText(text);
 cloudSay("Cloud ID and Secret Key copied. Save them somewhere secure.");
}

function localBackupPayload() {
 const records = Object.fromEntries(allRecords.map(item => [item.key, item.record]));
 return {
  format: "Form Data Restore Full Backup",
  version: 2,
  exportedAt: new Date().toISOString(),
  records
 };
}

async function runCloudBackup() {
 await readAll();
 cloudSay("Uploading local records to your cloud…");

 const result = await cloudRequest("/backups", {
  method: "POST",
  body: JSON.stringify(localBackupPayload())
 });

 await chrome.storage.local.set({
  "sfr:cloudLastBackupAt": result.createdAt,
  "sfr:cloudLastBackupStatus": "success"
 });

 cloudSay(`Cloud backup completed: ${result.websiteCount ?? 0} websites, ${result.recordCount ?? 0} records saved at ${fmt(result.createdAt)}.`);
 await loadCloudBackups();
}

async function loadCloudBackups() {
 const select = cloud$("cloudBackupList");
 select.innerHTML = '<option value="">Loading backups…</option>';

 const result = await cloudRequest("/backups");

 select.innerHTML = "";

 if (!result.backups?.length) {
  select.innerHTML = '<option value="">No cloud backups found</option>';
  cloudSay("Connected successfully. No cloud backups exist yet.");
  return;
 }

 for (const backup of result.backups) {
  const option = document.createElement("option");
  option.value = backup.id;
  option.textContent =
   `${new Date(backup.createdAt).toLocaleString()} · ` +
   `${Number(backup.websiteCount ?? 0)} websites · ` +
   `${Number(backup.recordCount ?? 0)} records · ` +
   `${(backup.size / 1024).toFixed(1)} KB`;
  select.append(option);
 }

 cloudSay(`${result.backups.length} cloud backup(s) available.`);
}

function mergeCloudRecords(local, remote) {
 const merged = { ...local };

 for (const [key, cloudRecord] of Object.entries(remote || {})) {
  if (!key.startsWith(PREFIX) || !cloudRecord || typeof cloudRecord !== "object") continue;

  const current = merged[key] && typeof merged[key] === "object"
   ? merged[key]
   : { auto: null, saved: [] };

  const a = current.auto;
  const b = cloudRecord.auto;
  const auto = (!a || ((b?.savedAt || 0) > (a?.savedAt || 0))) ? b : a;

  const savedMap = new Map();

  for (const item of [
   ...(Array.isArray(current.saved) ? current.saved : []),
   ...(Array.isArray(cloudRecord.saved) ? cloudRecord.saved : [])
  ]) {
   if (item?.id) savedMap.set(item.id, item);
  }

  merged[key] = {
   ...current,
   ...cloudRecord,
   auto: auto || null,
   saved: [...savedMap.values()].sort(
    (x, y) => (y.snapshot?.savedAt || 0) - (x.snapshot?.savedAt || 0)
   )
  };
 }

 return merged;
}

async function restoreCloudBackup() {
 const id = cloud$("cloudBackupList").value;

 if (!id) throw Error("Select a cloud backup first.");

 if (!await confirmDialog(
  "Restore cloud backup?",
  "Cloud records will be merged with local records. Newer local automatic drafts are kept, and local-only records are preserved.",
  "Restore"
 )) return;

 cloudSay("Downloading and merging cloud backup…");

 const backup = await cloudRequest(`/backups?id=${encodeURIComponent(id)}`);

 if (!backup.records || typeof backup.records !== "object") {
  throw Error("Cloud backup data is invalid.");
 }

 const local = await chrome.storage.local.get(null);
 const merged = mergeCloudRecords(local, backup.records);

 const writes = Object.fromEntries(
  Object.entries(merged).filter(
   ([key, value]) => key.startsWith(PREFIX) && value && typeof value === "object"
  )
 );

 await chrome.storage.local.set(writes);
 await readAll();

 cloudSay(`Restore completed. Merged ${Object.keys(backup.records).length} records. Local-only records were preserved.`);
}

async function initCloudPanel() {
 try {
  const cfg = await cloudConfig();

  cloud$("cloudId").value = cfg["sfr:cloudId"] || "";
  cloud$("cloudSecret").value = cfg["sfr:cloudSecret"] || "";
  cloud$("cloudAuto").checked = cfg["sfr:cloudAutoEnabled"] === true;
  cloud$("cloudInterval").value = String(cfg["sfr:cloudIntervalHours"] || 6);

  const status = cfg["sfr:cloudLastBackupStatus"];
  cloud$("cloudStatus").textContent =
   status === "success" ? "Last backup successful" :
   status?.startsWith("error:") ? "Last backup failed" :
   (cfg["sfr:cloudId"] ? "Credentials saved" : "Not connected");

  if (cfg["sfr:cloudLastBackupAt"]) {
   cloudSay(`Last successful cloud backup: ${fmt(cfg["sfr:cloudLastBackupAt"])}.`);
  }
 } catch (error) {
  cloudSay(error.message, true);
 }
}

cloud$("createCloudAccount").onclick = createCloudAccount;

cloud$("connectCloud").onclick = async () => {
 try {
  await connectCloudAccount();
 } catch (error) {
  cloudSay(error.message, true);
 }
};

cloud$("copyCloudCredentials").onclick = async () => {
 try {
  await copyCloudCredentials();
 } catch (error) {
  cloudSay(error.message, true);
 }
};

cloud$("saveCloudConfig").onclick = async () => {
 try {
  const result = await chrome.runtime.sendMessage({
   type: "SFR_CLOUD_CONFIGURE",
   autoEnabled: cloud$("cloudAuto").checked,
   intervalHours: Number(cloud$("cloudInterval").value) || 6
  });

  if (result && !result.ok) throw Error(result.error || "Could not configure automatic backup.");

  await chrome.storage.local.set({
   "sfr:cloudAutoEnabled": cloud$("cloudAuto").checked,
   "sfr:cloudIntervalHours": Number(cloud$("cloudInterval").value) || 6
  });

  cloudSay("Backup settings saved. Automatic backup " +
   (cloud$("cloudAuto").checked ? "enabled." : "disabled."));
 } catch (error) {
  cloudSay(error.message, true);
 }
};

cloud$("cloudBackupNow").onclick = async () => {
 try { await runCloudBackup(); }
 catch (error) { cloudSay(error.message, true); }
};

cloud$("cloudRefresh").onclick = async () => {
 try { await loadCloudBackups(); }
 catch (error) { cloudSay(error.message, true); }
};

cloud$("cloudRestore").onclick = async () => {
 try { await restoreCloudBackup(); }
 catch (error) { cloudSay(error.message, true); }
};

cloud$("cloudAuto").onchange = () =>
 cloudSay("Save backup settings to apply the automatic backup schedule.");

cloud$("cloudInterval").onchange = () =>
 cloudSay("Save backup settings to apply the new interval.");

initCloudPanel();

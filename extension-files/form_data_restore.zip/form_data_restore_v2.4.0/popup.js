const $=id=>document.getElementById(id);
const ENABLE_KEY="sfr:globalEnabled";
const AUTOSAVE_KEY="sfr:autoSaveEnabled";
let tab,pageKey,record={auto:null,saved:[]},isEnabled=true,autoSaveEnabled=true;
function say(s,bad=false){$("message").textContent=s;$("message").style.color=bad?"#b42318":"#087443";}
function keyFor(url){try{const u=new URL(url);return "sfr:"+u.origin+u.pathname;}catch{return null;}}
function paintToggles(){
  $("masterToggle").setAttribute("aria-checked",String(isEnabled));
  $("toggleLabel").textContent=isEnabled?"ON":"OFF";
  $("toggleStatus").textContent=isEnabled?"Extension is active":"All extension functions are paused";
  $("masterToggle").title=isEnabled?"Turn extension OFF":"Turn extension ON";
  $("autoSaveToggle").setAttribute("aria-checked",String(autoSaveEnabled));
  $("autoSaveLabel").textContent=autoSaveEnabled?"ON":"OFF";
  $("autoSaveStatus").textContent=autoSaveEnabled?"Forms save automatically":"Automatic saving is paused";
  $("autoSaveToggle").title=autoSaveEnabled?"Turn auto-save OFF":"Turn auto-save ON";
  $("autoSaveToggle").disabled=!isEnabled;
  for(const id of ["saveNow","restoreLatest","saveNamed"]) $(id).disabled=!isEnabled;
}
async function init(){
  const settings=await chrome.storage.local.get([ENABLE_KEY,AUTOSAVE_KEY]);
  isEnabled=settings[ENABLE_KEY]!==false;
  autoSaveEnabled=settings[AUTOSAVE_KEY]!==false;
  paintToggles();
  const a=await chrome.tabs.query({active:true,currentWindow:true});tab=a[0];
  if(!tab?.url||!/^https?:/.test(tab.url)){$("site").textContent="Open a website to use form tools.";return;}
  pageKey=keyFor(tab.url);$("site").textContent=tab.title||new URL(tab.url).hostname;
  const d=await chrome.storage.local.get(pageKey);record=d[pageKey]||{auto:null,saved:[]};
}
async function capture(){
  if(!isEnabled)throw Error("Form Data Restore is OFF. Turn it ON first.");
  if(!tab?.id)throw Error("Open a website first.");
  const r=await chrome.tabs.sendMessage(tab.id,{type:"SFR_CAPTURE"});
  if(!r?.ok)throw Error(r?.error||"Refresh this page and try again.");
  record.auto=r.snapshot;return r.snapshot;
}
$("masterToggle").onclick=async()=>{
  const previous=isEnabled;
  try{isEnabled=!isEnabled;await chrome.storage.local.set({[ENABLE_KEY]:isEnabled});paintToggles();
    say(isEnabled?"Form Data Restore is ON.":"Form Data Restore is OFF. All functions are paused.");
  }catch(e){isEnabled=previous;paintToggles();say("Could not change extension status.",true);}
};
$("autoSaveToggle").onclick=async()=>{
  const previous=autoSaveEnabled;
  try{autoSaveEnabled=!autoSaveEnabled;await chrome.storage.local.set({[AUTOSAVE_KEY]:autoSaveEnabled});paintToggles();
    say(autoSaveEnabled?"Auto-save is ON. Forms will save automatically.":"Auto-save is OFF. Use Save now to save manually.");
  }catch(e){autoSaveEnabled=previous;paintToggles();say("Could not change auto-save setting.",true);}
};
$("saveNow").onclick=async()=>{try{const s=await capture();say(`Saved ${s.fields.length} fields manually.`);}catch(e){say(e.message,true);}};
$("restoreLatest").onclick=async()=>{
  if(!isEnabled){say("Form Data Restore is OFF. Turn it ON first.",true);return;}
  if(!record.auto){say("No saved draft found.",true);return;}
  try{const r=await chrome.tabs.sendMessage(tab.id,{type:"SFR_RESTORE",snapshot:record.auto});if(!r?.ok)throw Error(r?.error||"Restore unavailable.");say(`Restored ${r.restored} fields. Review before submitting.`);}
  catch(e){say(e.message||"Refresh the page and try again.",true);}
};
$("saveNamed").onclick=async()=>{
  const name=$("sessionName").value.trim();if(!name){say("Enter a customer name or reference.",true);return;}
  try{const s=await capture();record.saved=Array.isArray(record.saved)?record.saved:[];
    record.saved.push({id:crypto.randomUUID(),name,snapshot:s});await chrome.storage.local.set({[pageKey]:record});
    $("sessionName").value="";say("Customer session saved.");
  }catch(e){say(e.message,true);}
};
$("dashboard").onclick=()=>chrome.tabs.create({url:chrome.runtime.getURL("dashboard.html")});
init().catch(()=>say("Could not initialize extension.",true));

SHOP FORM RECOVERY — VERSION 2.0

INSTALL / UPDATE
1. Download and extract shop-form-recovery-v2.zip.
2. In Chrome, open chrome://extensions.
3. If Version 1 is installed, click its Details page and note that both versions use the same local data key format. To avoid duplicate extensions, remove Version 1 first only after exporting its data, or use "Load unpacked" to reload the same extension folder if you are replacing the old files.
4. Turn on Developer mode.
5. Click "Load unpacked" and select the extracted shop_form_recovery_v2 folder.
6. Pin the extension icon. Click "Open full dashboard" in the popup, or open the extension's dashboard from chrome://extensions > Details.

DASHBOARD
- Search customer/session names, website titles, URLs and site keys.
- Filter named customer sessions or automatic drafts.
- See counts for named sessions, automatic drafts, websites and fields.
- Restore any saved item. The dashboard opens the original URL in a tab if required; the website may require you to sign in first.
- Export one record or all records to JSON.
- Import a full backup.
- Delete individual items or all extension data.
- Save current tab from dashboard.

POPUP
- Save now: capture current form immediately.
- Restore latest: restore the most recent automatic draft.
- Save named session: capture a named customer record.
- Open full dashboard.

DATA AND SAFETY
- All records are stored in chrome.storage.local in this Chrome profile. They do not sync to a cloud server.
- Export backups regularly. Local storage can be lost if the Chrome profile is reset/deleted, Windows profile is removed, or disk fails.
- Passwords, hidden/file inputs, OTP/PIN/payment-like fields are excluded when detected from type, autocomplete, labels, names, IDs or placeholders. Detection is not perfect; do not store secrets.
- This extension does not submit forms or bypass website security. Always check restored information before submitting.
- Some sites use custom controls, shadow DOM, cross-origin frames, dynamic field IDs, or scripts that may prevent complete restore.
- Use only where permitted by the website and applicable privacy rules. Protect access to the Windows/Chrome profile because customer data is personal information.

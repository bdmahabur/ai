
const PREFIX="sfr:",$=id=>document.getElementById(id);let allRecords=[];
const fmt=t=>new Date(t||Date.now()).toLocaleString();
function safeText(s){return String(s??"");}
async function readAll(){
 const data=await chrome.storage.local.get(null);
 allRecords=Object.entries(data).filter(([k,v])=>k.startsWith(PREFIX)&&v&&typeof v==="object").map(([key,record])=>({key,record}));
 render();
}
function buildItems(){
 const items=[];
 for(const {key,record} of allRecords){
  const auto=record.auto;
  if(auto?.fields?.length)items.push({key,type:"auto",name:"Automatic draft",snapshot:auto,id:"auto",count:auto.fields.length,when:auto.savedAt||0,title:auto.title||key,url:auto.url||""});
  (Array.isArray(record.saved)?record.saved:[]).forEach(s=>{
   if(s?.snapshot)items.push({key,type:"named",name:s.name||"Unnamed session",snapshot:s.snapshot,id:s.id,count:s.snapshot.fields?.length||0,when:s.snapshot.savedAt||0,title:s.snapshot.title||key,url:s.snapshot.url||""});
  });
 }
 return items.sort((a,b)=>b.when-a.when);
}
function render(){
 const items=buildItems(),q=$("search").value.trim().toLowerCase(),filter=$("filter").value;
 const sites=new Set(items.map(x=>x.key));
 $("countSessions").textContent=items.filter(x=>x.type==="named").length;
 $("countDrafts").textContent=items.filter(x=>x.type==="auto").length;
 $("countSites").textContent=sites.size;
 $("countFields").textContent=items.reduce((n,x)=>n+x.count,0);
 const visible=items.filter(x=>(filter==="all"||filter===x.type)&&[x.name,x.title,x.url,x.key].join(" ").toLowerCase().includes(q));
 const host=$("records");host.innerHTML="";
 if(!visible.length){host.innerHTML='<div class="empty">No saved forms match your search.</div>';return;}
 const groups=new Map();
 visible.forEach(item=>{if(!groups.has(item.key))groups.set(item.key,[]);groups.get(item.key).push(item);});
 for(const [key,list] of groups){
  const section=document.createElement("section");section.className="group";
  const head=document.createElement("div");head.className="group-head";
  const label=document.createElement("strong");label.textContent=list[0].title||key;
  const sub=document.createElement("small");sub.textContent=`${list.length} saved item${list.length===1?"":"s"} · ${key.replace(PREFIX,"")}`;
  head.append(label,sub);section.append(head);
  list.forEach(item=>{
   const row=document.createElement("div");row.className="entry";
   const info=document.createElement("div");info.className="entry-info";
   const name=document.createElement("strong");name.textContent=item.name;
   const meta=document.createElement("small");meta.textContent=`${item.count} fields · ${fmt(item.when)}${item.url?" · "+item.url:""}`;
   const tag=document.createElement("span");tag.className="tag";tag.textContent=item.type==="auto"?"Auto draft":"Customer session";
   info.append(tag,name,meta);
   const actions=document.createElement("div");actions.className="entry-actions";
   const restore=document.createElement("button");restore.textContent="Restore";restore.onclick=()=>restoreItem(item);
   const exportOne=document.createElement("button");exportOne.textContent="Export";exportOne.onclick=()=>download({format:"Shop Form Recovery Backup",version:2,exportedAt:new Date().toISOString(),records:{[item.key]:allRecords.find(x=>x.key===item.key).record}},`shop-form-${item.type}-backup.json`);
   const del=document.createElement("button");del.className="danger";del.textContent="Delete";del.onclick=()=>deleteItem(item);
   actions.append(restore,exportOne,del);row.append(info,actions);section.append(row);
  });
  host.append(section);
 }
}
async function restoreItem(item){
 let tabs=await chrome.tabs.query({active:true,currentWindow:true}),tab=tabs[0];
 try{
  if(!tab?.url||!tab.url.startsWith(new URL(item.url).origin)){
   tab=await chrome.tabs.create({url:item.url,active:true});
   await new Promise(resolve=>setTimeout(resolve,1300));
  }else if(new URL(tab.url).origin+new URL(tab.url).pathname!==new URL(item.url).origin+new URL(item.url).pathname){
   tab=await chrome.tabs.create({url:item.url,active:true});
   await new Promise(resolve=>setTimeout(resolve,1300));
  }
  let result;
  for(let i=0;i<5;i++){
   try{result=await chrome.tabs.sendMessage(tab.id,{type:"SFR_RESTORE",snapshot:item.snapshot});break;}
   catch{await new Promise(resolve=>setTimeout(resolve,700));}
  }
  if(!result)throw Error("Could not connect to the page. Refresh it and try again.");
  alert(`Restored ${result.restored} fields. ${result.skipped} fields could not be matched. Review the form before submitting.`);
 }catch(e){alert("Restore failed: "+(e.message||"Open the saved website and try again."));}
}
function confirmDialog(title,message,confirmLabel="Delete"){
 return new Promise(resolve=>{
  const dialog=$("confirmDialog"),titleEl=$("confirmTitle"),messageEl=$("confirmMessage"),confirmBtn=$("confirmDelete"),cancelBtn=$("cancelDelete");
  titleEl.textContent=title;messageEl.textContent=message;confirmBtn.textContent=confirmLabel;
  const cleanup=value=>{dialog.close();confirmBtn.removeEventListener("click",yes);cancelBtn.removeEventListener("click",no);dialog.removeEventListener("cancel",onCancel);resolve(value);};
  const yes=()=>cleanup(true),no=()=>cleanup(false),onCancel=e=>{e.preventDefault();no();};
  confirmBtn.addEventListener("click",yes);cancelBtn.addEventListener("click",no);dialog.addEventListener("cancel",onCancel);dialog.showModal();cancelBtn.focus();
 });
}
async function deleteItem(item){
 if(!await confirmDialog("Delete saved form?",`“${item.name}” will be permanently removed from this Chrome profile.`))return;
 const d=await chrome.storage.local.get(item.key),r=d[item.key]||{auto:null,saved:[]};
 if(item.type==="auto")r.auto=null;else r.saved=(r.saved||[]).filter(s=>s.id!==item.id);
 if(!r.auto&&!r.saved.length)await chrome.storage.local.remove(item.key);else await chrome.storage.local.set({[item.key]:r});
 await readAll();
}
function download(obj,name){
 const blob=new Blob([JSON.stringify(obj,null,2)],{type:"application/json"}),url=URL.createObjectURL(blob),a=document.createElement("a");
 a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
$("refresh").onclick=readAll;$("search").oninput=render;$("filter").onchange=render;
$("exportAll").onclick=()=>download({format:"Form Data Restore Full Backup",version:2,exportedAt:new Date().toISOString(),records:Object.fromEntries(allRecords.map(x=>[x.key,x.record]))},"form-data-restore-full-backup.json");
$("importAll").onchange=async e=>{
 const f=e.target.files[0];if(!f)return;
 try{
  const obj=JSON.parse(await f.text()),records=obj.records;
  if(!records||typeof records!=="object")throw Error();
  const clean={};for(const [k,v] of Object.entries(records)){if(k.startsWith(PREFIX)&&v&&typeof v==="object")clean[k]=v;}
  await chrome.storage.local.set(clean);await readAll();alert(`Imported ${Object.keys(clean).length} website record(s).`);
 }catch{alert("This backup file is invalid or unsupported.");}
 e.target.value="";
};
$("deleteAll").onclick=async()=>{
 if(!allRecords.length)return;
 if(!await confirmDialog("Delete all saved data?","All saved forms and customer sessions in this Chrome profile will be permanently deleted. Export a backup first if you may need this data.","Delete all"))return;
 const keys=allRecords.map(x=>x.key);if(keys.length)await chrome.storage.local.remove(keys);await readAll();
};
$("saveCurrent").onclick=async()=>{
 const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
 if(!tab?.url||!/^https?:/.test(tab.url)){alert("Open a normal website first.");return;}
 try{
  const r=await chrome.tabs.sendMessage(tab.id,{type:"SFR_CAPTURE"});
  if(!r?.ok)throw Error();
  await readAll();alert(`Saved ${r.snapshot.fields.length} fields from the current tab.`);
 }catch{alert("Could not read this page. Refresh it and try again.");}
};
readAll().catch(e=>{ $("records").textContent="Could not load local saved data."; });

# Print-Only White Overlay

This extension is intended for websites you own or are authorized to modify.

## Configure the domain

Open `manifest.json` and replace:

https://YOUR-AUTHORIZED-DOMAIN.example/*

with the authorized website's URL pattern.

## Configure overlay height

Open `print.css` and change:

height: 60px

to the desired height.

## Install

1. Extract the ZIP.
2. Open chrome://extensions
3. Enable Developer mode.
4. Choose Load unpacked.
5. Select this folder.
6. Open the authorized website.
7. The overlay is hidden during normal browsing and appears only in Ctrl+P / browser print preview.

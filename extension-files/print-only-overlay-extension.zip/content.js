(() => {
  const ID = "__print_only_white_overlay__";

  function install() {
    if (!document.body || document.getElementById(ID)) return;

    const mask = document.createElement("div");
    mask.id = ID;
    mask.setAttribute("aria-hidden", "true");
    document.body.appendChild(mask);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", install, { once: true });
  } else {
    install();
  }
})();

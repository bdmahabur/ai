/**
 * background.js — Teletalk Job Apply-Modified by Mahabur Hossain-01781040050
 * Handles messaging between the popup/options dashboard and content scripts.
 */

chrome.runtime.onInstalled.addListener(({ reason }) => {
  if (reason === "install") {
    // Initialize default storage schema
    chrome.storage.local.set({
      settings: {
        encryptionEnabled: false,
        activeProfileId: null,
        showFloatingBtn: true,
        autoDetect: true
      },
      profiles: []
    });
    // Launch options page immediately to help the user set up their first profile
    chrome.runtime.openOptionsPage();
  }
});

// Message Router
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action && message.action.startsWith("CLOUD_")) return false;
  switch (message.action) {
    case "GET_PROFILES":
      chrome.storage.local.get(["profiles", "settings"], (data) => {
        sendResponse({
          profiles: data.profiles || [],
          settings: data.settings || {}
        });
      });
      return true; // Async response

    case "SAVE_PROFILE":
      saveProfile(message.profile).then(sendResponse);
      return true;

    case "DELETE_PROFILE":
      deleteProfile(message.profileId).then(sendResponse);
      return true;

    case "GET_ACTIVE_PROFILE":
      chrome.storage.local.get(["profiles", "settings"], (data) => {
        const settings = data.settings || {};
        const profiles = data.profiles || [];
        const active = profiles.find(p => p.id === settings.activeProfileId) || profiles[0] || null;
        sendResponse({ profile: active });
      });
      return true;

    case "SET_ACTIVE_PROFILE":
      chrome.storage.local.get("settings", (data) => {
        const settings = data.settings || {};
        settings.activeProfileId = message.profileId;
        chrome.storage.local.set({ settings }, () => sendResponse({ ok: true }));
      });
      return true;

    case "UPDATE_SETTINGS":
      chrome.storage.local.get("settings", (data) => {
        const settings = Object.assign(data.settings || {}, message.settings);
        chrome.storage.local.set({ settings }, () => sendResponse({ ok: true }));
      });
      return true;

    case "AUTOFILL_PAGE":
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0] && tabs[0].id) {
          chrome.tabs.sendMessage(tabs[0].id, {
            action: "DO_AUTOFILL",
            profileId: message.profileId
          }, sendResponse);
        } else {
          sendResponse({ ok: false, error: "No active tab found" });
        }
      });
      return true;

    case "CLEAR_FORM":
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0] && tabs[0].id) {
          chrome.tabs.sendMessage(tabs[0].id, { action: "CLEAR_FORM" }, sendResponse);
        } else {
          sendResponse({ ok: false, error: "No active tab found" });
        }
      });
      return true;

    case "OPEN_OPTIONS":
      chrome.runtime.openOptionsPage();
      sendResponse({ ok: true });
      return true;

    default:
      sendResponse({ error: `Unknown action: ${message.action}` });
  }
});

// Helper functions for profile persistence
async function saveProfile(profile) {
  return new Promise((resolve) => {
    chrome.storage.local.get("profiles", (data) => {
      const profiles = data.profiles || [];
      const idx = profiles.findIndex((p) => p.id === profile.id);
      if (idx >= 0) {
        profiles[idx] = profile;
      } else {
        if (!profile.id) profile.id = "profile_" + Date.now();
        profiles.push(profile);
      }
      chrome.storage.local.set({ profiles }, () => resolve({ ok: true, id: profile.id }));
    });
  });
}

async function deleteProfile(profileId) {
  return new Promise((resolve) => {
    chrome.storage.local.get(["profiles", "settings"], (data) => {
      const profiles = (data.profiles || []).filter((p) => p.id !== profileId);
      const settings = data.settings || {};
      if (settings.activeProfileId === profileId) {
        settings.activeProfileId = profiles[0]?.id || null;
      }
      chrome.storage.local.set({ profiles, settings }, () => resolve({ ok: true }));
    });
  });
}

// ─── Encrypted Cloud Backup (Cloudflare Worker + D1 + R2) ─────────────────────
const CLOUD_ALARM = "teletalk-cloud-sync";
let applyingCloudSnapshot = false;
let cloudSyncRunning = false;
let cloudSyncPending = false;

function bytesToB64Url(bytes) {
  let binary = "";
  bytes.forEach(b => binary += String.fromCharCode(b));
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
function randomSecret(size = 32) {
  return bytesToB64Url(crypto.getRandomValues(new Uint8Array(size)));
}
async function sha256Hex(value) {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return Array.from(new Uint8Array(digest), b => b.toString(16).padStart(2, "0")).join("");
}
function makeAuthToken(accountId, recoveryKey) {
  return `${accountId}.${recoveryKey}`;
}
async function encryptCloudState(state, recoveryKey, accountId) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const material = await crypto.subtle.importKey("raw", new TextEncoder().encode(recoveryKey), "PBKDF2", false, ["deriveKey"]);
  const key = await crypto.subtle.deriveKey({ name: "PBKDF2", salt, iterations: 250000, hash: "SHA-256" }, material, { name: "AES-GCM", length: 256 }, false, ["encrypt"]);
  const aad = new TextEncoder().encode(`teletalk-cloud-v1:${accountId}`);
  const cipher = await crypto.subtle.encrypt({ name: "AES-GCM", iv, additionalData: aad }, key, new TextEncoder().encode(JSON.stringify(state)));
  return { v: 1, kdf: "PBKDF2-SHA256-250000", cipher: "AES-256-GCM", salt: bytesToB64Url(salt), iv: bytesToB64Url(iv), data: bytesToB64Url(new Uint8Array(cipher)) };
}
function b64UrlToBytes(value) {
  const normalized = value.replace(/-/g, "+").replace(/_/g, "/");
  const padded = normalized + "=".repeat((4 - normalized.length % 4) % 4);
  return Uint8Array.from(atob(padded), c => c.charCodeAt(0));
}
async function decryptCloudState(envelope, recoveryKey, accountId) {
  if (!envelope || envelope.v !== 1) throw new Error("Unsupported or invalid cloud backup format.");
  const material = await crypto.subtle.importKey("raw", new TextEncoder().encode(recoveryKey), "PBKDF2", false, ["deriveKey"]);
  const key = await crypto.subtle.deriveKey({ name: "PBKDF2", salt: b64UrlToBytes(envelope.salt), iterations: 250000, hash: "SHA-256" }, material, { name: "AES-GCM", length: 256 }, false, ["decrypt"]);
  const aad = new TextEncoder().encode(`teletalk-cloud-v1:${accountId}`);
  const plain = await crypto.subtle.decrypt({ name: "AES-GCM", iv: b64UrlToBytes(envelope.iv), additionalData: aad }, key, b64UrlToBytes(envelope.data));
  return JSON.parse(new TextDecoder().decode(plain));
}
function getLocal(keys) {
  return new Promise(resolve => chrome.storage.local.get(keys, resolve));
}
function setLocal(values) {
  return new Promise(resolve => chrome.storage.local.set(values, resolve));
}
async function cloudRequest(config, path, options = {}) {
  const token = makeAuthToken(config.accountId, config.recoveryKey);
  const headers = Object.assign({ "Content-Type": "application/json", "Authorization": `Bearer ${token}` }, options.headers || {});
  const response = await fetch(`${config.apiBase.replace(/\/$/, "")}${path}`, { ...options, headers });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(`${data.error || "Cloud API request failed"} (${response.status})`);
  return data;
}
function mergeCloudStates(local, remote) {
  const profiles = new Map();
  const tombstones = new Map();
  for (const t of [...(remote.tombstones || []), ...(local.tombstones || [])]) {
    if (!t?.id) continue;
    const previous = tombstones.get(t.id);
    if (!previous || Number(t.deletedAt || 0) > Number(previous.deletedAt || 0)) tombstones.set(t.id, t);
  }
  for (const p of [...(remote.profiles || []), ...(local.profiles || [])]) {
    if (!p?.id) continue;
    const old = profiles.get(p.id);
    if (!old || Number(p.updatedAt || 0) > Number(old.updatedAt || 0)) profiles.set(p.id, p);
  }
  for (const [id, t] of tombstones) {
    const p = profiles.get(id);
    if (p && Number(t.deletedAt || 0) >= Number(p.updatedAt || 0)) profiles.delete(id);
  }
  return { schema: 1, profiles: [...profiles.values()], tombstones: [...tombstones.values()], updatedAt: Date.now() };
}
async function performCloudSync() {
  if (cloudSyncRunning) {
    cloudSyncPending = true;
    return { ok: true, queued: true };
  }
  cloudSyncRunning = true;
  try {
    const data = await getLocal(["cloudConfig", "profiles", "cloudTombstones"]);
    const config = data.cloudConfig;
    if (!config?.apiBase || !config?.accountId || !config?.recoveryKey) throw new Error("Configure Cloud Backup ID, recovery key and Worker URL first.");
    const localState = { schema: 1, profiles: (data.profiles || []).map(p => ({ ...p, updatedAt: Number(p.updatedAt || Date.now()) })), tombstones: data.cloudTombstones || [], updatedAt: Date.now() };
    let remote = { profiles: [], tombstones: [] };
    let revision = 0;
    try {
      const response = await cloudRequest(config, "/v1/snapshot", { method: "GET" });
      revision = Number(response.revision || 0);
      if (response.envelope) remote = await decryptCloudState(response.envelope, config.recoveryKey, config.accountId);
    } catch (err) {
      if (!String(err.message).includes("404")) throw err;
    }
    let merged = mergeCloudStates(localState, remote);
    const envelope = await encryptCloudState(merged, config.recoveryKey, config.accountId);
    try {
      const saved = await cloudRequest(config, "/v1/snapshot", { method: "PUT", body: JSON.stringify({ expectedRevision: revision, envelope }) });
      revision = saved.revision;
    } catch (err) {
      // Concurrent device update: fetch once more, merge and retry against fresh revision.
      if (!String(err.message).includes("409")) throw err;
      const latest = await cloudRequest(config, "/v1/snapshot", { method: "GET" });
      const latestState = latest.envelope ? await decryptCloudState(latest.envelope, config.recoveryKey, config.accountId) : { profiles: [], tombstones: [] };
      merged = mergeCloudStates(merged, latestState);
      const retryEnvelope = await encryptCloudState(merged, config.recoveryKey, config.accountId);
      const retry = await cloudRequest(config, "/v1/snapshot", { method: "PUT", body: JSON.stringify({ expectedRevision: Number(latest.revision || 0), envelope: retryEnvelope }) });
      revision = retry.revision;
    }
    applyingCloudSnapshot = true;
    await setLocal({ profiles: merged.profiles, cloudTombstones: merged.tombstones, cloudLastSync: Date.now(), cloudRevision: revision });
    applyingCloudSnapshot = false;
    return { ok: true, profileCount: merged.profiles.length, revision };
  } catch (error) {
    applyingCloudSnapshot = false;
    return { ok: false, error: error.message || "Cloud sync failed." };
  } finally {
    cloudSyncRunning = false;
    if (cloudSyncPending) {
      cloudSyncPending = false;
      // Run the latest local state after the current request finishes.
      performCloudSync();
    }
  }
}

// Scheduled safety-net backup: once every 24 hours.
chrome.alarms.create(CLOUD_ALARM, { periodInMinutes: 24 * 60 });
chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === CLOUD_ALARM) performCloudSync();
});

// Immediate cloud sync after local profile create, edit, or delete.
// Local storage is updated first; cloud failure never blocks local work.
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local" || applyingCloudSnapshot || !changes.profiles) return;

  const oldProfiles = changes.profiles.oldValue || [];
  const newProfiles = changes.profiles.newValue || [];
  const oldMap = new Map(oldProfiles.filter(p => p?.id).map(p => [p.id, p]));
  const newMap = new Map(newProfiles.filter(p => p?.id).map(p => [p.id, p]));
  const now = Date.now();
  let profileChanged = false;

  const stamped = newProfiles.map(profile => {
    const old = profile?.id ? oldMap.get(profile.id) : null;
    if (!old) {
      profileChanged = true;
      return { ...profile, updatedAt: now };
    }

    // Ignore updatedAt alone when detecting content changes.
    const oldContent = { ...old };
    const newContent = { ...profile };
    delete oldContent.updatedAt;
    delete newContent.updatedAt;

    if (JSON.stringify(oldContent) !== JSON.stringify(newContent)) {
      profileChanged = true;
      return { ...profile, updatedAt: now };
    }
    return profile;
  });

  const deletedIds = oldProfiles
    .filter(old => old?.id && !newMap.has(old.id))
    .map(old => old.id);

  if (deletedIds.length) profileChanged = true;
  if (!profileChanged) return;

  (async () => {
    try {
      const { cloudTombstones = [] } = await getLocal("cloudTombstones");
      const tombstones = cloudTombstones.slice();
      for (const id of deletedIds) tombstones.push({ id, deletedAt: now });

      // Avoid recursively responding to our own timestamp/tombstone write.
      applyingCloudSnapshot = true;
      await new Promise(resolve => {
        chrome.storage.local.set(
          { profiles: stamped, cloudTombstones: tombstones.slice(-500) },
          resolve
        );
      });
    } finally {
      applyingCloudSnapshot = false;
    }

    // Start upload immediately after the local profile change is safely stored.
    // If cloud is offline, performCloudSync reports failure and the next 24h
    // alarm or the user's Sync Now action can retry.
    performCloudSync();
  })().catch(error => console.error("Immediate cloud sync scheduling failed:", error));
});

// Additional message routes are handled before the legacy router below.
const legacyMessageRouter = chrome.runtime.onMessage;
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "CLOUD_CREATE_ACCOUNT") {
    (async () => {
      const accountId = `TJA-${randomSecret(9).toUpperCase()}`;
      const recoveryKey = randomSecret(32);
      const token = makeAuthToken(accountId, recoveryKey);
      const authHash = await sha256Hex(token);
      const config = { apiBase: message.apiBase, accountId, recoveryKey };
      await cloudRequest(config, "/v1/register", { method: "POST", body: JSON.stringify({ accountId, authHash }) });
      await setLocal({ cloudConfig: config });
      return { ok: true, accountId, recoveryKey };
    })().then(sendResponse).catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }
  if (message.action === "CLOUD_CONFIGURE") {
    (async () => {
      if (!/^https:\/\//i.test(message.apiBase || "") || !message.accountId || !message.recoveryKey) throw new Error("Worker URL, Cloud Backup ID and recovery key are required.");
      const config = { apiBase: message.apiBase.replace(/\/$/, ""), accountId: message.accountId, recoveryKey: message.recoveryKey };
      await cloudRequest(config, "/v1/snapshot", { method: "GET" });
      await setLocal({ cloudConfig: config });
      return { ok: true };
    })().then(sendResponse).catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }
  if (message.action === "CLOUD_SYNC_NOW") { performCloudSync().then(sendResponse); return true; }
  return false;
});

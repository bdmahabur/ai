TELETALK JOB APPLY — CLOUD BACKUP (NO NPM REQUIRED)
====================================================

Package contents
----------------
- Teletalk Job Apply/ : Chrome extension, version 1.1.1
- cloudflare/worker.js : Cloudflare Worker API
- cloudflare/schema.sql : D1 database schema


IMPORTANT
---------
This package does NOT require npm, Node.js, Wrangler, a terminal, or command-line
commands. Deploy the Worker by pasting worker.js into the Cloudflare Dashboard.
Create the D1 and R2 resources in the dashboard and bind them to the Worker.

PART A — CLOUDFLARE DASHBOARD SETUP
-----------------------------------

1. Sign in at https://dash.cloudflare.com/

2. Create the D1 database:
   - Open Workers & Pages (or Storage & databases > D1).
   - Choose Create database.
   - Name it: teletalk-job-apply
   - Open the database's Console / SQL Console.
   - Open cloudflare/schema.sql from this package.
   - Copy all SQL and run it in the D1 console.

3. Create the R2 bucket:
   - Open R2 Object Storage.
   - Choose Create bucket.
   - Name it exactly: teletalk-job-apply-backups

4. Create the Worker:
   - Open Workers & Pages.
   - Choose Create application > Create Worker.
   - Name it: teletalk-job-apply-cloud
   - Deploy the starter Worker.
   - Open Edit code.
   - Replace all starter code with the complete contents of cloudflare/worker.js.
   - Save and Deploy.

5. Add D1 binding:
   - Open Worker > Settings > Bindings.
   - Add binding > D1 database.
   - Variable name: DB
   - Select database: teletalk-job-apply
   - Save.

6. Add R2 binding:
   - Add binding > R2 bucket.
   - Variable name: BACKUPS
   - Select bucket: teletalk-job-apply-backups
   - Save.

7. Optional Worker variable:
   - Add variable under Variables and Secrets.
   - Name: MAX_BACKUP_BYTES
   - Value: 10485760
   - Save and Deploy.

8. Copy the Worker URL, for example:
   https://teletalk-job-apply-cloud.YOUR-SUBDOMAIN.workers.dev

9. Test it in a browser by opening:
   https://YOUR-WORKER-URL/health
   Expected response:
   {"ok":true,"service":"teletalk-job-apply-cloud","apiVersion":1}

PART B — INSTALL THE EXTENSION
------------------------------

1. Extract the extension ZIP.
2. Open chrome://extensions
3. Enable Developer mode.
4. Choose Load unpacked.
5. Select the folder named "Teletalk Job Apply".
6. Open the extension's Options page.

PART C — CREATE YOUR CLOUD BACKUP ID
------------------------------------

1. In Cloud Backup & Sync, paste your Worker URL.
2. Click Create Cloud ID.
3. Store BOTH the Cloud Backup ID and Recovery Key somewhere safe and offline.
4. Click Save Connection if needed, then Sync Now.
5. Keep your recovery key private. It is required to decrypt the cloud data.

PART D — CONNECT A SECOND DEVICE
--------------------------------

1. Install the same extension on the second computer.
2. Open Options > Cloud Backup & Sync.
3. Enter the same Worker URL, Cloud Backup ID and Recovery Key.
4. Click Save Connection.
5. Click Sync Now.

The extension merges profiles by profile ID and updatedAt timestamp. Deletions
are synchronized using tombstones. A 15-minute alarm provides periodic sync;
local profile edits also schedule a faster sync.

SECURITY AND LIMITATIONS
------------------------

- Profile snapshots are encrypted in the extension using AES-256-GCM.
- The encryption key is derived locally using PBKDF2-SHA-256 (250,000 iterations).
- The recovery key is not sent as a standalone value; the Worker receives an
  authentication bearer token over HTTPS. The D1 database stores only its SHA-256
  verifier.
- R2 stores encrypted snapshot envelopes. D1 stores account and version metadata.
- The newest 10 successful snapshots are retained.
- If the recovery key is lost, the server cannot decrypt or reset the backup.
- The extension stores the recovery key in Chrome local extension storage so
  unattended sync can run on that device. Protect your Chrome user profile.
- Settings/UI preferences are device-local; profile records and deletion
  tombstones are synchronized.
- Existing profile-level password encryption remains encrypted inside the
  cloud snapshot; use the same profile password on the second device.
- Keep using manual JSON exports as an independent backup.
- Test with sample profiles before relying on cloud restore for important data.

TROUBLESHOOTING
---------------

"Invalid Cloud Backup ID or recovery key":
- Check the ID and recovery key exactly, including capitalization.
- Confirm both devices use the same Worker URL.

"Failed to fetch":
- Confirm the Worker URL starts with https:// and ends with workers.dev (or
  your configured custom hostname).
- Check that DB and BACKUPS bindings are saved on the Worker.
- Open /health to verify deployment.

"Internal server error":
- Open Worker > Logs in Cloudflare Dashboard.
- Confirm the D1 schema was executed and both bindings point to the correct
  database and bucket.

For a custom Worker domain other than workers.dev, add that exact domain to
host_permissions in manifest.json, then reload the extension at chrome://extensions.

-- Teletalk Job Apply Cloud Backup schema
CREATE TABLE IF NOT EXISTS users (
  account_id TEXT PRIMARY KEY,
  auth_hash TEXT NOT NULL,
  revision INTEGER NOT NULL DEFAULT 0,
  latest_r2_key TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE TABLE IF NOT EXISTS backups (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  account_id TEXT NOT NULL,
  revision INTEGER NOT NULL,
  r2_key TEXT NOT NULL UNIQUE,
  size_bytes INTEGER NOT NULL,
  checksum TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  FOREIGN KEY (account_id) REFERENCES users(account_id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_backups_account_revision ON backups(account_id, revision DESC);

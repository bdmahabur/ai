const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET,POST,PUT,OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type,Authorization",
  "Access-Control-Max-Age": "86400",
  "Vary": "Origin"
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...CORS, "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" }
  });
}

const encoder = new TextEncoder();

async function sha256Hex(value) {
  const digest = await crypto.subtle.digest("SHA-256", encoder.encode(value));
  return Array.from(new Uint8Array(digest), b => b.toString(16).padStart(2, "0")).join("");
}

function validAccountId(value) {
  return typeof value === "string" && /^TJA-[A-Za-z0-9_-]{8,40}$/.test(value);
}

async function readJson(request, maxBytes) {
  const declared = Number(request.headers.get("Content-Length") || 0);
  if (declared > maxBytes) throw Object.assign(new Error("Request is too large."), { status: 413 });
  const raw = await request.text();
  if (encoder.encode(raw).byteLength > maxBytes) throw Object.assign(new Error("Request is too large."), { status: 413 });
  try { return JSON.parse(raw); }
  catch { throw Object.assign(new Error("Invalid JSON."), { status: 400 }); }
}

async function authenticate(request, env) {
  const header = request.headers.get("Authorization") || "";
  if (!header.startsWith("Bearer ")) return null;
  const token = header.slice(7);
  const separator = token.indexOf(".");
  if (separator < 1) return null;

  const accountId = token.slice(0, separator);
  if (!validAccountId(accountId)) return null;

  const user = await env.DB.prepare(
    "SELECT account_id, auth_hash, revision, latest_r2_key FROM users WHERE account_id = ?"
  ).bind(accountId).first();

  if (!user) return null;
  const supplied = await sha256Hex(token);
  if (supplied.length !== user.auth_hash.length) return null;

  // Constant-time comparison of fixed-length hexadecimal hashes.
  let diff = 0;
  for (let i = 0; i < supplied.length; i++) diff |= supplied.charCodeAt(i) ^ user.auth_hash.charCodeAt(i);
  return diff === 0 ? user : null;
}

async function handle(request, env) {
  if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: CORS });
  const url = new URL(request.url);

  if (url.pathname === "/health" && request.method === "GET") {
    return json({ ok: true, service: "teletalk-job-apply-cloud", apiVersion: 1 });
  }

  if (url.pathname === "/v1/register" && request.method === "POST") {
    const body = await readJson(request, 16 * 1024);
    if (!validAccountId(body.accountId) || typeof body.authHash !== "string" || !/^[a-f0-9]{64}$/.test(body.authHash)) {
      return json({ error: "Invalid registration data." }, 400);
    }
    try {
      await env.DB.prepare("INSERT INTO users (account_id, auth_hash) VALUES (?, ?)")
        .bind(body.accountId, body.authHash).run();
    } catch {
      return json({ error: "This Cloud Backup ID already exists." }, 409);
    }
    return json({ ok: true, accountId: body.accountId }, 201);
  }

  if (url.pathname !== "/v1/snapshot" || !["GET", "PUT"].includes(request.method)) {
    return json({ error: "Not found." }, 404);
  }

  const user = await authenticate(request, env);
  if (!user) return json({ error: "Invalid Cloud Backup ID or recovery key." }, 401);

  if (request.method === "GET") {
    if (!user.latest_r2_key) {
      return json({ ok: true, revision: Number(user.revision || 0), envelope: null });
    }
    const object = await env.BACKUPS.get(user.latest_r2_key);
    if (!object) return json({ error: "Latest backup object is missing." }, 500);
    const envelope = await object.json();
    return json({ ok: true, revision: Number(user.revision || 0), envelope });
  }

  const maxBytes = Number(env.MAX_BACKUP_BYTES || 10485760);
  const body = await readJson(request, maxBytes + 32 * 1024);
  if (!Number.isInteger(body.expectedRevision) || body.expectedRevision < 0) {
    return json({ error: "Invalid expected revision." }, 400);
  }
  const e = body.envelope;
  if (!e || e.v !== 1 || e.cipher !== "AES-256-GCM" ||
      e.kdf !== "PBKDF2-SHA256-250000" ||
      !["salt", "iv", "data"].every(k => typeof e[k] === "string")) {
    return json({ error: "Invalid encrypted backup envelope." }, 400);
  }

  const serialized = JSON.stringify(e);
  const size = encoder.encode(serialized).byteLength;
  if (size > maxBytes) return json({ error: `Backup exceeds the ${maxBytes} byte limit.` }, 413);

  const nextRevision = body.expectedRevision + 1;
  const key = `accounts/${user.account_id}/versions/${String(nextRevision).padStart(10, "0")}-${crypto.randomUUID()}.json`;
  const checksum = await sha256Hex(serialized);

  // Put encrypted data first. Then use a conditional D1 batch as compare-and-swap.
  // If another device wins the revision race, delete this orphaned R2 object.
  await env.BACKUPS.put(key, serialized, {
    httpMetadata: { contentType: "application/json", cacheControl: "no-store" },
    customMetadata: { accountId: user.account_id, revision: String(nextRevision), checksum }
  });

  let batch;
  try {
    batch = await env.DB.batch([
      env.DB.prepare(
        "UPDATE users SET revision = ?, latest_r2_key = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE account_id = ? AND revision = ?"
      ).bind(nextRevision, key, user.account_id, body.expectedRevision),
      env.DB.prepare(
        "INSERT INTO backups (account_id, revision, r2_key, size_bytes, checksum) SELECT ?, ?, ?, ?, ? WHERE changes() = 1"
      ).bind(user.account_id, nextRevision, key, size, checksum)
    ]);
  } catch (error) {
    await env.BACKUPS.delete(key);
    throw error;
  }

  const changed = Number(batch?.[0]?.meta?.changes || 0);
  if (changed !== 1) {
    await env.BACKUPS.delete(key);
    return json({ error: "Revision conflict. Download, merge and retry." }, 409);
  }

  // Retain only the newest ten successful versions.
  const old = await env.DB.prepare(
    "SELECT id, r2_key FROM backups WHERE account_id = ? ORDER BY revision DESC LIMIT -1 OFFSET 10"
  ).bind(user.account_id).all();

  if (old.results?.length) {
    for (const row of old.results) await env.BACKUPS.delete(row.r2_key);
    const ids = old.results.map(row => row.id);
    const placeholders = ids.map(() => "?").join(",");
    await env.DB.prepare(`DELETE FROM backups WHERE id IN (${placeholders})`).bind(...ids).run();
  }

  return json({ ok: true, revision: nextRevision, retainedVersions: 10 });
}

export default {
  async fetch(request, env) {
    try {
      return await handle(request, env);
    } catch (error) {
      const status = Number(error?.status || 500);
      return json({ error: status < 500 ? error.message : "Internal server error. Check Worker logs." }, status);
    }
  }
};

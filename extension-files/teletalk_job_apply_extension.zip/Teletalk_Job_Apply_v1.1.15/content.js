/**
 * content.js — Teletalk Job Apply-Developed by Mahabur Hossain-01781040050
 * Injected into Teletalk pages. Implements the greedy match scoring engine,
 * element autofilling, dynamic upazila event triggers, and floating menu buttons.
 */

let debugMode = false;
let fillCount = 0;
let floatingBtn = null;

function setTeletalkStatusIcon(element, message, kind = "success") {
  if (!element) return;
  const paths = {
    success: '<path d="m5 12 4 4L19 6"/>',
    warning: '<path d="M12 3 2.8 20h18.4L12 3Z"/><path d="M12 9v5m0 3h.01"/>',
    error: '<path d="m6 6 12 12M18 6 6 18"/>',
    lock: '<rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3M12 14v3"/>',
    profile: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>'
  };
  const icon = `<svg class="teletalk-inline-icon" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${paths[kind] || paths.success}</svg>`;
  element.innerHTML = `${icon}<span></span>`;
  element.querySelector("span").textContent = String(message).replace(/[⚠✓❌🔒]/g, "").trim();
}



// Initialize debug mode from storage settings
chrome.storage.local.get("settings", (data) => {
  const settings = data.settings || {};
  debugMode = settings.debugMode === true;
  if (debugMode) {
    console.log("Teletalk Job Apply: Debug mode enabled");
  }
});

// Cache password in window session to avoid prompting multiple times on page steps
window._teletalkDecryptionPassword = window._teletalkDecryptionPassword || "";

// ─── Init ─────────────────────────────────────────────────────────────────────
(function init() {
  chrome.storage.local.get("settings", (data) => {
    const settings = data.settings || {};
    if (settings.showFloatingBtn !== false) {
      injectFloatingButton();
    }
  });
})();

// ─── Message Handler ──────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "DO_AUTOFILL") {
    chrome.storage.local.get(["profiles", "settings"], async (data) => {
      const profiles = data.profiles || [];
      const settings = data.settings || {};
      const profileId = message.profileId || settings.activeProfileId;
      let profile = profiles.find((p) => p.id === profileId) || profiles[0];
      if (!profile) {
        sendResponse({ ok: false, error: "No profile found" });
        return;
      }

      // Decrypt profile data if encrypted
      if (profile._enc) {
        const decrypted = await promptForPasswordAndDecrypt(profile);
        if (!decrypted) {
          sendResponse({ ok: false, error: "Decryption cancelled or failed" });
          return;
        }
        profile = decrypted;
      }

      const count = await autoFillForm(profile);
      sendResponse({ ok: true, filled: count });
    });
    return true; // Keep message channel open for async response
  }
  
  if (message.action === "CLEAR_FORM") {
    clearAllFields();
    sendResponse({ ok: true });
  }
});

// ─── Password Prompt UI ───────────────────────────────────────────────────────
async function promptForPasswordAndDecrypt(profile) {
  if (!profile || !profile._enc) return profile;

  // Try decrypting with cached password first
  if (window._teletalkDecryptionPassword) {
    try {
      const decrypted = await Encryption.decrypt(profile._enc, window._teletalkDecryptionPassword);
      if (debugMode) console.log("Teletalk Job Apply: Successfully decrypted profile using cached password.");
      return { ...decrypted, id: profile.id, profileName: profile.profileName };
    } catch (e) {
      console.warn("Cached password decryption failed.");
      window._teletalkDecryptionPassword = "";
    }
  }

  // Display a password entry modal overlay
  return new Promise((resolve) => {
    let overlay = document.getElementById("teletalk-decrypt-modal-overlay");
    if (overlay) overlay.remove();

    overlay = document.createElement("div");
    overlay.id = "teletalk-decrypt-modal-overlay";
    overlay.className = "teletalk-modal-overlay";
    overlay.innerHTML = `
      <div class="teletalk-modal">
        <div class="teletalk-modal-header">
          <span class="teletalk-modal-logo" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M8 12h8M12 8v8"/></svg></span>
          <h3 class="teletalk-modal-title">Profile Encrypted</h3>
        </div>
        <div class="teletalk-modal-body">
          The profile <strong>"${profile.profileName || "Unnamed"}"</strong> is secured with local AES encryption. Enter password to decrypt and autofill.
        </div>
        <div class="teletalk-modal-input-group">
          <label for="teletalk-decrypt-password">Password</label>
          <input type="password" id="teletalk-decrypt-password" class="teletalk-modal-input" placeholder="Enter password" autofocus>
          <div id="teletalk-decrypt-error" class="teletalk-modal-error"></div>
        </div>
        <div class="teletalk-modal-actions">
          <button type="button" id="teletalk-decrypt-cancel" class="teletalk-modal-btn teletalk-modal-btn-secondary">Cancel</button>
          <button type="button" id="teletalk-decrypt-submit" class="teletalk-modal-btn teletalk-modal-btn-primary">Decrypt & Fill</button>
        </div>
      </div>
    `;

    document.body.appendChild(overlay);
    setTimeout(() => overlay.classList.add("show"), 10);

    const input = overlay.querySelector("#teletalk-decrypt-password");
    const submitBtn = overlay.querySelector("#teletalk-decrypt-submit");
    const cancelBtn = overlay.querySelector("#teletalk-decrypt-cancel");
    const errorDiv = overlay.querySelector("#teletalk-decrypt-error");

    input.focus();

    const cleanup = () => {
      overlay.classList.remove("show");
      setTimeout(() => overlay.remove(), 300);
    };

    const handleDecrypt = async () => {
      const password = input.value.trim();
      if (!password) {
        setTeletalkStatusIcon(errorDiv, "Password is required.", "warning");
        return;
      }

      submitBtn.disabled = true;
      submitBtn.textContent = "Decrypting...";
      errorDiv.textContent = "";

      try {
        const decrypted = await Encryption.decrypt(profile._enc, password);
        window._teletalkDecryptionPassword = password; // Cache password
        cleanup();
        resolve({ ...decrypted, id: profile.id, profileName: profile.profileName });
      } catch (err) {
        submitBtn.disabled = false;
        submitBtn.textContent = "Decrypt & Fill";
        setTeletalkStatusIcon(errorDiv, "Incorrect password. Try again.", "error");
        input.value = "";
        input.focus();
      }
    };

    submitBtn.addEventListener("click", handleDecrypt);
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter") handleDecrypt();
    });
    cancelBtn.addEventListener("click", () => {
      cleanup();
      resolve(null);
    });
    overlay.addEventListener("click", (e) => {
      if (e.target === overlay) {
        cleanup();
        resolve(null);
      }
    });
  });
}

// ─── Floating Button UI ───────────────────────────────────────────────────────
function injectFloatingButton() {
  if (floatingBtn) return;

  const wrapper = document.createElement("div");
  wrapper.id = "teletalk-fab-wrapper";
  wrapper.innerHTML = `
    <div id="teletalk-fab-main" title="Teletalk Job Apply BD">
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
        <path d="M12 20h9M16.5 3.5a2.121 2.121 0 013 3L7 19l-4 1 1-4L16.5 3.5z"/>
      </svg>
    </div>
    <div id="teletalk-fab-menu">
      <div style="font-size: 11px; font-weight: 700; color: #006a4e; text-transform: uppercase; letter-spacing: 0.05em; padding: 4px 6px 8px; border-bottom: 1px solid #dde8e2; margin-bottom: 8px;">Select Profile</div>
      <div id="teletalk-fab-profiles" style="display: flex; flex-direction: column; gap: 6px; max-height: 200px; overflow-y: auto; padding-right: 2px; margin-bottom: 8px;">
        <!-- Loaded profiles here -->
      </div>
      <div style="height: 1px; background: #dde8e2; margin: 8px 0;"></div>
      <button id="teletalk-btn-clear" class="teletalk-fab-btn teletalk-btn-danger">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6M14 11v6"/></svg>
        Clear Form
      </button>
      <button id="teletalk-btn-manage" class="teletalk-fab-btn" style="background: #e8f5f1; color: #006a4e; margin-top: 6px; width: 100%;">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
        Manage Dashboard
      </button>
      <div id="teletalk-fab-status"></div>
    </div>
  `;

  document.body.appendChild(wrapper);
  floatingBtn = wrapper;

  // Toggle dropdown menu
  wrapper.querySelector("#teletalk-fab-main").addEventListener("click", () => {
    const opening = !wrapper.classList.contains("open");
    wrapper.classList.toggle("open");
    if (opening) {
      updateFABProfilesList(wrapper);
    }
  });

  // Clear action button
  wrapper.querySelector("#teletalk-btn-clear").addEventListener("click", () => {
    clearAllFields();
    const status = wrapper.querySelector("#teletalk-fab-status");
    setTeletalkStatusIcon(status, "Form cleared", "success");
    setTimeout(() => { status.textContent = ""; wrapper.classList.remove("open"); }, 1500);
  });

  // Open Options page
  wrapper.querySelector("#teletalk-btn-manage").addEventListener("click", () => {
    chrome.runtime.sendMessage({ action: "OPEN_OPTIONS" });
    wrapper.classList.remove("open");
  });

  // Close popup menu on click outside
  document.addEventListener("click", (e) => {
    if (!wrapper.contains(e.target)) wrapper.classList.remove("open");
  });
}

function updateFABProfilesList(wrapper) {
  const profilesContainer = wrapper.querySelector("#teletalk-fab-profiles");
  if (!profilesContainer) return;

  chrome.storage.local.get(["profiles", "settings"], (data) => {
    const profiles = data.profiles || [];
    const settings = data.settings || {};

    profilesContainer.innerHTML = "";

    if (profiles.length === 0) {
      profilesContainer.innerHTML = `<div style="font-size: 11px; color: #8fa89e; padding: 6px;">No profiles found</div>`;
      return;
    }

    profiles.forEach((p) => {
      const btn = document.createElement("button");
      btn.className = "teletalk-fab-btn teletalk-fab-profile-btn";
      btn.style.width = "100%";
      btn.style.justifyContent = "flex-start";
      btn.style.margin = "2px 0";

      if (p.id === settings.activeProfileId) {
        btn.classList.add("active");
        btn.style.borderLeft = "3px solid #006a4e";
        btn.style.background = "#e6f4ef";
      }

      const lockIcon = p._enc ? '<svg class="teletalk-inline-icon" viewBox="0 0 24 24" aria-label="Encrypted" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg>' : "";
      btn.innerHTML = `
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" style="margin-right: 4px;"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
        <span style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; flex: 1; text-align: left;">
          ${p.profileName || p.applicant_name_en || "Unnamed"}
        </span>
        ${lockIcon}
      `;

      btn.addEventListener("click", async () => {
        const status = wrapper.querySelector("#teletalk-fab-status");
        status.textContent = "Loading profile...";

        let profile = p;
        if (p._enc) {
          const decrypted = await promptForPasswordAndDecrypt(p);
          if (!decrypted) {
            setTeletalkStatusIcon(status, "Decryption cancelled", "warning");
            setTimeout(() => { status.textContent = ""; }, 2500);
            return;
          }
          profile = decrypted;
        }

        status.textContent = "Filling form...";

        // Set active in storage
        settings.activeProfileId = p.id;
        chrome.storage.local.set({ settings });

        const count = await autoFillForm(profile);
        setTeletalkStatusIcon(status, count > 0 ? `Filled ${count} fields` : "No matching fields found", count > 0 ? "success" : "warning");

        // Highlight active profile
        wrapper.querySelectorAll(".teletalk-fab-profile-btn").forEach((b) => {
          b.classList.remove("active");
          b.style.borderLeft = "";
          b.style.background = "";
        });
        btn.classList.add("active");
        btn.style.borderLeft = "3px solid #006a4e";
        btn.style.background = "#e6f4ef";

        setTimeout(() => { status.textContent = ""; wrapper.classList.remove("open"); }, 2500);
      });

      profilesContainer.appendChild(btn);
    });
  });
}

// ─── Greedy Bipartite Matching Engine ─────────────────────────────────────────
async function autoFillForm(profile) {
  fillCount = 0;

  // Scan and clean list of form inputs
  const allInputs = Array.from(document.querySelectorAll(
    "input:not([type=hidden]):not([type=submit]):not([type=button]):not([type=image]):not([type=reset]), select, textarea"
  ));

  if (debugMode) {
    console.log("Teletalk Job Apply: Scanning DOM elements count =", allInputs.length);
  }

  // Prioritize the four education dropdowns used by the standard Teletalk form.
  // Their IDs are stable and their labels are duplicated across SSC/HSC sections,
  // so resolving them by generic label matching can be ambiguous.
  const prefilledElements = new Set();
  const prefilledFields = new Set();

  // Exact Teletalk identity/quota/status dropdowns.
  // NID and birth registration are Yes/No flags driven by whether a number
  // exists in the saved profile; departmental status is always Not Applicable.
  const setExactSelect = (id, value, description) => {
    const el = document.getElementById(id);
    if (!el || el.tagName.toLowerCase() !== "select") return false;
    const option = Array.from(el.options).find(o => o.value === String(value));
    if (!option) {
      if (debugMode) console.warn(`Teletalk Job Apply: ${description} option missing`, value);
      return false;
    }
    el.value = option.value;
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    prefilledElements.add(el);
    if (debugMode) console.log(`Teletalk Job Apply: ${description}:`, option.text, option.value);
    fillCount++;
    return true;
  };

  // Graduation (GRA) uses exact Teletalk IDs. The examination selection
  // refreshes the dependent subject list; institute selection can refresh it
  // again, so wait for the site's onchange handlers before selecting dependents.
  const normalizeOptionText = (value) => String(value ?? "")
    .toLowerCase()
    .replace(/&amp;/g, "&")
    .replace(/[^a-z0-9]+/g, "");

  const waitForSelectOptions = (el, previousSignature, timeout = 2200) => new Promise(resolve => {
    if (!el) return resolve();
    const signature = () => Array.from(el.options).map(o => `${o.value}:${o.text}`).join("|");
    if (signature() !== previousSignature) return setTimeout(resolve, 150);
    let finished = false;
    const done = () => {
      if (finished) return;
      finished = true;
      observer.disconnect();
      resolve();
    };
    const observer = new MutationObserver(() => {
      if (signature() !== previousSignature) {
        observer.disconnect();
        setTimeout(done, 150);
      }
    });
    observer.observe(el, { childList: true, subtree: true, attributes: true });
    setTimeout(done, timeout);
  });

  const setExactSelectMatch = (id, rawValue, description, aliases = {}) => {
    const el = document.getElementById(id);
    const value = String(rawValue ?? "").trim();
    if (!el || el.tagName.toLowerCase() !== "select" || !value) return false;

    const normalized = normalizeOptionText(value);
    const aliasValue = aliases[value.toLowerCase()] ?? aliases[normalized];
    const options = Array.from(el.options);
    const target = options.find(o => o.value === String(aliasValue)) ||
      options.find(o => o.value.toLowerCase() === value.toLowerCase()) ||
      options.find(o => normalizeOptionText(o.text) === normalized) ||
      options.find(o => normalizeOptionText(o.text).includes(normalized) ||
                        normalized.includes(normalizeOptionText(o.text)));

    if (!target || !target.value) {
      if (debugMode) console.warn(`Teletalk Job Apply: ${description} option not found`, value,
        options.map(o => ({ text: o.text, value: o.value })));
      return false;
    }
    el.value = target.value;
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    prefilledElements.add(el);
    prefilledFields.add(description);
    fillCount++;
    if (debugMode) console.log(`Teletalk Job Apply: ${description}:`, target.text, target.value);
    return true;
  };

  const graExamAliases = {
    "bsc_engr": "1", "bsc engineering": "1", "b.sc engineering": "1",
    "bsc": "4", "ba": "4", "bss": "4", "bbs": "4", "llb": "4",
    "honours": "4", "honors": "4", "pass_course": "5",
    "degree pass course": "5", "mbbs": "3", "mbbs/bds": "3",
    "bba": "7", "other": "8", "other equivalent degree": "8",
    "graduation equivalent": "8", "fazil": "6"
  };

  const graExam = document.getElementById("gra_exam");
  const graSubject = document.getElementById("gra_subject");
  const graInstitute = document.getElementById("gra_institute");

  const savedGraExam = profile.honours_examination;
  if (savedGraExam) {
    const oldSubjectSignature = graSubject
      ? Array.from(graSubject.options).map(o => `${o.value}:${o.text}`).join("|") : "";
    setExactSelectMatch("gra_exam", savedGraExam, "Graduation Examination", graExamAliases);
    await waitForSelectOptions(graSubject, oldSubjectSignature);
  }

  if (profile.honours_university) {
    const oldSubjectSignature = graSubject
      ? Array.from(graSubject.options).map(o => `${o.value}:${o.text}`).join("|") : "";
    setExactSelectMatch("gra_institute", profile.honours_university, "Graduation University");
    await waitForSelectOptions(graSubject, oldSubjectSignature);
  }

  if (profile.honours_subject) {
    setExactSelectMatch("gra_subject", profile.honours_subject, "Graduation Subject");
  }

  if (profile.honours_result_type) {
    setExactSelectMatch("gra_result_type", profile.honours_result_type, "Graduation Result Type");
  } else if (profile.honours_result) {
    const resultText = String(profile.honours_result).trim().toLowerCase();
    const inferredResultType =
      /1st\s*class|first\s*class/.test(resultText) ? "1" :
      /2nd\s*class|second\s*class/.test(resultText) ? "2" :
      /passed|pass/.test(resultText) ? "6" :
      /(?:\/|out of)\s*4\b/.test(resultText) ? "4" :
      /(?:\/|out of)\s*5\b/.test(resultText) ? "5" : "";
    if (inferredResultType) {
      setExactSelectMatch("gra_result_type", inferredResultType, "Graduation Result Type");
    } else if (debugMode) {
      console.warn("Teletalk Job Apply: Graduation result scale not specified; select Result Type in saved profile.");
    }
  }

  // The result scale dropdown can trigger Teletalk's onchange handler, which
  // may populate the adjacent numeric result box with the scale value (e.g. 4).
  // Always write the saved GPA/CGPA into the separate numeric result field.
  if (profile.honours_result !== undefined && profile.honours_result !== null &&
      String(profile.honours_result).trim() !== "") {
    const graResultInput =
      document.getElementById("gra_result") ||
      document.getElementById("gra_cgpa") ||
      document.querySelector('input[name="gra_result"], input[name="gra_cgpa"]') ||
      document.getElementById("gra_result_type")?.parentElement?.querySelector('input[type="text"], input[type="number"]');
    if (graResultInput && /^(INPUT|TEXTAREA)$/.test(graResultInput.tagName)) {
      fillTextInput(graResultInput, String(profile.honours_result).trim());
      prefilledElements.add(graResultInput);
      prefilledFields.add("Graduation Result / CGPA");
      if (debugMode) {
        console.log("Teletalk Job Apply: Graduation numeric result filled:",
          graResultInput.id || graResultInput.name, graResultInput.value);
      }
    } else if (debugMode) {
      console.warn("Teletalk Job Apply: Graduation numeric result input not found.");
    }
  }

  if (profile.honours_passing_year) {
    setExactSelectMatch("gra_year", profile.honours_passing_year, "Graduation Passing Year");
  }
  if (profile.honours_duration) {
    const duration = String(profile.honours_duration).trim().replace(/^0+/, "");
    setExactSelectMatch("gra_duration", profile.honours_duration, "Graduation Course Duration", {
      "3": "03", "3years": "03", "4": "04", "4years": "04", "5": "05", "5years": "05"
    });
    // Also accept saved values like "04 Years" via visible option text.
    if (duration && !prefilledFields.has("Graduation Course Duration")) {
      setExactSelectMatch("gra_duration", `${duration} Years`, "Graduation Course Duration");
    }
  }

  // Masters / Post Graduation uses a separate set of Teletalk fields.
  // Keep its result scale and numeric CGPA independent from Graduation.
  const masExam = document.getElementById("mas_exam");
  const masSubject = document.getElementById("mas_subject");

  if (profile.masters_examination) {
    const oldSubjectSignature = masSubject
      ? Array.from(masSubject.options).map(o => `${o.value}:${o.text}`).join("|") : "";
    setExactSelectMatch("mas_exam", profile.masters_examination,
      "Masters Examination");
    await waitForSelectOptions(masSubject, oldSubjectSignature);
  }

  if (profile.masters_university) {
    const oldSubjectSignature = masSubject
      ? Array.from(masSubject.options).map(o => `${o.value}:${o.text}`).join("|") : "";
    setExactSelectMatch("mas_institute", profile.masters_university,
      "Masters University / Institute");
    await waitForSelectOptions(masSubject, oldSubjectSignature);
  }

  if (profile.masters_subject) {
    setExactSelectMatch("mas_subject", profile.masters_subject,
      "Masters Subject / Degree");
  }

  if (profile.masters_result_type) {
    setExactSelectMatch("mas_result_type", profile.masters_result_type,
      "Masters Result Type");
  } else if (profile.masters_result) {
    const resultText = String(profile.masters_result).trim().toLowerCase();
    const inferredResultType =
      /1st\s*class|first\s*class/.test(resultText) ? "1" :
      /2nd\s*class|second\s*class/.test(resultText) ? "2" :
      /passed|pass/.test(resultText) ? "6" :
      /(?:\/|out of)\s*4\b/.test(resultText) ? "4" :
      /(?:\/|out of)\s*5\b/.test(resultText) ? "5" : "";
    if (inferredResultType) {
      setExactSelectMatch("mas_result_type", inferredResultType,
        "Masters Result Type");
    }
  }

  // Fill the actual Masters CGPA (e.g. 3.41), never the scale number (e.g. 4).
  if (profile.masters_result !== undefined && profile.masters_result !== null &&
      String(profile.masters_result).trim() !== "") {
    const masResultInput =
      document.getElementById("mas_result") ||
      document.getElementById("mas_cgpa") ||
      document.querySelector('input[name="mas_result"], input[name="mas_cgpa"]') ||
      document.getElementById("mas_result_type")?.parentElement?.querySelector(
        'input[type="text"], input[type="number"]'
      );
    if (masResultInput && /^(INPUT|TEXTAREA)$/.test(masResultInput.tagName) &&
        masResultInput.type !== "hidden") {
      fillTextInput(masResultInput, String(profile.masters_result).trim());
      prefilledElements.add(masResultInput);
      prefilledFields.add("Masters Result / CGPA");
      if (debugMode) {
        console.log("Teletalk Job Apply: Masters numeric result filled:",
          masResultInput.id || masResultInput.name, masResultInput.value);
      }
    } else if (debugMode) {
      console.warn("Teletalk Job Apply: Masters numeric result input not found.");
    }
  }

  if (profile.masters_passing_year) {
    setExactSelectMatch("mas_year", profile.masters_passing_year,
      "Masters Passing Year");
  }

  if (profile.masters_duration) {
    const duration = String(profile.masters_duration).trim();
    const digits = duration.match(/\d+/)?.[0] || duration;
    const padded = digits.length === 1 ? `0${digits}` : digits;
    setExactSelectMatch("mas_duration", duration, "Masters Course Duration", {
      "1": "01", "1year": "01", "1years": "01",
      "2": "02", "2years": "02"
    });
    if (!prefilledFields.has("Masters Course Duration")) {
      setExactSelectMatch("mas_duration", `${padded} Years`,
        "Masters Course Duration");
    }
  }

  const hasNid = String(profile.nid ?? "").trim().length > 0;
  const hasBirthRegistration = String(profile.birth_reg_no ?? "").trim().length > 0;
  const hasPassport = String(profile.passport_no ?? "").trim().length > 0;
  setExactSelect("nid", hasNid ? "1" : "0", "National ID");
  setExactSelect("breg", hasBirthRegistration ? "1" : "0", "Birth Registration");
  setExactSelect("passport", hasPassport ? "1" : "0", "Passport");
  setExactSelect("dep_status", "5", "Departmental Status");

  // The confirmation field is not represented separately in the profile.
  // Fill both mobile inputs from the same saved profile.mobile value.
  const savedMobile = String(profile.mobile ?? "").trim();
  if (savedMobile) {
    for (const mobileId of ["mobile", "confirm_mobile"]) {
      const mobileEl = document.getElementById(mobileId);
      if (mobileEl && mobileEl.tagName.toLowerCase() === "input") {
        fillTextInput(mobileEl, savedMobile);
        prefilledElements.add(mobileEl);
        if (debugMode) {
          console.log(`Teletalk Job Apply: Mobile field #${mobileId} filled from profile.mobile`);
        }
      }
    }
  }

  // Translate the profile's quota category to the exact values offered by
  // this Teletalk recruitment form. General/None is explicitly Not Applicable.
  const quotaValue = String(profile.quota ?? "").trim().toLowerCase();
  const quotaOptionValues = {
    "": "8",
    "none": "8",
    "general": "8",
    "not applicable": "8",
    "freedom_fighter": "1",
    "freedom fighter": "1",
    "child_of_freedom_fighter": "1",
    "child of freedom fighter": "1",
    "child_of_martyred_freedom_fighter": "2",
    "child of martyred freedom fighter": "2",
    "child_of_war_heroine": "3",
    "child of war heroine": "3",
    "disabled": "4",
    "physically disabled": "4",
    "physically challenged": "4",
    "tribal": "6",
    "ethnic minority": "6",
    "ethnic_minority": "6",
    "third gender": "7",
    "third_gender": "7"
  };
  const mappedQuotaValue = quotaOptionValues[quotaValue];
  if (mappedQuotaValue !== undefined) {
    setExactSelect("quota", mappedQuotaValue, "Quota");
  } else if (debugMode) {
    console.warn("Teletalk Job Apply: Saved quota has no exact equivalent in this form; left unchanged:", quotaValue);
  }

  const exactEducationFields = [
    ["ssc_exam", "ssc_examination"],
    ["ssc_group", "ssc_group"],
    ["hsc_exam", "hsc_examination"],
    ["hsc_group", "hsc_group"]
  ];

  // Teletalk keeps the GPA scale in a separate result-type dropdown.
  // The profile stores the numeric GPA (e.g. 4.67), so select GPA(out of 5)
  // when a numeric GPA is present and no explicit result-type profile field exists.
  for (const level of ["ssc", "hsc"]) {
    const resultTypeEl = document.getElementById(`${level}_result_type`);
    const resultValue = profile[`${level}_result`];
    if (!resultTypeEl || resultValue === undefined || resultValue === null ||
        String(resultValue).trim() === "") continue;

    const explicitType = profile[`${level}_result_type`];
    let targetValue = explicitType != null && String(explicitType).trim() !== ""
      ? String(explicitType).trim()
      : "";

    if (!targetValue) {
      const numericResult = Number(String(resultValue).trim());
      if (Number.isFinite(numericResult) && numericResult >= 0 && numericResult <= 5) {
        targetValue = "5"; // GPA (out of 5), standard SSC/HSC scale
      }
    }

    const target = Array.from(resultTypeEl.options).find(option => option.value === targetValue);
    if (target) {
      resultTypeEl.value = target.value;
      resultTypeEl.dispatchEvent(new Event("input", { bubbles: true }));
      resultTypeEl.dispatchEvent(new Event("change", { bubbles: true }));
      fillCount++;
      if (debugMode) {
        console.log(`Teletalk Job Apply: ${level.toUpperCase()} result type selected:`,
          target.text, target.value);
      }
      prefilledElements.add(resultTypeEl);
    } else if (debugMode) {
      console.warn(`Teletalk Job Apply: Could not resolve ${level} result type`,
        resultValue, Array.from(resultTypeEl.options).map(o => [o.text, o.value]));
    }
  }

  for (const [elementId, fieldKey] of exactEducationFields) {
    const el = document.getElementById(elementId);
    const config = FIELD_MAP[fieldKey];
    if (!el || !config || el.tagName.toLowerCase() !== "select") continue;

    const value = profile[config.profileKey];
    if (value === undefined || value === null || String(value).trim() === "") continue;

    if (debugMode) {
      console.log(`Teletalk Job Apply: Exact education match "${fieldKey}" -> #${elementId}`, value);
    }

    const educationOptionValues = {
      ssc_exam: {
        "ssc": "1", "s.s.c": "1", "s.s.c.": "1",
        "dakhil": "2", "ssc vocational": "3", "vocational": "3",
        "o-level": "4", "o level": "4", "o level/cambridge": "4",
        "ssc_equivalent": "5", "equivalent": "5", "dakhil vocational": "6"
      },
      ssc_group: {
        "science": "1", "humanities": "2", "business_studies": "3",
        "business studies": "3", "commerce": "3", "general": "4", "other": "99"
      },
      hsc_exam: {
        "hsc": "1", "h.s.c": "1", "h.s.c.": "1", "alim": "2",
        "business management": "3", "diploma": "4",
        "diploma-in-engineering": "4", "a-level": "5", "a level": "5",
        "hsc_equivalent": "6", "equivalent": "6",
        "diploma in medical technology": "7", "hsc bm": "9",
        "diploma in pharmacy": "10"
      },
      hsc_group: {
        "science": "1", "humanities": "2", "business_studies": "3",
        "business studies": "3", "commerce": "3", "general": "4", "other": "99"
      }
    };

    const normalizedProfileValue = String(value).trim().toLowerCase();
    const mappedOptionValue = educationOptionValues[elementId]?.[normalizedProfileValue];
    const targetOption = mappedOptionValue
      ? Array.from(el.options).find(option => option.value === mappedOptionValue)
      : Array.from(el.options).find(option =>
          option.value.toLowerCase() === normalizedProfileValue ||
          option.text.trim().toLowerCase() === normalizedProfileValue
        );

    if (targetOption) {
      // Match the simple, verified selection behavior from the browser-console test.
      el.value = targetOption.value;
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
      fillCount++;
      if (debugMode) {
        console.log(`Teletalk Job Apply: Education selected #${elementId}:`,
          value, "=>", targetOption.text, "(", targetOption.value, ")");
      }
    } else if (debugMode) {
      console.warn(`Teletalk Job Apply: No option for #${elementId}; profile value:`, value,
        "Available:", Array.from(el.options).map(option => [option.text, option.value]));
    }

    highlightElement(el);
    prefilledElements.add(el);
    prefilledFields.add(fieldKey);
  }

  // Create candidates list for remaining fields
  const candidates = [];

  for (const el of allInputs) {
    const type = (el.type || "").toLowerCase();
    const tag = el.tagName.toLowerCase();
    const isRadio = type === "radio";
    const isCheckbox = type === "checkbox";

    for (const [fieldKey, config] of Object.entries(FIELD_MAP)) {
      const value = profile[config.profileKey];
      if (value === undefined || value === null || value === "") continue;

      let score = scoreElement(el, config);

      // Handle radio groups explicitly
      if (isRadio && config.type.includes("radio")) {
        const matchesVal = checkRadioValueMatches(el, value, config.optionMap);
        if (matchesVal) {
          score += 150; // Massively boost matching radio buttons
        } else {
          score = 0; // Filter out non-matching radios to avoid wrong checks
        }
      }

      // Prevent non-radio inputs from matching radio/checkbox configs and vice versa
      if (isRadio && !config.type.includes("radio")) score = 0;
      if (isCheckbox && !config.type.includes("checkbox") && !config.type.includes("radio")) score = 0;

      if (score > 30) {
        candidates.push({ el, fieldKey, config, value, score });
      }
    }
  }

  // Sort candidates by highest score first
  candidates.sort((a, b) => b.score - a.score);

  const assignedElements = new Set(prefilledElements);
  const assignedFields = new Set(prefilledFields);
  const delayedFills = []; // For dependent select chains (e.g. district -> upazila)

  for (const cand of candidates) {
    const { el, fieldKey, config, value, score } = cand;
    const type = (el.type || "").toLowerCase();

    // Element was already matched/filled (skip for radio since multiple elements share a group)
    if (type !== "radio" && assignedElements.has(el)) continue;

    // Field already mapped (since all personal fields should be mapped strictly 1-to-1)
    if (assignedFields.has(fieldKey)) continue;

    // Lock assignments
    if (type !== "radio") assignedElements.add(el);
    assignedFields.add(fieldKey);

    if (debugMode) {
      console.log(`Teletalk Job Apply Match: Field "${fieldKey}" -> <${el.tagName.toLowerCase()}> (Score: ${score}) Value:`, value);
    }

    // Check if this is a dependent field (upazila depends on district selection)
    const isDependentField = fieldKey.includes("upazila") || fieldKey.includes("post_office");
    if (isDependentField && el.tagName.toLowerCase() === "select") {
      delayedFills.push({ el, value, config, fieldKey });
    } else {
      // Perform the actual filling
      fillElement(el, value, config);
      // Apply soft glow highlight
      highlightElement(el);
    }
  }

  // Process delayed fills with staggered timing for dependent selects
  if (delayedFills.length > 0) {
    delayedFills.forEach((item, idx) => {
      setTimeout(() => {
        fillElement(item.el, item.value, item.config);
        highlightElement(item.el);
        if (debugMode) {
          console.log(`Teletalk Job Apply Delayed Fill: "${item.fieldKey}" ->`, item.value);
        }
      }, 500 + (idx * 400)); // Stagger by 400ms each after initial 500ms delay
    });
  }

  return fillCount;
}

// ─── Match Scoring Logic ──────────────────────────────────────────────────────
function scoreElement(el, config) {
  const { patterns } = config;
  let score = 0;
  const name = (el.name || "").toLowerCase();
  const id = (el.id || "").toLowerCase();
  const placeholder = (el.placeholder || "").toLowerCase();
  const className = (typeof el.className === "string" ? el.className : "").toLowerCase();
  const type = (el.type || "").toLowerCase();
  const tag = el.tagName.toLowerCase();
  const labelText = getLabelText(el).toLowerCase();

  // Strict type constraints to prevent files matching text/selects and vice-versa
  const isElFile = type === "file";
  const isConfigFile = config.type === "file_image";
  if (isElFile !== isConfigFile) {
    return 0;
  }

  // Prevent text-only configs from matching select elements and vice-versa
  const isElSelect = tag === "select";
  const isElTextarea = tag === "textarea";
  const isElTextInput = tag === "input" && !isElFile && type !== "radio" && type !== "checkbox";
  
  const configAcceptsSelect = config.type.includes("select");
  const configAcceptsText = config.type === "text" || config.type.includes("text") || config.type.includes("textarea");

  // Select elements should only match configs that accept selects
  if (isElSelect && !configAcceptsSelect) {
    return 0;
  }

  // Skip empty name/id elements for non-obvious matches to avoid false positives
  if (!name && !id && !placeholder && !labelText) {
    return 0;
  }

  // Exact Name attribute match
  if (patterns.names && patterns.names.some((p) => name === p.toLowerCase())) {
    score += 100;
  } else if (name && patterns.names && patterns.names.some((p) => name.includes(p.toLowerCase()) || p.toLowerCase().includes(name))) {
    // Only do fuzzy match if name has reasonable length to prevent short-name false positives
    if (name.length > 2) score += 70;
  }

  // ID attribute match
  if (patterns.ids && patterns.ids.some((p) => id === p.toLowerCase())) {
    score += 90;
  } else if (id && patterns.ids && patterns.ids.some((p) => id.includes(p.toLowerCase()) || p.toLowerCase().includes(id))) {
    if (id.length > 2) score += 60;
  }

  // Label text match (Highly important for Bangla text recognition)
  if (patterns.labels) {
    for (const lp of patterns.labels) {
      const lpLower = lp.toLowerCase();
      if (labelText === lpLower) {
        score += 85;
        break;
      }
      if (labelText.includes(lpLower) || lpLower.includes(labelText)) {
        // Avoid false match on very short label text  
        if (labelText.length > 3) {
          score += 55;
          break;
        }
      }
    }
  }

  // Placeholder match
  if (patterns.placeholders && patterns.placeholders.some((pp) => placeholder.includes(pp.toLowerCase()))) {
    score += 35;
  }

  // Class name match (lower weight to avoid false positives)
  if (patterns.names && patterns.names.some((p) => p.length > 3 && className.includes(p.toLowerCase()))) {
    score += 15;
  }

  // Boost score for address components based on location context
  const isPresentAddressField = patterns.names && patterns.names.some(p => p.includes("present"));
  const isPermanentAddressField = patterns.names && patterns.names.some(p => p.includes("permanent") || p.includes("perm"));

  if (isPresentAddressField && (name.includes("present") || id.includes("present") || labelText.includes("present") || labelText.includes("বর্তমান"))) {
    score += 40;
  }
  if (isPermanentAddressField && (name.includes("permanent") || name.includes("perm") || id.includes("permanent") || id.includes("perm") || labelText.includes("permanent") || labelText.includes("স্থায়ী"))) {
    score += 40;
  }
  
  // Penalize address cross-contamination: present config shouldn't match permanent elements
  if (isPresentAddressField && (name.includes("permanent") || name.includes("perm") || id.includes("permanent") || id.includes("perm") || labelText.includes("permanent") || labelText.includes("স্থায়ী"))) {
    score -= 80;
  }
  if (isPermanentAddressField && (name.includes("present") || id.includes("present") || labelText.includes("present") || labelText.includes("বর্তমান"))) {
    score -= 80;
  }

  // Boost for education roll/result mismatch prevention (e.g. ssc vs hsc)
  const isSscField = patterns.names && patterns.names.some(p => p.includes("ssc"));
  const isHscField = patterns.names && patterns.names.some(p => p.includes("hsc"));
  const isHonoursField = patterns.names && patterns.names.some(p => p.includes("honours") || p.includes("bach"));
  const isMastersField = patterns.names && patterns.names.some(p => p.includes("masters"));

  if (isSscField && (name.includes("ssc") || id.includes("ssc") || labelText.includes("ssc"))) score += 40;
  if (isHscField && (name.includes("hsc") || id.includes("hsc") || labelText.includes("hsc"))) score += 40;
  if (isHonoursField && (name.includes("honours") || name.includes("bachelor") || id.includes("honours") || labelText.includes("honours") || labelText.includes("graduation"))) score += 40;
  if (isMastersField && (name.includes("masters") || id.includes("masters") || labelText.includes("masters") || labelText.includes("post graduation"))) score += 40;

  // Penalize education cross-contamination
  if (isSscField && !isHscField && (name.includes("hsc") || id.includes("hsc"))) score -= 60;
  if (isHscField && !isSscField && (name.includes("ssc") || id.includes("ssc"))) score -= 60;
  if (isSscField && (name.includes("honours") || name.includes("masters") || id.includes("honours") || id.includes("masters"))) score -= 60;
  if (isHscField && (name.includes("honours") || name.includes("masters") || id.includes("honours") || id.includes("masters"))) score -= 60;
  if (isHonoursField && (name.includes("ssc") || name.includes("hsc") || name.includes("masters"))) score -= 60;
  if (isMastersField && (name.includes("ssc") || name.includes("hsc") || name.includes("honours"))) score -= 60;

  return Math.max(0, score);
}

function checkRadioValueMatches(el, profileValue, optionMap) {
  const elVal = el.value.toLowerCase().trim();
  const elLabel = getLabelText(el).toLowerCase().trim();
  const targetVal = profileValue.toString().toLowerCase().trim();

  // Direct match
  if (elVal === targetVal || elLabel === targetVal) return true;

  if (optionMap) {
    // Find which optionMap group the profile value belongs to (check both key and aliases)
    let matchedAliases = null;
    for (const [key, aliases] of Object.entries(optionMap)) {
      const allLower = aliases.map(a => a.toLowerCase());
      if (key.toLowerCase() === targetVal || allLower.includes(targetVal)) {
        matchedAliases = allLower;
        matchedAliases.push(key.toLowerCase()); // Include the key itself
        break;
      }
    }

    if (matchedAliases) {
      // Check if this radio element's value or label matches any alias
      if (matchedAliases.some(a => elVal === a || elLabel === a || elLabel.includes(a))) {
        return true;
      }
    }
  }
  return false;
}

// ─── Label Helper ─────────────────────────────────────────────────────────────
function getLabelText(el) {
  // Try using 'for' attribute label matching
  if (el.id) {
    const label = document.querySelector(`label[for="${el.id}"]`);
    if (label) return label.innerText.trim();
  }

  // Traverse up to find parent label tag
  let parent = el.parentElement;
  for (let i = 0; i < 5; i++) {
    if (!parent) break;

    if (parent.tagName === "LABEL") return parent.innerText.trim();

    const nearLabel = parent.querySelector("label");
    if (nearLabel && nearLabel !== el) return nearLabel.innerText.trim();

    // Look for text nodes or nearby elements acting as labels
    const childNodes = Array.from(parent.childNodes).filter(node => 
      node.nodeType === Node.TEXT_NODE || 
      (node.tagName && ["SPAN", "DIV", "TD", "TH"].includes(node.tagName))
    );

    for (const node of childNodes) {
      const text = (node.textContent || node.innerText || "").trim();
      if (text && text.length > 2 && text.length < 100) {
        if (!/^\d+$/.test(text) && !text.includes("select") && !text.includes("choose")) {
          return text;
        }
      }
    }

    // Check sibling cells in case of table layouts
    if (parent.tagName === "TD" || parent.tagName === "DIV" || parent.tagName === "TR") {
      const prev = parent.previousElementSibling;
      if (prev) {
        const prevText = (prev.innerText || prev.textContent || "").trim();
        if (prevText && prevText.length > 2 && prevText.length < 100) return prevText;
      }
    }

    parent = parent.parentElement;
  }

  // Aria label indicators
  if (el.getAttribute("aria-label")) return el.getAttribute("aria-label").trim();
  if (el.title) return el.title.trim();

  return "";
}

// ─── Element Filler Methods ───────────────────────────────────────────────────
function fillElement(el, value, config) {
  const tag = el.tagName.toLowerCase();
  const type = (el.type || "").toLowerCase();

  if (tag === "select") {
    const success = fillSelect(el, value, config.optionMap);
    if (!success) {
      queueDynamicSelectFill(el, value, config);
    }
  } else if (type === "radio") {
    fillRadioGroup(el, value, config.optionMap);
  } else if (type === "checkbox") {
    fillCheckbox(el, value, config.optionMap);
  } else if (type === "file") {
    fillFileInput(el, value, config);
  } else if (tag === "textarea") {
    fillTextArea(el, value);
  } else {
    fillTextInput(el, value);
  }
}

function fillTextInput(el, value) {
  if (el.value === String(value)) return;

  // Do not force focus during automated filling. Some sites attach focus
  // handlers that call showPicker(), which Chrome blocks without a user gesture.
  let val = String(value);

  // Format date inputs automatically if necessary
  if (el.type === "date") {
    if (typeof value === "string" && value.match(/^\d{2}\/\d{2}\/\d{4}$/)) {
      const parts = value.split("/");
      val = `${parts[2]}-${parts[1]}-${parts[0]}`;
    }
  }

  el.value = "";

  // React/Angular/Vue compatible: use native prototype setter for input elements
  const nativeInputSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement?.prototype || {}, "value")?.set;

  if (nativeInputSetter) {
    nativeInputSetter.call(el, val);
  } else {
    el.value = val;
  }

  el.setAttribute("value", val);
  triggerEvents(el);
  fillCount++;
}

function fillTextArea(el, value) {
  if (el.value === String(value)) return;

  // Avoid programmatic focus; site focus handlers may invoke showPicker()
  // and throw NotAllowedError outside a user gesture.
  const val = String(value);

  // Use native textarea setter for React/Angular/Vue framework compatibility
  const nativeTextAreaSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement?.prototype || {}, "value")?.set;

  if (nativeTextAreaSetter) {
    nativeTextAreaSetter.call(el, val);
  } else {
    el.value = val;
  }

  // Textareas don't use setAttribute("value") — they use textContent internally
  triggerEvents(el);
  fillCount++;
}

const activeSelectObservers = new Map();

function queueDynamicSelectFill(el, value, config) {
  if (activeSelectObservers.has(el)) {
    activeSelectObservers.get(el).value = value;
    return;
  }

  if (debugMode) {
    console.log("Teletalk Job Apply: Queued select for dynamic mutations:", el);
  }

  const observer = new MutationObserver(() => {
    const success = fillSelect(el, value, config.optionMap);
    if (success) {
      if (debugMode) console.log("Teletalk Job Apply: Dynamic fill succeeded for select:", el);
      observer.disconnect();
      activeSelectObservers.delete(el);
    }
  });

  observer.observe(el, { childList: true });
  activeSelectObservers.set(el, { observer, value });

  // Clean up observer to prevent leaks after 8 seconds
  setTimeout(() => {
    if (activeSelectObservers.has(el) && activeSelectObservers.get(el).observer === observer) {
      observer.disconnect();
      activeSelectObservers.delete(el);
    }
  }, 8000);
}

function fillSelect(el, value, optionMap) {
  const valueLower = value.toString().toLowerCase().trim();

  // 1. Try exact matches on text/value
  for (const opt of el.options) {
    const optText = opt.text.toLowerCase().trim();
    const optValue = opt.value.toLowerCase().trim();

    if (optText === valueLower || optValue === valueLower) {
      if (el.value !== opt.value) {
        el.value = opt.value;
        triggerEvents(el);
        fillCount++;
      }
      return true;
    }
  }

  // 2. Try optionMap aliases — match profile value against both keys and alias lists
  if (optionMap) {
    // First, find which optionMap key the profile value corresponds to
    let matchedAliases = null;
    for (const [key, aliases] of Object.entries(optionMap)) {
      const allLower = aliases.map(a => a.toLowerCase());
      if (key.toLowerCase() === valueLower || allLower.includes(valueLower)) {
        matchedAliases = allLower;
        break;
      }
    }

    if (matchedAliases) {
      // Now try to find a DOM option that matches any of the aliases
      let bestMatch = null;
      let bestScore = 0;
      for (const opt of el.options) {
        const optText = opt.text.toLowerCase().trim();
        const optValue = opt.value.toLowerCase().trim();
        
        // Exact matches on aliases score highest
        if (matchedAliases.includes(optValue)) {
          bestMatch = opt;
          bestScore = 100;
          break;
        }
        if (matchedAliases.includes(optText)) {
          bestMatch = opt;
          bestScore = 95;
          break;
        }
        // Partial match
        for (const alias of matchedAliases) {
          if (optText.includes(alias) || alias.includes(optText)) {
            const s = optText === alias ? 90 : 70;
            if (s > bestScore && optText.length > 1) {
              bestScore = s;
              bestMatch = opt;
            }
          }
          if (optValue.includes(alias)) {
            const s = optValue === alias ? 85 : 60;
            if (s > bestScore && optValue.length > 0) {
              bestScore = s;
              bestMatch = opt;
            }
          }
        }
      }

      if (bestMatch) {
        if (el.value !== bestMatch.value) {
          el.value = bestMatch.value;
          triggerEvents(el);
          fillCount++;
        }
        return true;
      }
    }
  }

  // 3. Fallback to partial matches on raw value
  const partialMatches = [];
  for (const opt of el.options) {
    const optText = opt.text.toLowerCase().trim();
    const optValue = opt.value.toLowerCase().trim();

    if ((optText.includes(valueLower) || valueLower.includes(optText)) && optText.length > 1) {
      partialMatches.push({ opt, score: optText === valueLower ? 100 : 60 });
    }
    if (optValue.includes(valueLower) && optValue.length > 0) {
      partialMatches.push({ opt, score: optValue === valueLower ? 90 : 50 });
    }
  }

  if (partialMatches.length > 0) {
    partialMatches.sort((a, b) => b.score - a.score);
    const bestOpt = partialMatches[0].opt;
    if (el.value !== bestOpt.value) {
      el.value = bestOpt.value;
      triggerEvents(el);
      fillCount++;
    }
    return true;
  }

  return false;
}

function fillRadioGroup(el, value, optionMap) {
  const valueLower = value.toString().toLowerCase().trim();
  const radios = document.querySelectorAll(`input[type=radio][name="${el.name}"]`);

  // Build the list of aliases to match against (includes raw value + optionMap aliases)
  let matchTargets = [valueLower];

  if (optionMap) {
    for (const [key, aliases] of Object.entries(optionMap)) {
      const allLower = aliases.map(a => a.toLowerCase());
      if (key.toLowerCase() === valueLower || allLower.includes(valueLower)) {
        matchTargets = [...new Set([...allLower, key.toLowerCase(), valueLower])];
        break;
      }
    }
  }

  for (const radio of radios) {
    const radioVal = radio.value.toLowerCase().trim();
    const radioLabel = getLabelText(radio).toLowerCase().trim();

    const isMatch = matchTargets.some(t => 
      radioVal === t || radioLabel === t || radioLabel.includes(t)
    );

    if (isMatch) {
      if (!radio.checked) {
        radio.checked = true;
        triggerEvents(radio);
        fillCount++;
      }
      return;
    }
  }
}

function fillCheckbox(el, value, optionMap) {
  const valueLower = value.toString().toLowerCase().trim();
  const elVal = el.value.toLowerCase().trim();
  const shouldCheck = valueLower === "true" || valueLower === "1" || valueLower === "yes" || elVal === valueLower;

  if (el.checked !== shouldCheck) {
    el.checked = shouldCheck;
    triggerEvents(el);
    fillCount++;
  }
}

function fillFileInput(el, dataURL, config) {
  if (!dataURL || typeof dataURL !== "string" || !dataURL.startsWith("data:")) return;

  try {
    const arr = dataURL.split(",");
    const mime = arr[0].match(/:(.*?);/)[1];
    const bstr = atob(arr[1]);
    let n = bstr.length;
    const u8arr = new Uint8Array(n);
    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }

    let filename = "document.jpg";
    if (config.profileKey === "profilePhoto") {
      filename = "profile_photo.jpg";
    } else if (config.profileKey === "signature") {
      filename = "signature.jpg";
    }

    const file = new File([u8arr], filename, { type: mime });
    const dataTransfer = new DataTransfer();
    dataTransfer.items.add(file);
    el.files = dataTransfer.files;

    triggerEvents(el);
    fillCount++;

    // Visual feedback overlay
    showFileInputFeedback(el, filename);
  } catch (error) {
    console.warn("Teletalk Job Apply: File upload failed:", error);
  }
}

function showFileInputFeedback(fileInput, filename) {
  let feedback = fileInput.parentNode.querySelector(".teletalk-file-feedback");
  if (feedback) feedback.remove();

  feedback = document.createElement("div");
  feedback.className = "teletalk-file-feedback";
  feedback.style.cssText = `
    font-size: 11px;
    color: #006a4e;
    margin-top: 5px;
    padding: 5px 10px;
    background: #e6f4ef;
    border-radius: 6px;
    border-left: 3px solid #006a4e;
    font-weight: 500;
  `;
  setTeletalkStatusIcon(feedback, `Auto-attached: ${filename}`, "success");
  fileInput.parentNode.appendChild(feedback);
}

// ─── Dispatch Events ──────────────────────────────────────────────────────────
function triggerEvents(el) {
  // Focus event first (some frameworks need this)
  el.dispatchEvent(new Event("focus", { bubbles: true }));
  
  // Keyboard events to simulate actual typing (important for some form validators)
  el.dispatchEvent(new Event("keydown", { bubbles: true }));
  el.dispatchEvent(new Event("keypress", { bubbles: true }));
  el.dispatchEvent(new Event("keyup", { bubbles: true }));
  
  // Core form events
  el.dispatchEvent(new Event("input", { bubbles: true }));
  el.dispatchEvent(new Event("change", { bubbles: true }));
  el.dispatchEvent(new Event("blur", { bubbles: true }));

  // Direct invoke support for legacy inline HTML event handlers (e.g. onchange="load_upazila()")
  if (typeof el.onchange === "function") {
    try {
      el.onchange();
    } catch (e) {
      if (debugMode) console.warn("Teletalk Job Apply: Legacy onchange trigger error:", e);
    }
  }
  if (typeof el.oninput === "function") {
    try {
      el.oninput();
    } catch (e) {
      if (debugMode) console.warn("Teletalk Job Apply: Legacy oninput trigger error:", e);
    }
  }
}

// ─── Visual Highlighter ───────────────────────────────────────────────────────
function highlightElement(el) {
  el.classList.add("teletalk-autofilled");
  
  // Custom temporary CSS style to flash element
  const originalTransition = el.style.transition;
  el.style.transition = "all 0.4s ease";
  el.style.boxShadow = "0 0 10px rgba(0, 106, 78, 0.7)";
  el.style.borderColor = "#006a4e";
  el.style.backgroundColor = "#e6f4ef";

  setTimeout(() => {
    el.style.boxShadow = "";
    el.style.borderColor = "";
    el.style.backgroundColor = "";
    setTimeout(() => {
      el.style.transition = originalTransition;
      el.classList.remove("teletalk-autofilled");
    }, 400);
  }, 2000);
}

// ─── Form Eraser ──────────────────────────────────────────────────────────────
function clearAllFields() {
  const allInputs = Array.from(document.querySelectorAll(
    "input:not([type=hidden]):not([type=submit]):not([type=button]):not([type=image]):not([type=reset]), select, textarea"
  ));

  for (const el of allInputs) {
    const type = (el.type || "").toLowerCase();
    const tag = el.tagName.toLowerCase();

    if (type === "checkbox" || type === "radio") {
      if (el.checked) {
        el.checked = false;
        triggerEvents(el);
      }
    } else if (tag === "select") {
      if (el.selectedIndex !== 0) {
        el.selectedIndex = 0;
        triggerEvents(el);
      }
    } else if (type === "file") {
      el.value = "";
      triggerEvents(el);
      const feedback = el.parentNode.querySelector(".teletalk-file-feedback");
      if (feedback) feedback.remove();
    } else {
      if (el.value !== "") {
        el.value = "";
        triggerEvents(el);
      }
    }
  }
}
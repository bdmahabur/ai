/**
 * popup.js — Teletalk Job Apply-Developed by Mahabur Hossain-01781040050
 */

document.addEventListener("DOMContentLoaded", () => {
  const profileSelect = document.getElementById("profile-select");
  const btnAutofill = document.getElementById("btn-autofill");
  const btnClear = document.getElementById("btn-clear");
  const statusMsg = document.getElementById("status-msg");
  const profilePreview = document.getElementById("profile-preview");
  const previewBadges = document.getElementById("preview-badges");
  const btnOpenOptions = document.getElementById("btn-open-options");
  const btnNewProfile = document.getElementById("btn-new-profile");
  const btnManage = document.getElementById("btn-manage");

  let profiles = [];
  let settings = {};

  function iconSvg(kind) {
    const paths = {
      lock: '<rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3M12 14v3"/>',
      image: '<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/>',
      signature: '<path d="M3 17c3-1 4-8 7-8 2 0 0 7 2 7 1 0 3-4 4-4 1 0 0 3 2 3h3"/><path d="M3 21h18"/>',
      alert: '<path d="M12 3 2.8 20h18.4L12 3Z"/><path d="M12 9v5m0 3h.01"/>',
      success: '<path d="m5 12 4 4L19 6"/>',
      error: '<path d="m6 6 12 12M18 6 6 18"/>'
    };
    return `<svg class="ui-inline-icon" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${paths[kind] || paths.alert}</svg>`;
  }

  // ─── Load Profiles and Active Settings ──────────────────────────────────────
  function initPopup() {
    chrome.runtime.sendMessage({ action: "GET_PROFILES" }, (res) => {
      if (chrome.runtime.lastError) {
        console.warn("Teletalk Job Apply Message Error:", chrome.runtime.lastError.message);
        return;
      }
      profiles = res.profiles || [];
      settings = res.settings || {};
      renderProfiles();
    });
  }

  function renderProfiles() {
    profileSelect.innerHTML = '<option value="">-- Choose Profile --</option>';
    
    if (profiles.length === 0) {
      profilePreview.classList.add("hidden");
      return;
    }

    profiles.forEach((p) => {
      const opt = document.createElement("option");
      opt.value = p.id;
      const prefix = p._enc ? "Encrypted · " : "";
      opt.textContent = prefix + (p.profileName || p.applicant_name_en || "Unnamed Profile");
      
      if (p.id === settings.activeProfileId) {
        opt.selected = true;
      }
      profileSelect.appendChild(opt);
    });

    updatePreview();
  }

  function updatePreview() {
    const selId = profileSelect.value;
    const p = profiles.find((p) => p.id === selId);
    
    if (!p) {
      profilePreview.classList.add("hidden");
      return;
    }
    
    profilePreview.classList.remove("hidden");
    previewBadges.innerHTML = "";

    if (p._enc) {
      document.getElementById("prev-name-en").textContent = "[Encrypted]";
      document.getElementById("prev-name-bn").textContent = "[Encrypted]";
      document.getElementById("prev-mobile").textContent = "[Encrypted]";
      document.getElementById("prev-email").textContent = "[Encrypted]";
      
      const badge = document.createElement("span");
      badge.className = "preview-badge badge-locked";
      badge.innerHTML = `${iconSvg("lock")}<span>Encrypted Profile</span>`;
      previewBadges.appendChild(badge);
    } else {
      document.getElementById("prev-name-en").textContent = p.applicant_name_en || "—";
      document.getElementById("prev-name-bn").textContent = p.applicant_name_bn || "—";
      document.getElementById("prev-mobile").textContent = p.mobile || "—";
      document.getElementById("prev-email").textContent = p.email || "—";

      if (p.profilePhoto) {
        const badge = document.createElement("span");
        badge.className = "preview-badge badge-photo";
        badge.innerHTML = `${iconSvg("image")}<span>Photo Added</span>`;
        previewBadges.appendChild(badge);
      }
      if (p.signature) {
        const badge = document.createElement("span");
        badge.className = "preview-badge badge-signature";
        badge.innerHTML = `${iconSvg("signature")}<span>Signature Added</span>`;
        previewBadges.appendChild(badge);
      }
      if (!p.profilePhoto && !p.signature) {
        const badge = document.createElement("span");
        badge.className = "preview-badge badge-warn";
        badge.innerHTML = `${iconSvg("alert")}<span>No Media Attached</span>`;
        previewBadges.appendChild(badge);
      }
    }
  }

  // ─── Dropdown Event Listener ────────────────────────────────────────────────
  profileSelect.addEventListener("change", () => {
    chrome.runtime.sendMessage({
      action: "SET_ACTIVE_PROFILE",
      profileId: profileSelect.value
    }, () => {
      updatePreview();
    });
  });

  // ─── Autofill Trigger ───────────────────────────────────────────────────────
  btnAutofill.addEventListener("click", () => {
    const profileId = profileSelect.value;
    if (!profileId) {
      showStatus("Select an applicant profile first.", "warn");
      return;
    }

    btnAutofill.disabled = true;
    showStatus("Filling form fields...", "ok");

    chrome.runtime.sendMessage({ action: "AUTOFILL_PAGE", profileId }, (res) => {
      btnAutofill.disabled = false;
      if (chrome.runtime.lastError) {
        showStatus("Error interacting with form page.", "warn");
        return;
      }
      
      if (res && res.ok) {
        if (res.filled > 0) {
          showStatus(`Autofilled ${res.filled} form fields!`, "ok");
        } else {
          showStatus("No matching form inputs detected on page.", "warn");
        }
      } else {
        const errMsg = (res && res.error) ? `: ${res.error}` : "";
        showStatus(`Autofill action failed${errMsg}`, "warn");
      }
    });
  });

  // ─── Clear Form Trigger ─────────────────────────────────────────────────────
  btnClear.addEventListener("click", () => {
    chrome.runtime.sendMessage({ action: "CLEAR_FORM" }, (res) => {
      if (chrome.runtime.lastError) {
        showStatus("Error clearing form.", "warn");
        return;
      }
      if (res && res.ok) {
        showStatus("Form cleared successfully.", "ok");
      }
    });
  });

  // ─── Navigation Triggers ────────────────────────────────────────────────────
  [btnOpenOptions, btnManage].forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      chrome.runtime.openOptionsPage();
    });
  });

  btnNewProfile.addEventListener("click", (e) => {
    e.preventDefault();
    chrome.storage.local.set({ optionsAction: "new_profile" }, () => {
      chrome.runtime.openOptionsPage();
    });
  });

  // Status indicator message toast
  function showStatus(msg, type = "ok") {
    const iconKind = type === "warn" ? "alert" : type === "ok" ? "success" : "error";
    const cleanMessage = String(msg).replace(/[⚠✓❌]/g, "").trim();
    statusMsg.innerHTML = `${iconSvg(iconKind)}<span></span>`;
    statusMsg.querySelector("span").textContent = cleanMessage;
    statusMsg.className = `status-msg status-${type}`;
    statusMsg.classList.remove("hidden");
    
    clearTimeout(statusMsg._timer);
    statusMsg._timer = setTimeout(() => {
      statusMsg.classList.add("hidden");
    }, 4000);
  }

  // Load state on startup
  initPopup();
});

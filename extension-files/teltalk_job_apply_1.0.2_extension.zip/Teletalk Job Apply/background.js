/**
 * background.js — Teletalk Job Apply-Modified by Mahabur Hossain-01781040050
 * Handles messaging between the popup/options dashboard and content scripts.
 */

chrome.runtime.onInstalled.addListener(({ reason }) => {
  if (reason === "install") {
    // Initialize default storage schema
    chrome.storage.local.set({
      settings: {
        encryptionEnabled: false,
        activeProfileId: null,
        showFloatingBtn: true,
        autoDetect: true
      },
      profiles: []
    });
    // Launch options page immediately to help the user set up their first profile
    chrome.runtime.openOptionsPage();
  }
});

// Message Router
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.action) {
    case "GET_PROFILES":
      chrome.storage.local.get(["profiles", "settings"], (data) => {
        sendResponse({
          profiles: data.profiles || [],
          settings: data.settings || {}
        });
      });
      return true; // Async response

    case "SAVE_PROFILE":
      saveProfile(message.profile).then(sendResponse);
      return true;

    case "DELETE_PROFILE":
      deleteProfile(message.profileId).then(sendResponse);
      return true;

    case "GET_ACTIVE_PROFILE":
      chrome.storage.local.get(["profiles", "settings"], (data) => {
        const settings = data.settings || {};
        const profiles = data.profiles || [];
        const active = profiles.find(p => p.id === settings.activeProfileId) || profiles[0] || null;
        sendResponse({ profile: active });
      });
      return true;

    case "SET_ACTIVE_PROFILE":
      chrome.storage.local.get("settings", (data) => {
        const settings = data.settings || {};
        settings.activeProfileId = message.profileId;
        chrome.storage.local.set({ settings }, () => sendResponse({ ok: true }));
      });
      return true;

    case "UPDATE_SETTINGS":
      chrome.storage.local.get("settings", (data) => {
        const settings = Object.assign(data.settings || {}, message.settings);
        chrome.storage.local.set({ settings }, () => sendResponse({ ok: true }));
      });
      return true;

    case "AUTOFILL_PAGE":
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0] && tabs[0].id) {
          chrome.tabs.sendMessage(tabs[0].id, {
            action: "DO_AUTOFILL",
            profileId: message.profileId
          }, sendResponse);
        } else {
          sendResponse({ ok: false, error: "No active tab found" });
        }
      });
      return true;

    case "CLEAR_FORM":
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0] && tabs[0].id) {
          chrome.tabs.sendMessage(tabs[0].id, { action: "CLEAR_FORM" }, sendResponse);
        } else {
          sendResponse({ ok: false, error: "No active tab found" });
        }
      });
      return true;

    case "OPEN_OPTIONS":
      chrome.runtime.openOptionsPage();
      sendResponse({ ok: true });
      return true;

    default:
      sendResponse({ error: `Unknown action: ${message.action}` });
  }
});

// Helper functions for profile persistence
async function saveProfile(profile) {
  return new Promise((resolve) => {
    chrome.storage.local.get("profiles", (data) => {
      const profiles = data.profiles || [];
      const idx = profiles.findIndex((p) => p.id === profile.id);
      if (idx >= 0) {
        profiles[idx] = profile;
      } else {
        if (!profile.id) profile.id = "profile_" + Date.now();
        profiles.push(profile);
      }
      chrome.storage.local.set({ profiles }, () => resolve({ ok: true, id: profile.id }));
    });
  });
}

async function deleteProfile(profileId) {
  return new Promise((resolve) => {
    chrome.storage.local.get(["profiles", "settings"], (data) => {
      const profiles = (data.profiles || []).filter((p) => p.id !== profileId);
      const settings = data.settings || {};
      if (settings.activeProfileId === profileId) {
        settings.activeProfileId = profiles[0]?.id || null;
      }
      chrome.storage.local.set({ profiles, settings }, () => resolve({ ok: true }));
    });
  });
}

/**
 * content.js — Teletalk Job Apply-Modified by Mahabur Hossain-01781040050
 * Injected into Teletalk pages. Implements the greedy match scoring engine,
 * element autofilling, dynamic upazila event triggers, and floating menu buttons.
 */

let debugMode = false;
let fillCount = 0;
let floatingBtn = null;

// Initialize debug mode from storage settings
chrome.storage.local.get("settings", (data) => {
  const settings = data.settings || {};
  debugMode = settings.debugMode === true;
  if (debugMode) {
    console.log("Teletalk Job Apply: Debug mode enabled");
  }
});

// Cache password in window session to avoid prompting multiple times on page steps
window._teletalkDecryptionPassword = window._teletalkDecryptionPassword || "";

// ─── Init ─────────────────────────────────────────────────────────────────────
(function init() {
  chrome.storage.local.get("settings", (data) => {
    const settings = data.settings || {};
    if (settings.showFloatingBtn !== false) {
      injectFloatingButton();
    }
  });
})();

// ─── Message Handler ──────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "DO_AUTOFILL") {
    chrome.storage.local.get(["profiles", "settings"], async (data) => {
      const profiles = data.profiles || [];
      const settings = data.settings || {};
      const profileId = message.profileId || settings.activeProfileId;
      let profile = profiles.find((p) => p.id === profileId) || profiles[0];
      if (!profile) {
        sendResponse({ ok: false, error: "No profile found" });
        return;
      }

      // Decrypt profile data if encrypted
      if (profile._enc) {
        const decrypted = await promptForPasswordAndDecrypt(profile);
        if (!decrypted) {
          sendResponse({ ok: false, error: "Decryption cancelled or failed" });
          return;
        }
        profile = decrypted;
      }

      const count = autoFillForm(profile);
      sendResponse({ ok: true, filled: count });
    });
    return true; // Keep message channel open for async response
  }
  
  if (message.action === "CLEAR_FORM") {
    clearAllFields();
    sendResponse({ ok: true });
  }
});

// ─── Password Prompt UI ───────────────────────────────────────────────────────
async function promptForPasswordAndDecrypt(profile) {
  if (!profile || !profile._enc) return profile;

  // Try decrypting with cached password first
  if (window._teletalkDecryptionPassword) {
    try {
      const decrypted = await Encryption.decrypt(profile._enc, window._teletalkDecryptionPassword);
      if (debugMode) console.log("Teletalk Job Apply: Successfully decrypted profile using cached password.");
      return { ...decrypted, id: profile.id, profileName: profile.profileName };
    } catch (e) {
      console.warn("Cached password decryption failed.");
      window._teletalkDecryptionPassword = "";
    }
  }

  // Display a password entry modal overlay
  return new Promise((resolve) => {
    let overlay = document.getElementById("teletalk-decrypt-modal-overlay");
    if (overlay) overlay.remove();

    overlay = document.createElement("div");
    overlay.id = "teletalk-decrypt-modal-overlay";
    overlay.className = "teletalk-modal-overlay";
    overlay.innerHTML = `
      <div class="teletalk-modal">
        <div class="teletalk-modal-header">
          <span class="teletalk-modal-logo">🇧🇩</span>
          <h3 class="teletalk-modal-title">Profile Encrypted</h3>
        </div>
        <div class="teletalk-modal-body">
          The profile <strong>"${profile.profileName || "Unnamed"}"</strong> is secured with local AES encryption. Enter password to decrypt and autofill.
        </div>
        <div class="teletalk-modal-input-group">
          <label for="teletalk-decrypt-password">Password</label>
          <input type="password" id="teletalk-decrypt-password" class="teletalk-modal-input" placeholder="Enter password" autofocus>
          <div id="teletalk-decrypt-error" class="teletalk-modal-error"></div>
        </div>
        <div class="teletalk-modal-actions">
          <button type="button" id="teletalk-decrypt-cancel" class="teletalk-modal-btn teletalk-modal-btn-secondary">Cancel</button>
          <button type="button" id="teletalk-decrypt-submit" class="teletalk-modal-btn teletalk-modal-btn-primary">Decrypt & Fill</button>
        </div>
      </div>
    `;

    document.body.appendChild(overlay);
    setTimeout(() => overlay.classList.add("show"), 10);

    const input = overlay.querySelector("#teletalk-decrypt-password");
    const submitBtn = overlay.querySelector("#teletalk-decrypt-submit");
    const cancelBtn = overlay.querySelector("#teletalk-decrypt-cancel");
    const errorDiv = overlay.querySelector("#teletalk-decrypt-error");

    input.focus();

    const cleanup = () => {
      overlay.classList.remove("show");
      setTimeout(() => overlay.remove(), 300);
    };

    const handleDecrypt = async () => {
      const password = input.value.trim();
      if (!password) {
        errorDiv.textContent = "⚠ Password is required.";
        return;
      }

      submitBtn.disabled = true;
      submitBtn.textContent = "Decrypting...";
      errorDiv.textContent = "";

      try {
        const decrypted = await Encryption.decrypt(profile._enc, password);
        window._teletalkDecryptionPassword = password; // Cache password
        cleanup();
        resolve({ ...decrypted, id: profile.id, profileName: profile.profileName });
      } catch (err) {
        submitBtn.disabled = false;
        submitBtn.textContent = "Decrypt & Fill";
        errorDiv.textContent = "❌ Incorrect password. Try again.";
        input.value = "";
        input.focus();
      }
    };

    submitBtn.addEventListener("click", handleDecrypt);
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter") handleDecrypt();
    });
    cancelBtn.addEventListener("click", () => {
      cleanup();
      resolve(null);
    });
    overlay.addEventListener("click", (e) => {
      if (e.target === overlay) {
        cleanup();
        resolve(null);
      }
    });
  });
}

// ─── Floating Button UI ───────────────────────────────────────────────────────
function injectFloatingButton() {
  if (floatingBtn) return;

  const wrapper = document.createElement("div");
  wrapper.id = "teletalk-fab-wrapper";
  wrapper.innerHTML = `
    <div id="teletalk-fab-main" title="Teletalk Job Apply BD">
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
        <path d="M12 20h9M16.5 3.5a2.121 2.121 0 013 3L7 19l-4 1 1-4L16.5 3.5z"/>
      </svg>
    </div>
    <div id="teletalk-fab-menu">
      <div style="font-size: 11px; font-weight: 700; color: #006a4e; text-transform: uppercase; letter-spacing: 0.05em; padding: 4px 6px 8px; border-bottom: 1px solid #dde8e2; margin-bottom: 8px;">Select Profile</div>
      <div id="teletalk-fab-profiles" style="display: flex; flex-direction: column; gap: 6px; max-height: 200px; overflow-y: auto; padding-right: 2px; margin-bottom: 8px;">
        <!-- Loaded profiles here -->
      </div>
      <div style="height: 1px; background: #dde8e2; margin: 8px 0;"></div>
      <button id="teletalk-btn-clear" class="teletalk-fab-btn teletalk-btn-danger">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6M14 11v6"/></svg>
        Clear Form
      </button>
      <button id="teletalk-btn-manage" class="teletalk-fab-btn" style="background: #e8f5f1; color: #006a4e; margin-top: 6px; width: 100%;">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
        Manage Dashboard
      </button>
      <div id="teletalk-fab-status"></div>
    </div>
  `;

  document.body.appendChild(wrapper);
  floatingBtn = wrapper;

  // Toggle dropdown menu
  wrapper.querySelector("#teletalk-fab-main").addEventListener("click", () => {
    const opening = !wrapper.classList.contains("open");
    wrapper.classList.toggle("open");
    if (opening) {
      updateFABProfilesList(wrapper);
    }
  });

  // Clear action button
  wrapper.querySelector("#teletalk-btn-clear").addEventListener("click", () => {
    clearAllFields();
    const status = wrapper.querySelector("#teletalk-fab-status");
    status.textContent = "✓ Form cleared";
    setTimeout(() => { status.textContent = ""; wrapper.classList.remove("open"); }, 1500);
  });

  // Open Options page
  wrapper.querySelector("#teletalk-btn-manage").addEventListener("click", () => {
    chrome.runtime.sendMessage({ action: "OPEN_OPTIONS" });
    wrapper.classList.remove("open");
  });

  // Close popup menu on click outside
  document.addEventListener("click", (e) => {
    if (!wrapper.contains(e.target)) wrapper.classList.remove("open");
  });
}

function updateFABProfilesList(wrapper) {
  const profilesContainer = wrapper.querySelector("#teletalk-fab-profiles");
  if (!profilesContainer) return;

  chrome.storage.local.get(["profiles", "settings"], (data) => {
    const profiles = data.profiles || [];
    const settings = data.settings || {};

    profilesContainer.innerHTML = "";

    if (profiles.length === 0) {
      profilesContainer.innerHTML = `<div style="font-size: 11px; color: #8fa89e; padding: 6px;">No profiles found</div>`;
      return;
    }

    profiles.forEach((p) => {
      const btn = document.createElement("button");
      btn.className = "teletalk-fab-btn teletalk-fab-profile-btn";
      btn.style.width = "100%";
      btn.style.justifyContent = "flex-start";
      btn.style.margin = "2px 0";

      if (p.id === settings.activeProfileId) {
        btn.classList.add("active");
        btn.style.borderLeft = "3px solid #006a4e";
        btn.style.background = "#e6f4ef";
      }

      const lockIcon = p._enc ? " 🔒" : "";
      btn.innerHTML = `
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" style="margin-right: 4px;"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
        <span style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; flex: 1; text-align: left;">
          ${p.profileName || p.applicant_name_en || "Unnamed"}
        </span>
        ${lockIcon}
      `;

      btn.addEventListener("click", async () => {
        const status = wrapper.querySelector("#teletalk-fab-status");
        status.textContent = "Loading profile...";

        let profile = p;
        if (p._enc) {
          const decrypted = await promptForPasswordAndDecrypt(p);
          if (!decrypted) {
            status.textContent = "⚠ Decryption cancelled";
            setTimeout(() => { status.textContent = ""; }, 2500);
            return;
          }
          profile = decrypted;
        }

        status.textContent = "Filling form...";

        // Set active in storage
        settings.activeProfileId = p.id;
        chrome.storage.local.set({ settings });

        const count = autoFillForm(profile);
        status.textContent = count > 0 ? `✓ Filled ${count} fields` : "⚠ No matching fields found";

        // Highlight active profile
        wrapper.querySelectorAll(".teletalk-fab-profile-btn").forEach((b) => {
          b.classList.remove("active");
          b.style.borderLeft = "";
          b.style.background = "";
        });
        btn.classList.add("active");
        btn.style.borderLeft = "3px solid #006a4e";
        btn.style.background = "#e6f4ef";

        setTimeout(() => { status.textContent = ""; wrapper.classList.remove("open"); }, 2500);
      });

      profilesContainer.appendChild(btn);
    });
  });
}

// ─── Greedy Bipartite Matching Engine ─────────────────────────────────────────
function autoFillForm(profile) {
  fillCount = 0;

  // Scan and clean list of form inputs
  const allInputs = Array.from(document.querySelectorAll(
    "input:not([type=hidden]):not([type=submit]):not([type=button]):not([type=image]):not([type=reset]), select, textarea"
  ));

  if (debugMode) {
    console.log("Teletalk Job Apply: Scanning DOM elements count =", allInputs.length);
  }

  // Create candidates list for greedy matching
  const candidates = [];

  for (const el of allInputs) {
    const type = (el.type || "").toLowerCase();
    const tag = el.tagName.toLowerCase();
    const isRadio = type === "radio";
    const isCheckbox = type === "checkbox";

    for (const [fieldKey, config] of Object.entries(FIELD_MAP)) {
      const value = profile[config.profileKey];
      if (value === undefined || value === null || value === "") continue;

      let score = scoreElement(el, config);

      // Handle radio groups explicitly
      if (isRadio && config.type.includes("radio")) {
        const matchesVal = checkRadioValueMatches(el, value, config.optionMap);
        if (matchesVal) {
          score += 150; // Massively boost matching radio buttons
        } else {
          score = 0; // Filter out non-matching radios to avoid wrong checks
        }
      }

      // Prevent non-radio inputs from matching radio/checkbox configs and vice versa
      if (isRadio && !config.type.includes("radio")) score = 0;
      if (isCheckbox && !config.type.includes("checkbox") && !config.type.includes("radio")) score = 0;

      if (score > 30) {
        candidates.push({ el, fieldKey, config, value, score });
      }
    }
  }

  // Sort candidates by highest score first
  candidates.sort((a, b) => b.score - a.score);

  const assignedElements = new Set();
  const assignedFields = new Set();
  const delayedFills = []; // For dependent select chains (e.g. district -> upazila)

  for (const cand of candidates) {
    const { el, fieldKey, config, value, score } = cand;
    const type = (el.type || "").toLowerCase();

    // Element was already matched/filled (skip for radio since multiple elements share a group)
    if (type !== "radio" && assignedElements.has(el)) continue;

    // Field already mapped (since all personal fields should be mapped strictly 1-to-1)
    if (assignedFields.has(fieldKey)) continue;

    // Lock assignments
    if (type !== "radio") assignedElements.add(el);
    assignedFields.add(fieldKey);

    if (debugMode) {
      console.log(`Teletalk Job Apply Match: Field "${fieldKey}" -> <${el.tagName.toLowerCase()}> (Score: ${score}) Value:`, value);
    }

    // Check if this is a dependent field (upazila depends on district selection)
    const isDependentField = fieldKey.includes("upazila") || fieldKey.includes("post_office");
    if (isDependentField && el.tagName.toLowerCase() === "select") {
      delayedFills.push({ el, value, config, fieldKey });
    } else {
      // Perform the actual filling
      fillElement(el, value, config);
      // Apply soft glow highlight
      highlightElement(el);
    }
  }

  // Process delayed fills with staggered timing for dependent selects
  if (delayedFills.length > 0) {
    delayedFills.forEach((item, idx) => {
      setTimeout(() => {
        fillElement(item.el, item.value, item.config);
        highlightElement(item.el);
        if (debugMode) {
          console.log(`Teletalk Job Apply Delayed Fill: "${item.fieldKey}" ->`, item.value);
        }
      }, 500 + (idx * 400)); // Stagger by 400ms each after initial 500ms delay
    });
  }

  return fillCount;
}

// ─── Match Scoring Logic ──────────────────────────────────────────────────────
function scoreElement(el, config) {
  const { patterns } = config;
  let score = 0;
  const name = (el.name || "").toLowerCase();
  const id = (el.id || "").toLowerCase();
  const placeholder = (el.placeholder || "").toLowerCase();
  const className = (typeof el.className === "string" ? el.className : "").toLowerCase();
  const type = (el.type || "").toLowerCase();
  const tag = el.tagName.toLowerCase();
  const labelText = getLabelText(el).toLowerCase();

  // Strict type constraints to prevent files matching text/selects and vice-versa
  const isElFile = type === "file";
  const isConfigFile = config.type === "file_image";
  if (isElFile !== isConfigFile) {
    return 0;
  }

  // Prevent text-only configs from matching select elements and vice-versa
  const isElSelect = tag === "select";
  const isElTextarea = tag === "textarea";
  const isElTextInput = tag === "input" && !isElFile && type !== "radio" && type !== "checkbox";
  
  const configAcceptsSelect = config.type.includes("select");
  const configAcceptsText = config.type === "text" || config.type.includes("text") || config.type.includes("textarea");

  // Select elements should only match configs that accept selects
  if (isElSelect && !configAcceptsSelect) {
    return 0;
  }

  // Skip empty name/id elements for non-obvious matches to avoid false positives
  if (!name && !id && !placeholder && !labelText) {
    return 0;
  }

  // Exact Name attribute match
  if (patterns.names && patterns.names.some((p) => name === p.toLowerCase())) {
    score += 100;
  } else if (name && patterns.names && patterns.names.some((p) => name.includes(p.toLowerCase()) || p.toLowerCase().includes(name))) {
    // Only do fuzzy match if name has reasonable length to prevent short-name false positives
    if (name.length > 2) score += 70;
  }

  // ID attribute match
  if (patterns.ids && patterns.ids.some((p) => id === p.toLowerCase())) {
    score += 90;
  } else if (id && patterns.ids && patterns.ids.some((p) => id.includes(p.toLowerCase()) || p.toLowerCase().includes(id))) {
    if (id.length > 2) score += 60;
  }

  // Label text match (Highly important for Bangla text recognition)
  if (patterns.labels) {
    for (const lp of patterns.labels) {
      const lpLower = lp.toLowerCase();
      if (labelText === lpLower) {
        score += 85;
        break;
      }
      if (labelText.includes(lpLower) || lpLower.includes(labelText)) {
        // Avoid false match on very short label text  
        if (labelText.length > 3) {
          score += 55;
          break;
        }
      }
    }
  }

  // Placeholder match
  if (patterns.placeholders && patterns.placeholders.some((pp) => placeholder.includes(pp.toLowerCase()))) {
    score += 35;
  }

  // Class name match (lower weight to avoid false positives)
  if (patterns.names && patterns.names.some((p) => p.length > 3 && className.includes(p.toLowerCase()))) {
    score += 15;
  }

  // Boost score for address components based on location context
  const isPresentAddressField = patterns.names && patterns.names.some(p => p.includes("present"));
  const isPermanentAddressField = patterns.names && patterns.names.some(p => p.includes("permanent") || p.includes("perm"));

  if (isPresentAddressField && (name.includes("present") || id.includes("present") || labelText.includes("present") || labelText.includes("বর্তমান"))) {
    score += 40;
  }
  if (isPermanentAddressField && (name.includes("permanent") || name.includes("perm") || id.includes("permanent") || id.includes("perm") || labelText.includes("permanent") || labelText.includes("স্থায়ী"))) {
    score += 40;
  }
  
  // Penalize address cross-contamination: present config shouldn't match permanent elements
  if (isPresentAddressField && (name.includes("permanent") || name.includes("perm") || id.includes("permanent") || id.includes("perm") || labelText.includes("permanent") || labelText.includes("স্থায়ী"))) {
    score -= 80;
  }
  if (isPermanentAddressField && (name.includes("present") || id.includes("present") || labelText.includes("present") || labelText.includes("বর্তমান"))) {
    score -= 80;
  }

  // Boost for education roll/result mismatch prevention (e.g. ssc vs hsc)
  const isSscField = patterns.names && patterns.names.some(p => p.includes("ssc"));
  const isHscField = patterns.names && patterns.names.some(p => p.includes("hsc"));
  const isHonoursField = patterns.names && patterns.names.some(p => p.includes("honours") || p.includes("bach"));
  const isMastersField = patterns.names && patterns.names.some(p => p.includes("masters"));

  if (isSscField && (name.includes("ssc") || id.includes("ssc") || labelText.includes("ssc"))) score += 40;
  if (isHscField && (name.includes("hsc") || id.includes("hsc") || labelText.includes("hsc"))) score += 40;
  if (isHonoursField && (name.includes("honours") || name.includes("bachelor") || id.includes("honours") || labelText.includes("honours") || labelText.includes("graduation"))) score += 40;
  if (isMastersField && (name.includes("masters") || id.includes("masters") || labelText.includes("masters") || labelText.includes("post graduation"))) score += 40;

  // Penalize education cross-contamination
  if (isSscField && !isHscField && (name.includes("hsc") || id.includes("hsc"))) score -= 60;
  if (isHscField && !isSscField && (name.includes("ssc") || id.includes("ssc"))) score -= 60;
  if (isSscField && (name.includes("honours") || name.includes("masters") || id.includes("honours") || id.includes("masters"))) score -= 60;
  if (isHscField && (name.includes("honours") || name.includes("masters") || id.includes("honours") || id.includes("masters"))) score -= 60;
  if (isHonoursField && (name.includes("ssc") || name.includes("hsc") || name.includes("masters"))) score -= 60;
  if (isMastersField && (name.includes("ssc") || name.includes("hsc") || name.includes("honours"))) score -= 60;

  return Math.max(0, score);
}

function checkRadioValueMatches(el, profileValue, optionMap) {
  const elVal = el.value.toLowerCase().trim();
  const elLabel = getLabelText(el).toLowerCase().trim();
  const targetVal = profileValue.toString().toLowerCase().trim();

  // Direct match
  if (elVal === targetVal || elLabel === targetVal) return true;

  if (optionMap) {
    // Find which optionMap group the profile value belongs to (check both key and aliases)
    let matchedAliases = null;
    for (const [key, aliases] of Object.entries(optionMap)) {
      const allLower = aliases.map(a => a.toLowerCase());
      if (key.toLowerCase() === targetVal || allLower.includes(targetVal)) {
        matchedAliases = allLower;
        matchedAliases.push(key.toLowerCase()); // Include the key itself
        break;
      }
    }

    if (matchedAliases) {
      // Check if this radio element's value or label matches any alias
      if (matchedAliases.some(a => elVal === a || elLabel === a || elLabel.includes(a))) {
        return true;
      }
    }
  }
  return false;
}

// ─── Label Helper ─────────────────────────────────────────────────────────────
function getLabelText(el) {
  // Try using 'for' attribute label matching
  if (el.id) {
    const label = document.querySelector(`label[for="${el.id}"]`);
    if (label) return label.innerText.trim();
  }

  // Traverse up to find parent label tag
  let parent = el.parentElement;
  for (let i = 0; i < 5; i++) {
    if (!parent) break;

    if (parent.tagName === "LABEL") return parent.innerText.trim();

    const nearLabel = parent.querySelector("label");
    if (nearLabel && nearLabel !== el) return nearLabel.innerText.trim();

    // Look for text nodes or nearby elements acting as labels
    const childNodes = Array.from(parent.childNodes).filter(node => 
      node.nodeType === Node.TEXT_NODE || 
      (node.tagName && ["SPAN", "DIV", "TD", "TH"].includes(node.tagName))
    );

    for (const node of childNodes) {
      const text = (node.textContent || node.innerText || "").trim();
      if (text && text.length > 2 && text.length < 100) {
        if (!/^\d+$/.test(text) && !text.includes("select") && !text.includes("choose")) {
          return text;
        }
      }
    }

    // Check sibling cells in case of table layouts
    if (parent.tagName === "TD" || parent.tagName === "DIV" || parent.tagName === "TR") {
      const prev = parent.previousElementSibling;
      if (prev) {
        const prevText = (prev.innerText || prev.textContent || "").trim();
        if (prevText && prevText.length > 2 && prevText.length < 100) return prevText;
      }
    }

    parent = parent.parentElement;
  }

  // Aria label indicators
  if (el.getAttribute("aria-label")) return el.getAttribute("aria-label").trim();
  if (el.title) return el.title.trim();

  return "";
}

// ─── Element Filler Methods ───────────────────────────────────────────────────
function fillElement(el, value, config) {
  const tag = el.tagName.toLowerCase();
  const type = (el.type || "").toLowerCase();

  if (tag === "select") {
    const success = fillSelect(el, value, config.optionMap);
    if (!success) {
      queueDynamicSelectFill(el, value, config);
    }
  } else if (type === "radio") {
    fillRadioGroup(el, value, config.optionMap);
  } else if (type === "checkbox") {
    fillCheckbox(el, value, config.optionMap);
  } else if (type === "file") {
    fillFileInput(el, value, config);
  } else if (tag === "textarea") {
    fillTextArea(el, value);
  } else {
    fillTextInput(el, value);
  }
}

function fillTextInput(el, value) {
  if (el.value === String(value)) return;

  el.focus();
  let val = String(value);

  // Format date inputs automatically if necessary
  if (el.type === "date") {
    if (typeof value === "string" && value.match(/^\d{2}\/\d{2}\/\d{4}$/)) {
      const parts = value.split("/");
      val = `${parts[2]}-${parts[1]}-${parts[0]}`;
    }
  }

  el.value = "";

  // React/Angular/Vue compatible: use native prototype setter for input elements
  const nativeInputSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement?.prototype || {}, "value")?.set;

  if (nativeInputSetter) {
    nativeInputSetter.call(el, val);
  } else {
    el.value = val;
  }

  el.setAttribute("value", val);
  triggerEvents(el);
  fillCount++;
}

function fillTextArea(el, value) {
  if (el.value === String(value)) return;

  el.focus();
  const val = String(value);

  // Use native textarea setter for React/Angular/Vue framework compatibility
  const nativeTextAreaSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement?.prototype || {}, "value")?.set;

  if (nativeTextAreaSetter) {
    nativeTextAreaSetter.call(el, val);
  } else {
    el.value = val;
  }

  // Textareas don't use setAttribute("value") — they use textContent internally
  triggerEvents(el);
  fillCount++;
}

const activeSelectObservers = new Map();

function queueDynamicSelectFill(el, value, config) {
  if (activeSelectObservers.has(el)) {
    activeSelectObservers.get(el).value = value;
    return;
  }

  if (debugMode) {
    console.log("Teletalk Job Apply: Queued select for dynamic mutations:", el);
  }

  const observer = new MutationObserver(() => {
    const success = fillSelect(el, value, config.optionMap);
    if (success) {
      if (debugMode) console.log("Teletalk Job Apply: Dynamic fill succeeded for select:", el);
      observer.disconnect();
      activeSelectObservers.delete(el);
    }
  });

  observer.observe(el, { childList: true });
  activeSelectObservers.set(el, { observer, value });

  // Clean up observer to prevent leaks after 8 seconds
  setTimeout(() => {
    if (activeSelectObservers.has(el) && activeSelectObservers.get(el).observer === observer) {
      observer.disconnect();
      activeSelectObservers.delete(el);
    }
  }, 8000);
}

function fillSelect(el, value, optionMap) {
  const valueLower = value.toString().toLowerCase().trim();

  // 1. Try exact matches on text/value
  for (const opt of el.options) {
    const optText = opt.text.toLowerCase().trim();
    const optValue = opt.value.toLowerCase().trim();

    if (optText === valueLower || optValue === valueLower) {
      if (el.value !== opt.value) {
        el.value = opt.value;
        triggerEvents(el);
        fillCount++;
      }
      return true;
    }
  }

  // 2. Try optionMap aliases — match profile value against both keys and alias lists
  if (optionMap) {
    // First, find which optionMap key the profile value corresponds to
    let matchedAliases = null;
    for (const [key, aliases] of Object.entries(optionMap)) {
      const allLower = aliases.map(a => a.toLowerCase());
      if (key.toLowerCase() === valueLower || allLower.includes(valueLower)) {
        matchedAliases = allLower;
        break;
      }
    }

    if (matchedAliases) {
      // Now try to find a DOM option that matches any of the aliases
      let bestMatch = null;
      let bestScore = 0;
      for (const opt of el.options) {
        const optText = opt.text.toLowerCase().trim();
        const optValue = opt.value.toLowerCase().trim();
        
        // Exact matches on aliases score highest
        if (matchedAliases.includes(optValue)) {
          bestMatch = opt;
          bestScore = 100;
          break;
        }
        if (matchedAliases.includes(optText)) {
          bestMatch = opt;
          bestScore = 95;
          break;
        }
        // Partial match
        for (const alias of matchedAliases) {
          if (optText.includes(alias) || alias.includes(optText)) {
            const s = optText === alias ? 90 : 70;
            if (s > bestScore && optText.length > 1) {
              bestScore = s;
              bestMatch = opt;
            }
          }
          if (optValue.includes(alias)) {
            const s = optValue === alias ? 85 : 60;
            if (s > bestScore && optValue.length > 0) {
              bestScore = s;
              bestMatch = opt;
            }
          }
        }
      }

      if (bestMatch) {
        if (el.value !== bestMatch.value) {
          el.value = bestMatch.value;
          triggerEvents(el);
          fillCount++;
        }
        return true;
      }
    }
  }

  // 3. Fallback to partial matches on raw value
  const partialMatches = [];
  for (const opt of el.options) {
    const optText = opt.text.toLowerCase().trim();
    const optValue = opt.value.toLowerCase().trim();

    if ((optText.includes(valueLower) || valueLower.includes(optText)) && optText.length > 1) {
      partialMatches.push({ opt, score: optText === valueLower ? 100 : 60 });
    }
    if (optValue.includes(valueLower) && optValue.length > 0) {
      partialMatches.push({ opt, score: optValue === valueLower ? 90 : 50 });
    }
  }

  if (partialMatches.length > 0) {
    partialMatches.sort((a, b) => b.score - a.score);
    const bestOpt = partialMatches[0].opt;
    if (el.value !== bestOpt.value) {
      el.value = bestOpt.value;
      triggerEvents(el);
      fillCount++;
    }
    return true;
  }

  return false;
}

function fillRadioGroup(el, value, optionMap) {
  const valueLower = value.toString().toLowerCase().trim();
  const radios = document.querySelectorAll(`input[type=radio][name="${el.name}"]`);

  // Build the list of aliases to match against (includes raw value + optionMap aliases)
  let matchTargets = [valueLower];

  if (optionMap) {
    for (const [key, aliases] of Object.entries(optionMap)) {
      const allLower = aliases.map(a => a.toLowerCase());
      if (key.toLowerCase() === valueLower || allLower.includes(valueLower)) {
        matchTargets = [...new Set([...allLower, key.toLowerCase(), valueLower])];
        break;
      }
    }
  }

  for (const radio of radios) {
    const radioVal = radio.value.toLowerCase().trim();
    const radioLabel = getLabelText(radio).toLowerCase().trim();

    const isMatch = matchTargets.some(t => 
      radioVal === t || radioLabel === t || radioLabel.includes(t)
    );

    if (isMatch) {
      if (!radio.checked) {
        radio.checked = true;
        triggerEvents(radio);
        fillCount++;
      }
      return;
    }
  }
}

function fillCheckbox(el, value, optionMap) {
  const valueLower = value.toString().toLowerCase().trim();
  const elVal = el.value.toLowerCase().trim();
  const shouldCheck = valueLower === "true" || valueLower === "1" || valueLower === "yes" || elVal === valueLower;

  if (el.checked !== shouldCheck) {
    el.checked = shouldCheck;
    triggerEvents(el);
    fillCount++;
  }
}

function fillFileInput(el, dataURL, config) {
  if (!dataURL || typeof dataURL !== "string" || !dataURL.startsWith("data:")) return;

  try {
    const arr = dataURL.split(",");
    const mime = arr[0].match(/:(.*?);/)[1];
    const bstr = atob(arr[1]);
    let n = bstr.length;
    const u8arr = new Uint8Array(n);
    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }

    let filename = "document.jpg";
    if (config.profileKey === "profilePhoto") {
      filename = "profile_photo.jpg";
    } else if (config.profileKey === "signature") {
      filename = "signature.jpg";
    }

    const file = new File([u8arr], filename, { type: mime });
    const dataTransfer = new DataTransfer();
    dataTransfer.items.add(file);
    el.files = dataTransfer.files;

    triggerEvents(el);
    fillCount++;

    // Visual feedback overlay
    showFileInputFeedback(el, filename);
  } catch (error) {
    console.warn("Teletalk Job Apply: File upload failed:", error);
  }
}

function showFileInputFeedback(fileInput, filename) {
  let feedback = fileInput.parentNode.querySelector(".teletalk-file-feedback");
  if (feedback) feedback.remove();

  feedback = document.createElement("div");
  feedback.className = "teletalk-file-feedback";
  feedback.style.cssText = `
    font-size: 11px;
    color: #006a4e;
    margin-top: 5px;
    padding: 5px 10px;
    background: #e6f4ef;
    border-radius: 6px;
    border-left: 3px solid #006a4e;
    font-weight: 500;
  `;
  feedback.textContent = `✓ Auto-attached: ${filename}`;
  fileInput.parentNode.appendChild(feedback);
}

// ─── Dispatch Events ──────────────────────────────────────────────────────────
function triggerEvents(el) {
  // Focus event first (some frameworks need this)
  el.dispatchEvent(new Event("focus", { bubbles: true }));
  
  // Keyboard events to simulate actual typing (important for some form validators)
  el.dispatchEvent(new Event("keydown", { bubbles: true }));
  el.dispatchEvent(new Event("keypress", { bubbles: true }));
  el.dispatchEvent(new Event("keyup", { bubbles: true }));
  
  // Core form events
  el.dispatchEvent(new Event("input", { bubbles: true }));
  el.dispatchEvent(new Event("change", { bubbles: true }));
  el.dispatchEvent(new Event("blur", { bubbles: true }));

  // Direct invoke support for legacy inline HTML event handlers (e.g. onchange="load_upazila()")
  if (typeof el.onchange === "function") {
    try {
      el.onchange();
    } catch (e) {
      if (debugMode) console.warn("Teletalk Job Apply: Legacy onchange trigger error:", e);
    }
  }
  if (typeof el.oninput === "function") {
    try {
      el.oninput();
    } catch (e) {
      if (debugMode) console.warn("Teletalk Job Apply: Legacy oninput trigger error:", e);
    }
  }
}

// ─── Visual Highlighter ───────────────────────────────────────────────────────
function highlightElement(el) {
  el.classList.add("teletalk-autofilled");
  
  // Custom temporary CSS style to flash element
  const originalTransition = el.style.transition;
  el.style.transition = "all 0.4s ease";
  el.style.boxShadow = "0 0 10px rgba(0, 106, 78, 0.7)";
  el.style.borderColor = "#006a4e";
  el.style.backgroundColor = "#e6f4ef";

  setTimeout(() => {
    el.style.boxShadow = "";
    el.style.borderColor = "";
    el.style.backgroundColor = "";
    setTimeout(() => {
      el.style.transition = originalTransition;
      el.classList.remove("teletalk-autofilled");
    }, 400);
  }, 2000);
}

// ─── Form Eraser ──────────────────────────────────────────────────────────────
function clearAllFields() {
  const allInputs = Array.from(document.querySelectorAll(
    "input:not([type=hidden]):not([type=submit]):not([type=button]):not([type=image]):not([type=reset]), select, textarea"
  ));

  for (const el of allInputs) {
    const type = (el.type || "").toLowerCase();
    const tag = el.tagName.toLowerCase();

    if (type === "checkbox" || type === "radio") {
      if (el.checked) {
        el.checked = false;
        triggerEvents(el);
      }
    } else if (tag === "select") {
      if (el.selectedIndex !== 0) {
        el.selectedIndex = 0;
        triggerEvents(el);
      }
    } else if (type === "file") {
      el.value = "";
      triggerEvents(el);
      const feedback = el.parentNode.querySelector(".teletalk-file-feedback");
      if (feedback) feedback.remove();
    } else {
      if (el.value !== "") {
        el.value = "";
        triggerEvents(el);
      }
    }
  }
}
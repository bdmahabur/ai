/**
 * content.js — Teletalk Job Apply-Modified by Mahabur Hossain-01781040050
 * Injected into Teletalk pages. Handles field detection,
 * auto-fill logic, and the floating action button.
 */

// ─── Field Map (Complete and Clean) ─────────────────────
const FIELD_MAP = {
  // ─── Personal Information ───────────────────────────────────────────────────
  applicant_name_en: {
    profileKey: "applicant_name_en", type: "text",
    patterns: { 
      names: ["applicant_name","full_name","name_en","applicant_name_en","fullname","ApplicantName"], 
      ids: ["applicant_name","full_name","name_en","fullname","ApplicantName"], 
      labels: ["applicant name","full name","name (english)","name in english","applicant's name"], 
      placeholders: ["enter name","full name","applicant name"] 
    }
  },
  applicant_name_bn: {
    profileKey: "applicant_name_bn", type: "text",
    patterns: { 
      names: ["applicant_name_bn","name_bn","bangla_name","name_bangla"], 
      ids: ["applicant_name_bn","name_bn","bangla_name"], 
      labels: ["নাম","আবেদনকারীর নাম","পূর্ণ নাম","name (bangla)","name in bangla","applicant name (bangla)"], 
      placeholders: ["বাংলায় নাম লিখুন","নাম"] 
    }
  },
  father_name_en: {
    profileKey: "father_name_en", type: "text",
    patterns: { 
      names: ["father_name","father_name_en","fathers_name","fname_en"], 
      ids: ["father_name","father_name_en","fathers_name"], 
      labels: ["father's name","father name","father's name (english)","name of father"], 
      placeholders: ["father's name","enter father name"] 
    }
  },
  father_name_bn: {
    profileKey: "father_name_bn", type: "text",
    patterns: { 
      names: ["father_name_bn","fathers_name_bn","fname_bn"], 
      ids: ["father_name_bn","fathers_name_bn"], 
      labels: ["পিতার নাম","বাবার নাম","father's name (bangla)","পিতা/অভিভাবকের নাম"], 
      placeholders: ["পিতার নাম লিখুন"] 
    }
  },
  mother_name_en: {
    profileKey: "mother_name_en", type: "text",
    patterns: { 
      names: ["mother_name","mother_name_en","mothers_name","mname_en"], 
      ids: ["mother_name","mother_name_en","mothers_name"], 
      labels: ["mother's name","mother name","mother's name (english)","name of mother"], 
      placeholders: ["mother's name","enter mother name"] 
    }
  },
  mother_name_bn: {
    profileKey: "mother_name_bn", type: "text",
    patterns: { 
      names: ["mother_name_bn","mothers_name_bn","mname_bn"], 
      ids: ["mother_name_bn","mothers_name_bn"], 
      labels: ["মাতার নাম","মায়ের নাম","mother's name (bangla)","মাতা/অভিভাবকের নাম"], 
      placeholders: ["মাতার নাম লিখুন"] 
    }
  },
  date_of_birth: {
    profileKey: "date_of_birth", type: "text",
    patterns: { 
      names: ["dob","date_of_birth","birth_date","birthdate"], 
      ids: ["dob","date_of_birth","birth_date","dateofbirth"], 
      labels: ["date of birth","birth date","জন্ম তারিখ","d.o.b","dob"], 
      placeholders: ["dd/mm/yyyy","yyyy-mm-dd","date of birth","জন্ম তারিখ"] 
    }
  },
  birth_reg_no: {
    profileKey: "birth_reg_no", type: "text",
    patterns: { 
      names: ["birth_reg_no","birth_registration","birth_cert_no","brn"], 
      ids: ["birth_reg_no","birth_registration","birth_cert"], 
      labels: ["birth registration number","birth certificate number","জন্ম নিবন্ধন নম্বর","birth reg. no"], 
      placeholders: ["birth registration no","enter birth reg no"] 
    }
  },
  nid: {
    profileKey: "nid", type: "text",
    patterns: { 
      names: ["nid","national_id","nid_no","national_id_no","voter_id","NIDNo"], 
      ids: ["nid","national_id","nid_no","voter_id"], 
      labels: ["national id","nid","national identity","জাতীয় পরিচয়পত্র নম্বর","nid number","voter id"], 
      placeholders: ["enter nid","national id no","nid number"] 
    }
  },
  gender: {
    profileKey: "gender", type: "select_radio",
    patterns: { 
      names: ["gender","sex"], 
      ids: ["gender","sex"], 
      labels: ["gender","লিঙ্গ","sex"], 
      placeholders: ["select gender"] 
    },
    optionMap: {
      "male": ["male","পুরুষ","m","1"],
      "female": ["female","মহিলা","নারী","f","2"],
      "other": ["other","অন্যান্য","3"]
    }
  },
  religion: {
    profileKey: "religion", type: "select_radio",
    patterns: { 
      names: ["religion","religion_id"], 
      ids: ["religion","religion_id"], 
      labels: ["religion","ধর্ম"], 
      placeholders: ["select religion","ধর্ম নির্বাচন করুন"] 
    },
    optionMap: {
      "islam": ["islam","ইসলাম","muslim","মুসলিম","1"],
      "hinduism": ["hinduism","hindu","হিন্দু","হিন্দুধর্ম","2"],
      "christianity": ["christianity","christian","খ্রিষ্টান","3"],
      "buddhism": ["buddhism","buddhist","বৌদ্ধ","4"],
      "other": ["other","অন্যান্য","5"]
    }
  },
  nationality: {
    profileKey: "nationality", type: "text_select",
    patterns: { 
      names: ["nationality","citizenship"], 
      ids: ["nationality","citizenship"], 
      labels: ["nationality","জাতীয়তা","citizenship"], 
      placeholders: ["nationality","enter nationality"] 
    },
    defaultValue: "Bangladeshi"
  },
  marital_status: {
    profileKey: "marital_status", type: "select_radio",
    patterns: { 
      names: ["marital_status","marital","marriage_status"], 
      ids: ["marital_status","marital","marriage_status"], 
      labels: ["marital status","বৈবাহিক অবস্থা","marriage status"], 
      placeholders: ["select marital status"] 
    },
    optionMap: {
      "single": ["single","অবিবাহিত","unmarried","1"],
      "married": ["married","বিবাহিত","2"],
      "divorced": ["divorced","তালাকপ্রাপ্ত","3"],
      "widowed": ["widowed","বিধবা","বিপত্নীক","4"]
    }
  },
  mobile: {
    profileKey: "mobile", type: "text",
    patterns: { 
      names: ["mobile","mobile_no","phone","phone_no","contact_no","cell","MobileNo"], 
      ids: ["mobile","mobile_no","phone","contact_no"], 
      labels: ["mobile","মোবাইল","mobile number","মোবাইল নম্বর","phone","contact number"], 
      placeholders: ["01xxxxxxxxx","mobile no","phone number","মোবাইল নম্বর"] 
    }
  },
  email: {
    profileKey: "email", type: "text",
    patterns: { 
      names: ["email","email_address","e_mail"], 
      ids: ["email","email_address"], 
      labels: ["email","ইমেইল","e-mail","email address","ইমেইল ঠিকানা"], 
      placeholders: ["email@example.com","enter email","ইমেইল"] 
    }
  },
  applicant_name_bn: {
    profileKey: "applicant_name_bn", type: "text",
    patterns: { names: ["applicant_name_bn","name_bn","bangla_name","name_bangla"], ids: ["applicant_name_bn","name_bn","bangla_name"], labels: ["নাম","আবেদনকারীর নাম","পূর্ণ নাম","name (bangla)","name in bangla"], placeholders: ["বাংলায় নাম","নাম"] }
  },
  father_name_en: {
    profileKey: "father_name_en", type: "text",
    patterns: { names: ["father_name","father_name_en","fathers_name","fname_en"], ids: ["father_name","father_name_en","fathers_name"], labels: ["father's name","father name","father's name (english)","name of father"], placeholders: ["father's name"] }
  },
  father_name_bn: {
    profileKey: "father_name_bn", type: "text",
    patterns: { names: ["father_name_bn","fathers_name_bn","fname_bn"], ids: ["father_name_bn","fathers_name_bn"], labels: ["পিতার নাম","বাবার নাম","father's name (bangla)"], placeholders: ["পিতার নাম"] }
  },
  mother_name_en: {
    profileKey: "mother_name_en", type: "text",
    patterns: { names: ["mother_name","mother_name_en","mothers_name","mname_en"], ids: ["mother_name","mother_name_en","mothers_name"], labels: ["mother's name","mother name","mother's name (english)"], placeholders: ["mother's name"] }
  },
  mother_name_bn: {
    profileKey: "mother_name_bn", type: "text",
    patterns: { names: ["mother_name_bn","mothers_name_bn","mname_bn"], ids: ["mother_name_bn","mothers_name_bn"], labels: ["মাতার নাম","মায়ের নাম","mother's name (bangla)"], placeholders: ["মাতার নাম"] }
  },
  date_of_birth: {
    profileKey: "date_of_birth", type: "text",
    patterns: { names: ["dob","date_of_birth","birth_date","birthdate"], ids: ["dob","date_of_birth","birth_date","dateofbirth"], labels: ["date of birth","birth date","জন্ম তারিখ","d.o.b"], placeholders: ["dd/mm/yyyy","yyyy-mm-dd","জন্ম তারিখ"] }
  },
  birth_reg_no: {
    profileKey: "birth_reg_no", type: "text",
    patterns: { names: ["birth_reg_no","birth_registration","birth_cert_no","brn"], ids: ["birth_reg_no","birth_registration"], labels: ["birth registration number","birth certificate number","জন্ম নিবন্ধন নম্বর"], placeholders: ["birth registration no"] }
  },
  nid: {
    profileKey: "nid", type: "text",
    patterns: { names: ["nid","national_id","nid_no","national_id_no","voter_id","NIDNo"], ids: ["nid","national_id","nid_no","voter_id"], labels: ["national id","nid","জাতীয় পরিচয়পত্র নম্বর","voter id"], placeholders: ["enter nid","nid number"] }
  },
  gender: {
    profileKey: "gender", type: "select_radio",
    patterns: { names: ["gender","sex"], ids: ["gender","sex"], labels: ["gender","লিঙ্গ","sex"], placeholders: ["select gender"] },
    optionMap: { male: ["male","পুরুষ","m","1"], female: ["female","মহিলা","নারী","f","2"], other: ["other","অন্যান্য","3"] }
  },
  religion: {
    profileKey: "religion", type: "select_radio",
    patterns: { names: ["religion","religion_id"], ids: ["religion","religion_id"], labels: ["religion","ধর্ম"], placeholders: ["select religion"] },
    optionMap: { islam: ["islam","ইসলাম","muslim","1"], hinduism: ["hinduism","hindu","হিন্দু","2"], christianity: ["christianity","christian","খ্রিষ্টান","3"], buddhism: ["buddhism","buddhist","বৌদ্ধ","4"], other: ["other","অন্যান্য","5"] }
  },
  nationality: {
    profileKey: "nationality", type: "text_select",
    patterns: { names: ["nationality","citizenship"], ids: ["nationality","citizenship"], labels: ["nationality","জাতীয়তা"], placeholders: ["nationality"] },
    defaultValue: "Bangladeshi"
  },
  marital_status: {
    profileKey: "marital_status", type: "select_radio",
    patterns: { names: ["marital_status","marital","marriage_status"], ids: ["marital_status","marital"], labels: ["marital status","বৈবাহিক অবস্থা"], placeholders: ["select marital status"] },
    optionMap: { single: ["single","অবিবাহিত","unmarried","1"], married: ["married","বিবাহিত","2"], divorced: ["divorced","তালাকপ্রাপ্ত","3"], widowed: ["widowed","বিধবা","বিপত্নীক","4"] }
  },
  mobile: {
    profileKey: "mobile", type: "text",
    patterns: { names: ["mobile","mobile_no","phone","phone_no","contact_no","MobileNo"], ids: ["mobile","mobile_no","phone","contact_no"], labels: ["mobile","মোবাইল","mobile number","মোবাইল নম্বর"], placeholders: ["01xxxxxxxxx","mobile no"] }
  },
  email: {
    profileKey: "email", type: "text",
    patterns: { names: ["email","email_address","e_mail"], ids: ["email","email_address"], labels: ["email","ইমেইল","e-mail","email address"], placeholders: ["email@example.com"] }
  },
  present_address_bn: {
    profileKey: "present_address_bn", type: "textarea_text",
    patterns: { names: ["present_address_bn","present_address_bangla","cur_address_bn"], ids: ["present_address_bn","present_address_bangla"], labels: ["বর্তমান ঠিকানা","present address (bangla)"], placeholders: ["বর্তমান ঠিকানা"] }
  },
  present_address_en: {
    profileKey: "present_address_en", type: "textarea_text",
    patterns: { names: ["present_address","present_address_en","present_address_english","cur_address"], ids: ["present_address","present_address_en"], labels: ["present address","present address (english)"], placeholders: ["present address"] }
  },
  permanent_address_bn: {
    profileKey: "permanent_address_bn", type: "textarea_text",
    patterns: { names: ["permanent_address_bn","perm_address_bn","permanent_address_bangla"], ids: ["permanent_address_bn","perm_address_bn"], labels: ["স্থায়ী ঠিকানা","permanent address (bangla)"], placeholders: ["স্থায়ী ঠিকানা"] }
  },
  permanent_address_en: {
    profileKey: "permanent_address_en", type: "textarea_text",
    patterns: { names: ["permanent_address","permanent_address_en","perm_address","per_address"], ids: ["permanent_address","permanent_address_en"], labels: ["permanent address","permanent address (english)"], placeholders: ["permanent address"] }
  },
  // ─── Address Information ────────────────────────────────────────────────────
  // Present Address Fields
  present_care_of: { 
    profileKey: "present_care_of", type: "text", 
    patterns: { 
      names: ["present_care_of","care_of","c_o","care_of_present","careof","care","co","CareOf"], 
      ids: ["present_care_of","care_of","c_o","careof","care","co","CareOf"], 
      labels: ["care of","c/o","যত্নে","care of (present)","careof","care","Care Of"], 
      placeholders: ["care of","c/o","careof","MD SHARIFUR ISLAM"] 
    } 
  },
  present_village_town: { 
    profileKey: "present_village_town", type: "text", 
    patterns: { 
      names: ["present_village","village_town","village_present","town_present","road_present","village","town","road","village_town_road","area_present","VillageTown","Village"], 
      ids: ["present_village","village_town","village_present","village","town","road","VillageTown"], 
      labels: ["village","গ্রাম","town","শহর","village/town/road","village/town","road","area","এলাকা","Village / Town / Road","Village/Town/Road"], 
      placeholders: ["village/town/road","village name","town name","road name"] 
    } 
  },
  present_house_flat: { 
    profileKey: "present_house_flat", type: "text", 
    patterns: { 
      names: ["present_house","house_flat","house_present","flat_present","building_present","house","flat","building","house_no","flat_no","HouseFlat"], 
      ids: ["present_house","house_flat","house_present","house","flat","building","HouseFlat"], 
      labels: ["house","বাড়ি","flat","ফ্ল্যাট","house/flat","building","ভবন","house no","flat no","House / Flat","House/Flat"], 
      placeholders: ["house/flat","house no","flat no","building"] 
    } 
  },
  present_district: { 
    profileKey: "present_district", type: "select_text", 
    patterns: { 
      names: ["present_district","district_present","district","dist_present","district_name","present_dist","District"], 
      ids: ["present_district","district_present","district","dist","district_name","District"], 
      labels: ["district","জেলা","present district","বর্তমান জেলা","district name","জেলার নাম","District"], 
      placeholders: ["select district","জেলা নির্বাচন করুন","district","Select","Sylhet"] 
    } 
  },
  present_upazila: { 
    profileKey: "present_upazila", type: "text_select", 
    patterns: { 
      names: ["present_upazila","upazila_present","upazila","thana_present","ps_present","thana","police_station","sub_district","upazila_ps","Upazila","UpazilaPS"], 
      ids: ["present_upazila","upazila_present","upazila","thana","ps","police_station","Upazila","UpazilaPS"], 
      labels: ["upazila","উপজেলা","thana","থানা","p.s.","police station","upazila/p.s.","sub district","upazila/thana","Upazila/P.S.","Upazila/PS","Upazila P.S."], 
      placeholders: ["upazila/p.s.","উপজেলা","thana","police station","Select","Beanibazar"] 
    } 
  },
  present_post_office: { 
    profileKey: "present_post_office", type: "text", 
    patterns: { 
      names: ["present_post_office","post_office_present","post_office","po_present","postoffice","po","post_office_name","PostOffice"], 
      ids: ["present_post_office","post_office_present","post_office","po","postoffice","PostOffice"], 
      labels: ["post office","ডাকঘর","p.o.","present post office","post office name","ডাক অফিস","Post Office"], 
      placeholders: ["post office","ডাকঘর","p.o.","post office name"] 
    } 
  },
  present_post_code: { 
    profileKey: "present_post_code", type: "text", 
    patterns: { 
      names: ["present_post_code","postal_code_present","post_code","zip_present","postcode","zip","postal_code","zip_code","PostCode"], 
      ids: ["present_post_code","postal_code_present","post_code","postcode","zip","postal_code","PostCode"], 
      labels: ["post code","পোস্ট কোড","postal code","zip code","পোস্টাল কোড","Post Code"], 
      placeholders: ["post code","postal code","zip code","পোস্ট কোড"] 
    } 
  },
  present_address_bn: {
    profileKey: "present_address_bn", type: "textarea_text",
    patterns: { 
      names: ["present_address_bn","present_address_bangla","cur_address_bn","address_bn_present","present_addr_bn"], 
      ids: ["present_address_bn","present_address_bangla","address_bn_present"], 
      labels: ["বর্তমান ঠিকানা","present address (bangla)","present address (বাংলায়)","ঠিকানা (বাংলা)","বর্তমান ঠিকানা (বাংলা)"], 
      placeholders: ["বর্তমান ঠিকানা লিখুন","বর্তমান ঠিকানা","ঠিকানা বাংলায়"] 
    }
  },
  present_address_en: {
    profileKey: "present_address_en", type: "textarea_text",
    patterns: { 
      names: ["present_address","present_address_en","present_address_english","cur_address","current_address","present_addr","address_present"], 
      ids: ["present_address","present_address_en","present_address_english","cur_address","current_address"], 
      labels: ["present address","present address (english)","বর্তমান ঠিকানা (ইংরেজি)","current address","address (english)"], 
      placeholders: ["present address","enter present address","current address"] 
    }
  },

  // Permanent Address Fields  
  permanent_care_of: { 
    profileKey: "permanent_care_of", type: "text", 
    patterns: { 
      names: ["permanent_care_of","care_of_permanent","perm_care_of","care_of_perm","permanent_careof"], 
      ids: ["permanent_care_of","care_of_permanent","perm_care_of","permanent_careof"], 
      labels: ["care of","c/o","যত্নে","care of (permanent)","permanent care of","Care Of"], 
      placeholders: ["care of","c/o","careof","MD SHARIFUR ISLAM"] 
    } 
  },
  permanent_village_town: { 
    profileKey: "permanent_village_town", type: "text", 
    patterns: { 
      names: ["permanent_village","village_permanent","town_permanent","road_permanent","perm_village","perm_town","village_perm"], 
      ids: ["permanent_village","village_permanent","town_permanent","perm_village"], 
      labels: ["village","গ্রাম","town","শহর","village/town/road","village/town","road","area","এলাকা","Village / Town / Road","Village/Town/Road"], 
      placeholders: ["village/town/road","village name","town name"] 
    } 
  },
  permanent_house_flat: { 
    profileKey: "permanent_house_flat", type: "text", 
    patterns: { 
      names: ["permanent_house","house_permanent","flat_permanent","building_permanent","perm_house","perm_flat","house_perm"], 
      ids: ["permanent_house","house_permanent","flat_permanent","perm_house"], 
      labels: ["house","বাড়ি","flat","ফ্ল্যাট","house/flat","building","ভবন","House / Flat","House/Flat"], 
      placeholders: ["house/flat","house no","flat no"] 
    } 
  },
  permanent_district: { 
    profileKey: "permanent_district", type: "select_text", 
    patterns: { 
      names: ["permanent_district","district_permanent","perm_district","district_perm","permanent_dist"], 
      ids: ["permanent_district","district_permanent","perm_district","permanent_dist"], 
      labels: ["district","জেলা","permanent district","স্থায়ী জেলা","district name","District"], 
      placeholders: ["select district","জেলা নির্বাচন করুন","district","Select"] 
    } 
  },
  permanent_upazila: { 
    profileKey: "permanent_upazila", type: "text_select", 
    patterns: { 
      names: ["permanent_upazila","upazila_permanent","thana_permanent","ps_permanent","perm_upazila","perm_thana","upazila_perm"], 
      ids: ["permanent_upazila","upazila_permanent","thana_permanent","perm_upazila"], 
      labels: ["upazila","উপজেলা","thana","থানা","p.s.","police station","upazila/p.s.","Upazila/P.S.","Upazila/PS"], 
      placeholders: ["upazila/p.s.","উপজেলা","thana","Select"] 
    } 
  },
  permanent_post_office: { 
    profileKey: "permanent_post_office", type: "text", 
    patterns: { 
      names: ["permanent_post_office","post_office_permanent","perm_post_office","postoffice_perm","po_permanent"], 
      ids: ["permanent_post_office","post_office_permanent","perm_post_office","po_permanent"], 
      labels: ["post office","ডাকঘর","p.o.","permanent post office","post office name","Post Office"], 
      placeholders: ["post office","ডাকঘর","p.o."] 
    } 
  },
  permanent_post_code: { 
    profileKey: "permanent_post_code", type: "text", 
    patterns: { 
      names: ["permanent_post_code","postal_code_permanent","perm_post_code","postcode_perm","zip_permanent"], 
      ids: ["permanent_post_code","postal_code_permanent","perm_post_code","zip_permanent"], 
      labels: ["post code","পোস্ট কোড","postal code","zip code","Post Code"], 
      placeholders: ["post code","postal code","পোস্ট কোড"] 
    } 
  },
  permanent_address_bn: {
    profileKey: "permanent_address_bn", type: "textarea_text",
    patterns: { 
      names: ["permanent_address_bn","perm_address_bn","permanent_address_bangla","address_bn_permanent","perm_addr_bn"], 
      ids: ["permanent_address_bn","perm_address_bn","address_bn_permanent"], 
      labels: ["স্থায়ী ঠিকানা","permanent address (bangla)","permanent address (বাংলায়)","ঠিকানা (বাংলা)","স্থায়ী ঠিকানা (বাংলা)"], 
      placeholders: ["স্থায়ী ঠিকানা লিখুন","স্থায়ী ঠিকানা","ঠিকানা বাংলায়"] 
    }
  },
  permanent_address_en: {
    profileKey: "permanent_address_en", type: "textarea_text",
    patterns: { 
      names: ["permanent_address","permanent_address_en","perm_address","per_address","permanent_address_english","perm_addr"], 
      ids: ["permanent_address","permanent_address_en","perm_address","per_address"], 
      labels: ["permanent address","permanent address (english)","স্থায়ী ঠিকানা (ইংরেজি)","address (english)"], 
      placeholders: ["permanent address","enter permanent address","permanent address in english"] 
    }
  },
  // Legacy address fields (for backward compatibility and simple forms) - Enhanced patterns
  district: {
    profileKey: "present_district", type: "select_text",
    patterns: { 
      names: ["district","district_id","dist_id","district_name","dist","districts"], 
      ids: ["district","district_id","dist","districts","district_name"], 
      labels: ["district","জেলা","district name","জেলার নাম"], 
      placeholders: ["select district","জেলা নির্বাচন করুন","choose district","Select","Sylhet"] 
    }
  },
  upazila: {
    profileKey: "present_upazila", type: "select_text",
    patterns: { 
      names: ["upazila","upazila_id","thana","thana_id","sub_district","upazila_name","thana_name","ps","police_station"], 
      ids: ["upazila","upazila_id","thana","thana_id","ps","police_station"], 
      labels: ["upazila","উপজেলা","thana","থানা","sub-district","police station","p.s."], 
      placeholders: ["select upazila","উপজেলা নির্বাচন করুন","choose upazila","thana","Select","Beanibazar"] 
    }
  },
  post_office: {
    profileKey: "present_post_office", type: "text_select",
    patterns: { 
      names: ["post_office","post_office_name","po_name","postoffice","po","post_office_id"], 
      ids: ["post_office","post_office_name","postoffice","po"], 
      labels: ["post office","পোস্ট অফিস","po name","ডাকঘর","post office name"], 
      placeholders: ["post office","পোস্ট অফিস","select post office"] 
    }
  },
  postal_code: {
    profileKey: "present_post_code", type: "text",
    patterns: { 
      names: ["postal_code","zip_code","post_code","zip","postcode","postal","post_code_id"], 
      ids: ["postal_code","zip_code","post_code","zip","postcode"], 
      labels: ["postal code","পোস্টাল কোড","zip code","post code","পোস্ট কোড"], 
      placeholders: ["postal code","1000","পোস্ট কোড","zip code","post code"] 
    }
  },
  // ─── Education ──────────────────────────────────────────────────────────────
  // SSC/Equivalent Level
  ssc_examination: {
    profileKey: "ssc_examination", type: "select_text",
    patterns: { 
      names: ["ssc_exam_name","ssc_examination","exam_name","examination"], 
      ids: ["ssc_exam_name","ssc_examination","exam_name"], 
      labels: ["examination","exam name","পরীক্ষার নাম","ssc examination"], 
      placeholders: ["select examination","exam name"] 
    }
  },
  ssc_board: {
    profileKey: "ssc_board", type: "select_text",
    patterns: { 
      names: ["ssc_board","board","board_name","edu_board"], 
      ids: ["ssc_board","board","board_name"], 
      labels: ["board","বোর্ড","education board","ssc board"], 
      placeholders: ["select board","বোর্ড নির্বাচন করুন"] 
    }
  },
  ssc_roll: {
    profileKey: "ssc_roll", type: "text",
    patterns: { 
      names: ["ssc_roll","roll_no","roll","roll_number"], 
      ids: ["ssc_roll","roll_no","roll"], 
      labels: ["roll no","রোল নম্বর","roll number","ssc roll"], 
      placeholders: ["roll number","রোল নম্বর"] 
    }
  },
  ssc_result: {
    profileKey: "ssc_result", type: "text",
    patterns: { 
      names: ["ssc_gpa","ssc_result","gpa","result","grade"], 
      ids: ["ssc_gpa","ssc_result","gpa","result"], 
      labels: ["gpa","result","grade","জিপিএ","ফলাফল","ssc result"], 
      placeholders: ["gpa","result","5.00"] 
    }
  },
  ssc_group: {
    profileKey: "ssc_group", type: "select_text",
    patterns: { 
      names: ["ssc_group","group","subject_group","group_subject"], 
      ids: ["ssc_group","group","subject_group"], 
      labels: ["group","গ্রুপ","subject group","group/subject"], 
      placeholders: ["select group"] 
    }
  },
  ssc_passing_year: {
    profileKey: "ssc_passing_year", type: "text_select",
    patterns: { 
      names: ["ssc_passing_year","ssc_year","passing_year","pass_year"], 
      ids: ["ssc_passing_year","ssc_year","passing_year"], 
      labels: ["passing year","পাসের সন","ssc passing year"], 
      placeholders: ["passing year","yyyy"] 
    }
  },
  ssc_institution: {
    profileKey: "ssc_institution", type: "text",
    patterns: { 
      names: ["ssc_institute","ssc_institution","institute","school_name"], 
      ids: ["ssc_institute","ssc_institution","institute"], 
      labels: ["institution","school","institute name","প্রতিষ্ঠান"], 
      placeholders: ["institution name","school name"] 
    }
  },

  // HSC/Equivalent Level  
  hsc_examination: {
    profileKey: "hsc_examination", type: "select_text",
    patterns: { 
      names: ["hsc_exam_name","hsc_examination","exam_name","examination"], 
      ids: ["hsc_exam_name","hsc_examination"], 
      labels: ["examination","exam name","পরীক্ষার নাম","hsc examination"], 
      placeholders: ["select examination"] 
    }
  },
  hsc_board: {
    profileKey: "hsc_board", type: "select_text",
    patterns: { 
      names: ["hsc_board","board","board_name"], 
      ids: ["hsc_board","board","board_name"], 
      labels: ["board","বোর্ড","education board","hsc board"], 
      placeholders: ["select board"] 
    }
  },
  hsc_roll: {
    profileKey: "hsc_roll", type: "text",
    patterns: { 
      names: ["hsc_roll","roll_no","roll","roll_number"], 
      ids: ["hsc_roll","roll_no","roll"], 
      labels: ["roll no","রোল নম্বর","roll number","hsc roll"], 
      placeholders: ["roll number"] 
    }
  },
  hsc_result: {
    profileKey: "hsc_result", type: "text",
    patterns: { 
      names: ["hsc_gpa","hsc_result","gpa","result","grade"], 
      ids: ["hsc_gpa","hsc_result","gpa","result"], 
      labels: ["gpa","result","grade","জিপিএ","ফলাফল","hsc result"], 
      placeholders: ["gpa","result"] 
    }
  },
  hsc_group: {
    profileKey: "hsc_group", type: "select_text",
    patterns: { 
      names: ["hsc_group","group","subject_group"], 
      ids: ["hsc_group","group","subject_group"], 
      labels: ["group","গ্রুপ","subject group"], 
      placeholders: ["select group"] 
    }
  },
  hsc_passing_year: {
    profileKey: "hsc_passing_year", type: "text_select",
    patterns: { 
      names: ["hsc_passing_year","hsc_year","passing_year","pass_year"], 
      ids: ["hsc_passing_year","hsc_year","passing_year"], 
      labels: ["passing year","পাসের সন","hsc passing year"], 
      placeholders: ["passing year","yyyy"] 
    }
  },
  hsc_institution: {
    profileKey: "hsc_institution", type: "text",
    patterns: { 
      names: ["hsc_institute","hsc_institution","institute","college_name"], 
      ids: ["hsc_institute","hsc_institution","institute"], 
      labels: ["institution","college","institute name","প্রতিষ্ঠান"], 
      placeholders: ["institution name","college name"] 
    }
  },

  // Honours/Bachelor Level
  honours_examination: { 
    profileKey: "honours_examination", type: "select_text", 
    patterns: { 
      names: ["honours_exam","bachelor_exam","graduation_exam","examination"], 
      ids: ["honours_exam","bachelor_exam","graduation_exam"], 
      labels: ["examination","degree type","graduation","honours examination"], 
      placeholders: ["select examination"] 
    } 
  },
  honours_university: { 
    profileKey: "honours_university", type: "text", 
    patterns: { 
      names: ["honours_university","university","university_name","varsity"], 
      ids: ["honours_university","university","university_name"], 
      labels: ["university","বিশ্ববিদ্যালয়","university name","varsity"], 
      placeholders: ["university name"] 
    } 
  },
  honours_subject: { 
    profileKey: "honours_subject", type: "text", 
    patterns: { 
      names: ["honours_subject","subject","degree","major_subject"], 
      ids: ["honours_subject","subject","degree"], 
      labels: ["subject","বিষয়","degree","major subject","subject/degree"], 
      placeholders: ["subject name","degree"] 
    } 
  },
  honours_result: { 
    profileKey: "honours_result", type: "text", 
    patterns: { 
      names: ["honours_cgpa","honours_result","cgpa","result","grade"], 
      ids: ["honours_cgpa","honours_result","cgpa"], 
      labels: ["cgpa","result","grade","সিজিপিএ","ফলাফল"], 
      placeholders: ["cgpa","result"] 
    } 
  },
  honours_passing_year: { 
    profileKey: "honours_passing_year", type: "text_select", 
    patterns: { 
      names: ["honours_year","graduation_year","passing_year","pass_year"], 
      ids: ["honours_year","graduation_year","passing_year"], 
      labels: ["passing year","পাসের সন","graduation year"], 
      placeholders: ["passing year","yyyy"] 
    } 
  },
  honours_duration: { 
    profileKey: "honours_duration", type: "select_text", 
    patterns: { 
      names: ["honours_duration","course_duration","duration"], 
      ids: ["honours_duration","course_duration"], 
      labels: ["course duration","কোর্সের মেয়াদ","duration"], 
      placeholders: ["duration"] 
    } 
  },

  // Masters Level
  masters_examination: { 
    profileKey: "masters_examination", type: "select_text", 
    patterns: { 
      names: ["masters_exam","master_exam","post_graduation","examination"], 
      ids: ["masters_exam","master_exam","post_graduation"], 
      labels: ["examination","degree type","masters","post graduation"], 
      placeholders: ["select examination"] 
    } 
  },
  masters_university: { 
    profileKey: "masters_university", type: "text", 
    patterns: { 
      names: ["masters_university","university","university_name"], 
      ids: ["masters_university","university","university_name"], 
      labels: ["university","বিশ্ববিদ্যালয়","university name"], 
      placeholders: ["university name"] 
    } 
  },
  masters_subject: { 
    profileKey: "masters_subject", type: "text", 
    patterns: { 
      names: ["masters_subject","subject","degree","major_subject"], 
      ids: ["masters_subject","subject","degree"], 
      labels: ["subject","বিষয়","degree","major subject"], 
      placeholders: ["subject name","degree"] 
    } 
  },
  masters_result: { 
    profileKey: "masters_result", type: "text", 
    patterns: { 
      names: ["masters_cgpa","masters_result","cgpa","result","grade"], 
      ids: ["masters_cgpa","masters_result","cgpa"], 
      labels: ["cgpa","result","grade","সিজিপিএ","ফলাফল"], 
      placeholders: ["cgpa","result"] 
    } 
  },
  masters_passing_year: { 
    profileKey: "masters_passing_year", type: "text_select", 
    patterns: { 
      names: ["masters_year","post_grad_year","passing_year","pass_year"], 
      ids: ["masters_year","post_grad_year","passing_year"], 
      labels: ["passing year","পাসের সন","masters passing year"], 
      placeholders: ["passing year","yyyy"] 
    } 
  },
  masters_duration: { 
    profileKey: "masters_duration", type: "select_text", 
    patterns: { 
      names: ["masters_duration","course_duration","duration"], 
      ids: ["masters_duration","course_duration"], 
      labels: ["course duration","কোর্সের মেয়াদ","duration"], 
      placeholders: ["duration"] 
    } 
  },

  // Legacy education fields (for backward compatibility) - Enhanced patterns
  edu_exam: {
    profileKey: "ssc_examination", type: "select_text",
    patterns: { 
      names: ["exam_name","examination","edu_exam","exam_level"], 
      ids: ["exam_name","examination","edu_exam"], 
      labels: ["examination","exam name","পরীক্ষার নাম","education level"], 
      placeholders: ["select examination","exam name"] 
    }
  },
  edu_board: {
    profileKey: "ssc_board", type: "select_text",
    patterns: { 
      names: ["board","board_name","edu_board","board_id"], 
      ids: ["board","board_name","edu_board"], 
      labels: ["board","বোর্ড","education board","শিক্ষা বোর্ড"], 
      placeholders: ["select board","বোর্ড নির্বাচন করুন"] 
    }
  },
  edu_passing_year: {
    profileKey: "ssc_passing_year", type: "text_select",
    patterns: { 
      names: ["passing_year","pass_year","year_of_passing","passing_yr"], 
      ids: ["passing_year","pass_year","year_of_passing"], 
      labels: ["passing year","পাসের সন","year of passing","pass year"], 
      placeholders: ["passing year","yyyy","পাসের বছর"] 
    }
  },
  edu_gpa: {
    profileKey: "ssc_result", type: "text",
    patterns: { 
      names: ["gpa","cgpa","result","grade","marks"], 
      ids: ["gpa","cgpa","result","grade"], 
      labels: ["gpa","cgpa","result","grade","জিপিএ","সিজিপিএ","ফলাফল"], 
      placeholders: ["gpa","e.g. 5.00","cgpa"] 
    }
  },
  edu_institution: {
    profileKey: "ssc_institution", type: "text",
    patterns: { 
      names: ["institute","institution","school_name","college_name","university_name"], 
      ids: ["institute","institution","school_name"], 
      labels: ["institution","institute name","school/college","প্রতিষ্ঠানের নাম"], 
      placeholders: ["institution name","school/college name"] 
    }
  },
  experience: {
    profileKey: "experience", type: "textarea_text",
    patterns: { names: ["experience","work_experience"], ids: ["experience","work_experience"], labels: ["experience","অভিজ্ঞতা","work experience"], placeholders: ["experience details"] }
  },
  quota: {
    profileKey: "quota", type: "select_radio_checkbox",
    patterns: { names: ["quota","quota_id","freedom_fighter"], ids: ["quota","quota_id"], labels: ["quota","কোটা","freedom fighter quota"], placeholders: ["select quota"] },
    optionMap: { none: ["none","general","সাধারণ","0"], freedom_fighter: ["freedom fighter","মুক্তিযোদ্ধা","ff","1"], district: ["district","জেলা কোটা","2"], women: ["women","নারী","3"], tribal: ["tribal","উপজাতি","4"], disabled: ["disabled","প্রতিবন্ধী","5"] }
  },
  // SSC Level
  ssc_examination: { profileKey: "ssc_examination", type: "select_text", patterns: { names: ["ssc_exam_name","ssc_examination","exam_name"], ids: ["ssc_exam_name","ssc_examination"], labels: ["examination","ssc examination","পরীক্ষার নাম"], placeholders: ["select examination"] } },
  ssc_board: { profileKey: "ssc_board", type: "select_text", patterns: { names: ["ssc_board","board","board_name"], ids: ["ssc_board","board"], labels: ["board","বোর্ড","ssc board"], placeholders: ["select board"] } },
  ssc_roll: { profileKey: "ssc_roll", type: "text", patterns: { names: ["ssc_roll","roll_no","roll"], ids: ["ssc_roll","roll_no"], labels: ["roll no","রোল নম্বর","ssc roll"], placeholders: ["roll number"] } },
  ssc_result: { profileKey: "ssc_result", type: "text", patterns: { names: ["ssc_gpa","ssc_result","gpa","result"], ids: ["ssc_gpa","ssc_result"], labels: ["gpa","result","জিপিএ","ssc result"], placeholders: ["gpa","result"] } },
  ssc_group: { profileKey: "ssc_group", type: "select_text", patterns: { names: ["ssc_group","group","subject_group"], ids: ["ssc_group","group"], labels: ["group","গ্রুপ","subject group"], placeholders: ["select group"] } },
  ssc_passing_year: { profileKey: "ssc_passing_year", type: "text_select", patterns: { names: ["ssc_passing_year","ssc_year","passing_year"], ids: ["ssc_passing_year","ssc_year"], labels: ["passing year","পাসের সন","ssc passing year"], placeholders: ["passing year"] } },
  ssc_institution: { profileKey: "ssc_institution", type: "text", patterns: { names: ["ssc_institute","ssc_institution","institute","school_name"], ids: ["ssc_institute","ssc_institution"], labels: ["institution","school","প্রতিষ্ঠান"], placeholders: ["institution name"] } },
  // HSC Level
  hsc_examination: { profileKey: "hsc_examination", type: "select_text", patterns: { names: ["hsc_exam_name","hsc_examination","exam_name"], ids: ["hsc_exam_name","hsc_examination"], labels: ["examination","hsc examination","পরীক্ষার নাম"], placeholders: ["select examination"] } },
  hsc_board: { profileKey: "hsc_board", type: "select_text", patterns: { names: ["hsc_board","board","board_name"], ids: ["hsc_board","board"], labels: ["board","বোর্ড","hsc board"], placeholders: ["select board"] } },
  hsc_roll: { profileKey: "hsc_roll", type: "text", patterns: { names: ["hsc_roll","roll_no","roll"], ids: ["hsc_roll","roll_no"], labels: ["roll no","রোল নম্বর","hsc roll"], placeholders: ["roll number"] } },
  hsc_result: { profileKey: "hsc_result", type: "text", patterns: { names: ["hsc_gpa","hsc_result","gpa","result"], ids: ["hsc_gpa","hsc_result"], labels: ["gpa","result","জিপিএ","hsc result"], placeholders: ["gpa","result"] } },
  hsc_group: { profileKey: "hsc_group", type: "select_text", patterns: { names: ["hsc_group","group","subject_group"], ids: ["hsc_group","group"], labels: ["group","গ্রুপ","subject group"], placeholders: ["select group"] } },
  hsc_passing_year: { profileKey: "hsc_passing_year", type: "text_select", patterns: { names: ["hsc_passing_year","hsc_year","passing_year"], ids: ["hsc_passing_year","hsc_year"], labels: ["passing year","পাসের সন","hsc passing year"], placeholders: ["passing year"] } },
  hsc_institution: { profileKey: "hsc_institution", type: "text", patterns: { names: ["hsc_institute","hsc_institution","institute","college_name"], ids: ["hsc_institute","hsc_institution"], labels: ["institution","college","প্রতিষ্ঠান"], placeholders: ["institution name"] } },
  // Honours Level
  honours_examination: { profileKey: "honours_examination", type: "select_text", patterns: { names: ["honours_exam","bachelor_exam","graduation_exam"], ids: ["honours_exam","bachelor_exam"], labels: ["examination","honours examination","graduation"], placeholders: ["select examination"] } },
  honours_university: { profileKey: "honours_university", type: "text", patterns: { names: ["honours_university","university","university_name"], ids: ["honours_university","university"], labels: ["university","বিশ্ববিদ্যালয়"], placeholders: ["university name"] } },
  honours_subject: { profileKey: "honours_subject", type: "text", patterns: { names: ["honours_subject","subject","degree","major_subject"], ids: ["honours_subject","subject"], labels: ["subject","বিষয়","degree"], placeholders: ["subject name"] } },
  honours_result: { profileKey: "honours_result", type: "text", patterns: { names: ["honours_cgpa","honours_result","cgpa","result"], ids: ["honours_cgpa","honours_result"], labels: ["cgpa","result","সিজিপিএ"], placeholders: ["cgpa","result"] } },
  honours_passing_year: { profileKey: "honours_passing_year", type: "text_select", patterns: { names: ["honours_year","graduation_year","passing_year"], ids: ["honours_year","graduation_year"], labels: ["passing year","পাসের সন"], placeholders: ["passing year"] } },
  honours_duration: { profileKey: "honours_duration", type: "select_text", patterns: { names: ["honours_duration","course_duration","duration"], ids: ["honours_duration","course_duration"], labels: ["course duration","কোর্সের মেয়াদ"], placeholders: ["duration"] } },
  // Masters Level
  masters_examination: { profileKey: "masters_examination", type: "select_text", patterns: { names: ["masters_exam","master_exam","post_graduation"], ids: ["masters_exam","master_exam"], labels: ["examination","masters","post graduation"], placeholders: ["select examination"] } },
  masters_university: { profileKey: "masters_university", type: "text", patterns: { names: ["masters_university","university","university_name"], ids: ["masters_university","university"], labels: ["university","বিশ্ববিদ্যালয়"], placeholders: ["university name"] } },
  masters_subject: { profileKey: "masters_subject", type: "text", patterns: { names: ["masters_subject","subject","degree","major_subject"], ids: ["masters_subject","subject"], labels: ["subject","বিষয়","degree"], placeholders: ["subject name"] } },
  masters_result: { profileKey: "masters_result", type: "text", patterns: { names: ["masters_cgpa","masters_result","cgpa","result"], ids: ["masters_cgpa","masters_result"], labels: ["cgpa","result","সিজিপিএ"], placeholders: ["cgpa","result"] } },
  masters_passing_year: { profileKey: "masters_passing_year", type: "text_select", patterns: { names: ["masters_year","post_grad_year","passing_year"], ids: ["masters_year","post_grad_year"], labels: ["passing year","পাসের সন"], placeholders: ["passing year"] } },
  masters_duration: { profileKey: "masters_duration", type: "select_text", patterns: { names: ["masters_duration","course_duration","duration"], ids: ["masters_duration","course_duration"], labels: ["course duration","কোর্সের মেয়াদ"], placeholders: ["duration"] } },
  profile_photo: {
    profileKey: "profilePhoto", type: "file_image",
    patterns: { names: ["photo","image","picture","profile_photo","profile_picture","applicant_photo","passport_photo"], ids: ["photo","image","picture","profile_photo","applicant_photo"], labels: ["photo","ছবি","image","picture","profile photo","applicant photo","পাসপোর্ট সাইজ ছবি","আবেদনকারীর ছবি"], types: ["file"], accepts: ["image/*",".jpg",".jpeg",".png",".gif",".webp"] }
  },
  signature: {
    profileKey: "signature", type: "file_image",
    patterns: { names: ["signature","sign","applicant_signature","signature_image"], ids: ["signature","sign","applicant_signature"], labels: ["signature","স্বাক্ষর","sign","applicant signature","আবেদনকারীর স্বাক্ষর"], types: ["file"], accepts: ["image/*",".jpg",".jpeg",".png",".gif",".webp"] }
  }
};

// ─── State ────────────────────────────────────────────────────────────────────
let floatingBtn = null;
let fillCount = 0;
let debugMode = false; // Enable for debugging

// Enable debug mode if on localhost or with debug parameter
if (window.location.hostname === 'localhost' || window.location.search.includes('debug=1')) {
  debugMode = true;
  console.log('Teletalk Job Apply: Debug mode enabled');
}

// ─── Init ─────────────────────────────────────────────────────────────────────
(function init() {
  chrome.storage.local.get("settings", (data) => {
    const settings = data.settings || {};
    if (settings.showFloatingBtn !== false) {
      injectFloatingButton();
    }
  });
})();

// ─── Message Handler ──────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "DO_AUTOFILL") {
    chrome.storage.local.get(["profiles", "settings"], (data) => {
      const profiles = data.profiles || [];
      const settings = data.settings || {};
      const profileId = message.profileId || settings.activeProfileId;
      const profile = profiles.find(p => p.id === profileId) || profiles[0];
      if (!profile) {
        sendResponse({ ok: false, message: "No profile found" });
        return;
      }
      const count = autoFillForm(profile);
      sendResponse({ ok: true, filled: count });
    });
    return true;
  }
  if (message.action === "CLEAR_FORM") {
    clearAllFields();
    sendResponse({ ok: true });
  }
});

// ─── Floating Button ──────────────────────────────────────────────────────────
function injectFloatingButton() {
  if (floatingBtn) return;

  const wrapper = document.createElement("div");
  wrapper.id = "teletalk-fab-wrapper";
  wrapper.innerHTML = `
    <div id="teletalk-fab-main" title="Teletalk Job Apply">
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
        <path d="M12 20h9M16.5 3.5a2.121 2.121 0 013 3L7 19l-4 1 1-4L16.5 3.5z"/>
      </svg>
    </div>
    <div id="teletalk-fab-menu">
      <button id="teletalk-btn-fill" class="teletalk-fab-btn">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
        Auto Fill Form
      </button>
      <button id="teletalk-btn-clear" class="teletalk-fab-btn teletalk-btn-danger">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6M14 11v6"/></svg>
        Clear Form
      </button>
      <div id="teletalk-fab-status"></div>
    </div>
  `;

  document.body.appendChild(wrapper);
  floatingBtn = wrapper;

  // Toggle menu
  wrapper.querySelector("#teletalk-fab-main").addEventListener("click", () => {
    wrapper.classList.toggle("open");
  });

  // Fill button
  wrapper.querySelector("#teletalk-btn-fill").addEventListener("click", () => {
    const status = wrapper.querySelector("#teletalk-fab-status");
    status.textContent = "Filling...";
    chrome.storage.local.get(["profiles", "settings"], (data) => {
      const profiles = data.profiles || [];
      const settings = data.settings || {};
      const profile = profiles.find(p => p.id === settings.activeProfileId) || profiles[0];
      if (!profile) {
        status.textContent = "⚠ No profile found. Please set up your profile.";
        return;
      }
      const count = autoFillForm(profile);
      status.textContent = count > 0 ? `✓ Filled ${count} field(s)` : "⚠ No matching fields found";
      setTimeout(() => { status.textContent = ""; wrapper.classList.remove("open"); }, 2500);
    });
  });

  // Clear button
  wrapper.querySelector("#teletalk-btn-clear").addEventListener("click", () => {
    clearAllFields();
    const status = wrapper.querySelector("#teletalk-fab-status");
    status.textContent = "✓ Form cleared";
    setTimeout(() => { status.textContent = ""; wrapper.classList.remove("open"); }, 1500);
  });

  // Close on outside click
  document.addEventListener("click", (e) => {
    if (!wrapper.contains(e.target)) wrapper.classList.remove("open");
  });
}

// ─── Core AutoFill Engine ─────────────────────────────────────────────────────
function autoFillForm(profile) {
  fillCount = 0;
  const allInputs = Array.from(document.querySelectorAll(
    "input:not([type=hidden]):not([type=submit]):not([type=button]):not([type=image]):not([type=reset]), select, textarea"
  ));

  if (debugMode) {
    console.log('Teletalk Job Apply: Found', allInputs.length, 'form elements');
    console.log('Teletalk Job Apply: Profile data:', profile);
  }
  
  for (const [fieldKey, config] of Object.entries(FIELD_MAP)) {
    const value = profile[config.profileKey];
    if (!value && value !== 0) continue;

    const matchedElements = findMatchingElements(allInputs, config);
    
    if (debugMode && matchedElements.length > 0) {
      console.log(`Teletalk Job Apply: Field "${fieldKey}" (${config.profileKey}) found ${matchedElements.length} matches`);
    }
    
    for (const el of matchedElements) {
      if (debugMode) {
        console.log(`Teletalk Job Apply: Filling ${fieldKey} -> ${el.tagName}#${el.id || 'no-id'}.${el.className || 'no-class'} with value:`, value);
      }
      fillElement(el, value, config);
    }
  }
  
  if (debugMode) {
    console.log('Teletalk Job Apply: Completed filling', fillCount, 'fields');
  }
  
  return fillCount;
}

// ─── Field Finder ─────────────────────────────────────────────────────────────
function findMatchingElements(allInputs, config) {
  const { patterns } = config;
  const results = [];

  for (const el of allInputs) {
    const score = scoreElement(el, patterns);
    if (score > 0) {
      results.push({ el, score });
      // Debug logging for high-scoring elements
      if (score > 40 && debugMode) {
        console.log(`Teletalk Job Apply: Element scored ${score} points:`, {
          tag: el.tagName,
          id: el.id,
          name: el.name,
          className: el.className,
          placeholder: el.placeholder,
          label: getLabelText(el),
          profileKey: config.profileKey
        });
      }
    }
  }

  // Return highest-scored unique elements
  results.sort((a, b) => b.score - a.score);
  const seen = new Set();
  return results
    .filter(r => { if (seen.has(r.el)) return false; seen.add(r.el); return true; })
    .slice(0, 3) // Limit to top 3 matches to avoid over-filling
    .map(r => r.el);
}

function scoreElement(el, patterns) {
  let score = 0;
  const name = (el.name || "").toLowerCase();
  const id   = (el.id   || "").toLowerCase();
  const placeholder = (el.placeholder || "").toLowerCase();
  const type = (el.type || "").toLowerCase();
  const accept = (el.accept || "").toLowerCase();
  
  // Get all text content around the element for better context matching
  const className = (el.className || "").toLowerCase();
  const value = (el.value || "").toLowerCase();

  // Exact name match = highest priority
  if (patterns.names && patterns.names.some(p => name === p.toLowerCase())) score += 100;
  else if (patterns.names && patterns.names.some(p => name.includes(p.toLowerCase()) || p.toLowerCase().includes(name))) score += 70;

  // ID match
  if (patterns.ids && patterns.ids.some(p => id === p.toLowerCase())) score += 90;
  else if (patterns.ids && patterns.ids.some(p => id.includes(p.toLowerCase()) || p.toLowerCase().includes(id))) score += 60;

  // Class name matching for better detection
  if (patterns.names && patterns.names.some(p => className.includes(p.toLowerCase()))) score += 40;

  // For file inputs, check accept attribute
  if (type === "file" && patterns.accepts) {
    if (patterns.accepts.some(a => accept.includes(a.toLowerCase()))) score += 70;
  }

  // Placeholder match - Enhanced with specific Teletalk patterns
  if (patterns.placeholders) {
    for (const pp of patterns.placeholders) {
      const ppLower = pp.toLowerCase();
      if (placeholder.includes(ppLower) || ppLower.includes(placeholder)) {
        score += 35;
        break;
      }
      // Special scoring for specific Teletalk placeholder patterns
      if ((ppLower === "md sharifur islam" && placeholder.includes("sharifur")) ||
          (ppLower === "select" && placeholder === "select") ||
          (ppLower === "sylhet" && placeholder.includes("sylhet")) ||
          (ppLower === "beanibazar" && placeholder.includes("beanibazar"))) {
        score += 50; // Higher score for specific Teletalk patterns
        break;
      }
    }
  }

  // Label text match (most reliable for Bangla) - enhanced matching
  const labelText = getLabelText(el).toLowerCase();
  if (patterns.labels) {
    for (const lp of patterns.labels) {
      const lpLower = lp.toLowerCase();
      if (labelText === lpLower) { score += 80; break; }
      if (labelText.includes(lpLower) || lpLower.includes(labelText)) { score += 50; break; }
      // Check for partial matches with common variations
      if (labelText.includes(lpLower.replace(/[\/\s]/g, '')) || lpLower.includes(labelText.replace(/[\/\s]/g, ''))) { score += 45; break; }
    }
  }

  // Enhanced boost score for address-specific fields with more patterns
  if (name.includes('address') || id.includes('address') || labelText.includes('address') || labelText.includes('ঠিকানা')) {
    score += 25;
  }
  
  if (name.includes('district') || id.includes('district') || labelText.includes('district') || labelText.includes('জেলা')) {
    score += 25;
  }
  
  if (name.includes('upazila') || name.includes('thana') || id.includes('upazila') || id.includes('thana') || 
      labelText.includes('upazila') || labelText.includes('thana') || labelText.includes('উপজেলা') || labelText.includes('থানা') ||
      labelText.includes('p.s.') || labelText.includes('police station')) {
    score += 25;
  }
  
  // Additional boost for care of fields
  if (name.includes('care') || name.includes('c_o') || id.includes('care') || id.includes('c_o') ||
      labelText.includes('care of') || labelText.includes('c/o') || labelText.includes('যত্নে')) {
    score += 25;
  }
  
  // Additional boost for post office and postal code fields
  if (name.includes('post') || id.includes('post') || labelText.includes('post office') || labelText.includes('ডাকঘর') ||
      labelText.includes('postal') || labelText.includes('zip') || labelText.includes('পোস্ট কোড')) {
    score += 25;
  }
  
  // Boost for education fields
  if (name.includes('ssc') || name.includes('hsc') || name.includes('honours') || name.includes('masters') ||
      id.includes('ssc') || id.includes('hsc') || id.includes('honours') || id.includes('masters') ||
      labelText.includes('ssc') || labelText.includes('hsc') || labelText.includes('honours') || labelText.includes('masters') ||
      labelText.includes('examination') || labelText.includes('board') || labelText.includes('বোর্ড') ||
      labelText.includes('passing year') || labelText.includes('পাসের সন') || labelText.includes('roll') ||
      labelText.includes('gpa') || labelText.includes('জিপিএ') || labelText.includes('institution') ||
      labelText.includes('প্রতিষ্ঠান')) {
    score += 20;
  }

  return score;
}

function getLabelText(el) {
  // Try <label for="id">
  if (el.id) {
    const label = document.querySelector(`label[for="${el.id}"]`);
    if (label) return label.innerText.trim();
  }
  
  // Try parent/ancestor label
  let parent = el.parentElement;
  for (let i = 0; i < 5; i++) {
    if (!parent) break;
    
    if (parent.tagName === "LABEL") return parent.innerText.trim();
    
    const nearLabel = parent.querySelector("label");
    if (nearLabel && nearLabel !== el) return nearLabel.innerText.trim();
    
    // Check for text nodes or spans that might act as labels
    const textNodes = Array.from(parent.childNodes).filter(node => 
      node.nodeType === Node.TEXT_NODE || 
      (node.tagName && ['SPAN', 'DIV', 'P', 'TD', 'TH'].includes(node.tagName))
    );
    
    for (const textNode of textNodes) {
      const text = (textNode.textContent || textNode.innerText || '').trim();
      if (text && text.length > 2 && text.length < 100) {
        // Skip if it looks like a value rather than a label
        if (!/^\d+$/.test(text) && !text.includes('select') && !text.includes('choose')) {
          return text;
        }
      }
    }
    
    // td/th sibling approach for table forms
    if (parent.tagName === "TD" || parent.tagName === "DIV" || parent.tagName === "TR") {
      const prev = parent.previousElementSibling;
      if (prev) {
        const prevText = (prev.innerText || prev.textContent || '').trim();
        if (prevText && prevText.length > 2 && prevText.length < 100) return prevText;
      }
      
      // Also check next sibling in case label comes after
      const next = parent.nextElementSibling;  
      if (next) {
        const nextText = (next.innerText || next.textContent || '').trim();
        if (nextText && nextText.length > 2 && nextText.length < 100 && 
            (nextText.includes(':') || nextText.includes('নাম') || nextText.includes('ঠিকানা'))) {
          return nextText;
        }
      }
    }
    
    parent = parent.parentElement;
  }
  
  // Last resort: check aria-label or title
  if (el.getAttribute('aria-label')) return el.getAttribute('aria-label').trim();
  if (el.title) return el.title.trim();
  
  return "";
}

// ─── Element Filler ───────────────────────────────────────────────────────────
function fillElement(el, value, config) {
  const tag  = el.tagName.toLowerCase();
  const type = (el.type || "").toLowerCase();

  if (tag === "select") {
    fillSelect(el, value, config.optionMap);
  } else if (type === "radio") {
    fillRadioGroup(el, value, config.optionMap);
  } else if (type === "checkbox") {
    fillCheckbox(el, value, config.optionMap);
  } else if (type === "file") {
    fillFileInput(el, value, config);
  } else if (tag === "textarea" || type === "text" || type === "email" || type === "tel" || type === "" || type === "number" || type === "date") {
    fillTextInput(el, value);
  }
}

function fillTextInput(el, value) {
  if (el.value === value) return;
  
  // Focus the element first
  el.focus();
  
  // Handle different input types appropriately
  const inputType = (el.type || '').toLowerCase();
  let processedValue = value;
  
  // For date inputs, try to format the value appropriately
  if (inputType === 'date') {
    // Try to convert DD/MM/YYYY to YYYY-MM-DD
    if (typeof value === 'string' && value.match(/^\d{2}\/\d{2}\/\d{4}$/)) {
      const parts = value.split('/');
      processedValue = `${parts[2]}-${parts[1]}-${parts[0]}`;
    }
  }
  
  // Clear existing value first
  el.value = '';
  
  // Native input value setter to trigger React/Vue watchers
  const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement?.prototype || {}, "value")?.set
    || Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement?.prototype || {}, "value")?.set;
  
  if (nativeInputValueSetter) {
    nativeInputValueSetter.call(el, processedValue);
  } else {
    el.value = processedValue;
  }
  
  // Set the value directly as well for maximum compatibility
  el.setAttribute('value', processedValue);
  
  triggerEvents(el);
  fillCount++;
  
  if (debugMode) {
    console.log(`Teletalk Job Apply: Successfully filled text input with: "${processedValue}"`);
  }
}

function fillSelect(el, value, optionMap) {
  const valueLower = value.toString().toLowerCase();
  let filled = false;
  
  // Try to find option by text or value (exact match first)
  for (const opt of el.options) {
    const optText  = opt.text.toLowerCase().trim();
    const optValue = opt.value.toLowerCase().trim();
    
    if (optText === valueLower || optValue === valueLower) {
      if (el.value !== opt.value) { 
        el.value = opt.value; 
        triggerEvents(el); 
        fillCount++; 
        filled = true;
        if (debugMode) console.log(`Teletalk Job Apply: Exact match found for select: "${opt.text}"`);
      }
      return;
    }
  }
  
  // Try optionMap matching
  if (optionMap && !filled) {
    for (const [profileVal, aliases] of Object.entries(optionMap)) {
      if (aliases.map(a => a.toLowerCase()).includes(valueLower)) {
        for (const opt of el.options) {
          const optText  = opt.text.toLowerCase().trim();
          const optValue = opt.value.toLowerCase().trim();
          if (aliases.map(a => a.toLowerCase()).some(a => optText.includes(a) || optValue === a)) {
            if (el.value !== opt.value) { 
              el.value = opt.value; 
              triggerEvents(el); 
              fillCount++; 
              filled = true;
              if (debugMode) console.log(`Teletalk Job Apply: Option map match found: "${opt.text}"`);
            }
            return;
          }
        }
      }
    }
  }
  
  // Partial match fallback (more aggressive matching)
  if (!filled) {
    const matches = [];
    for (const opt of el.options) {
      const optText = opt.text.toLowerCase().trim();
      const optValue = opt.value.toLowerCase().trim();
      
      // Check if option text contains our value or vice versa
      if ((optText.includes(valueLower) || valueLower.includes(optText)) && optText.length > 1) {
        matches.push({ opt, score: optText === valueLower ? 100 : (optText.includes(valueLower) ? 80 : 60) });
      }
      // Also check option values
      if (optValue.includes(valueLower) && optValue.length > 0) {
        matches.push({ opt, score: optValue === valueLower ? 90 : 50 });
      }
    }
    
    // Sort by best match and take the first one
    if (matches.length > 0) {
      matches.sort((a, b) => b.score - a.score);
      const bestMatch = matches[0].opt;
      if (el.value !== bestMatch.value) {
        el.value = bestMatch.value;
        triggerEvents(el);
        fillCount++;
        if (debugMode) console.log(`Teletalk Job Apply: Partial match found: "${bestMatch.text}" (score: ${matches[0].score})`);
      }
    }
  }
}

function fillRadioGroup(el, value, optionMap) {
  const valueLower = value.toString().toLowerCase();
  // Find all radio buttons with same name
  const radios = document.querySelectorAll(`input[type=radio][name="${el.name}"]`);
  for (const radio of radios) {
    const radioVal = radio.value.toLowerCase();
    const radioLabel = getLabelText(radio).toLowerCase();
    if (radioVal === valueLower || radioLabel === valueLower) {
      if (!radio.checked) { radio.checked = true; triggerEvents(radio); fillCount++; }
      return;
    }
    if (optionMap) {
      for (const [, aliases] of Object.entries(optionMap)) {
        if (aliases.map(a => a.toLowerCase()).includes(valueLower)) {
          if (aliases.map(a => a.toLowerCase()).some(a => radioVal === a || radioLabel.includes(a))) {
            if (!radio.checked) { radio.checked = true; triggerEvents(radio); fillCount++; }
            return;
          }
        }
      }
    }
  }
}

function fillCheckbox(el, value, optionMap) {
  const valueLower = value.toString().toLowerCase();
  const elVal = el.value.toLowerCase();
  const shouldCheck = valueLower === "true" || valueLower === "1" || valueLower === "yes" || elVal === valueLower;
  if (el.checked !== shouldCheck) {
    el.checked = shouldCheck;
    triggerEvents(el);
    fillCount++;
  }
}

function fillFileInput(el, dataURL, config) {
  if (!dataURL || typeof dataURL !== 'string' || !dataURL.startsWith('data:')) {
    return; // Invalid data URL
  }

  try {
    // Convert data URL to File object
    const arr = dataURL.split(',');
    const mime = arr[0].match(/:(.*?);/)[1];
    const bstr = atob(arr[1]);
    let n = bstr.length;
    const u8arr = new Uint8Array(n);
    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }

    // Generate appropriate filename based on field type
    let filename = 'document.jpg';
    if (config.profileKey === 'profilePhoto') {
      filename = 'profile_photo.jpg';
    } else if (config.profileKey === 'signature') {
      filename = 'signature.jpg';
    }

    const file = new File([u8arr], filename, { type: mime });

    // Create a new FileList containing our file
    const dataTransfer = new DataTransfer();
    dataTransfer.items.add(file);
    el.files = dataTransfer.files;

    // Trigger change event to notify the form
    triggerEvents(el);
    fillCount++;

    // Visual feedback - show filename near the input
    showFileUploadFeedback(el, filename);

  } catch (error) {
    console.warn('Failed to fill file input:', error);
  }
}

function showFileUploadFeedback(fileInput, filename) {
  // Remove any existing feedback
  const existingFeedback = fileInput.parentNode.querySelector('.teletalk-file-feedback');
  if (existingFeedback) {
    existingFeedback.remove();
  }

  // Create feedback element
  const feedback = document.createElement('div');
  feedback.className = 'teletalk-file-feedback';
  feedback.style.cssText = `
    font-size: 11px;
    color: #006a4e;
    margin-top: 4px;
    padding: 4px 8px;
    background: #e6f4ef;
    border-radius: 4px;
    border-left: 3px solid #006a4e;
  `;
  feedback.textContent = `✓ Uploaded: ${filename}`;

  // Insert after the file input
  fileInput.parentNode.insertBefore(feedback, fileInput.nextSibling);

  // Auto-remove after 5 seconds
  setTimeout(() => {
    if (feedback.parentNode) {
      feedback.parentNode.removeChild(feedback);
    }
  }, 5000);
}

function triggerEvents(el) {
  // Trigger multiple events to ensure compatibility with different frameworks
  const events = [
    'input',
    'change', 
    'blur',
    'keyup',
    'keydown',
    'focus'
  ];
  
  events.forEach(eventType => {
    // Create and dispatch the event
    const event = new Event(eventType, { 
      bubbles: true, 
      cancelable: true,
      view: window
    });
    el.dispatchEvent(event);
  });
  
  // Also trigger React-specific events if they exist
  if (window.React) {
    try {
      const event = new Event('input', { bubbles: true });
      Object.defineProperty(event, 'target', { writable: false, value: el });
      Object.defineProperty(event, 'currentTarget', { writable: false, value: el });
      el.dispatchEvent(event);
    } catch (e) {
      // Ignore errors
    }
  }
  
  // Trigger a delayed change event as well
  setTimeout(() => {
    const changeEvent = new Event('change', { bubbles: true });
    el.dispatchEvent(changeEvent);
  }, 100);
}

// ─── Clear All Fields ─────────────────────────────────────────────────────────
function clearAllFields() {
  document.querySelectorAll("input:not([type=hidden]):not([type=submit]):not([type=button])").forEach(el => {
    if (el.type === "checkbox" || el.type === "radio") {
      el.checked = false;
    } else {
      el.value = "";
    }
    triggerEvents(el);
  });
  document.querySelectorAll("select").forEach(el => {
    el.selectedIndex = 0;
    triggerEvents(el);
  });
  document.querySelectorAll("textarea").forEach(el => {
    el.value = "";
    triggerEvents(el);
  });
}

// ─── Dynamic Form Observer ────────────────────────────────────────────────────
// Re-inject button if DOM changes reload the page structure
const observer = new MutationObserver(() => {
  if (!document.getElementById("teletalk-fab-wrapper")) {
    chrome.storage.local.get("settings", (data) => {
      if ((data.settings || {}).showFloatingBtn !== false) {
        injectFloatingButton();
      }
    });
  }
});
observer.observe(document.body, { childList: true, subtree: false });

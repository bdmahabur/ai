/**
 * encryption.js-Teletalk Job Apply-Modified by Mahabur Hossain-01781040050
 * Optional client-side AES-GCM encryption for profile data stored in Chrome local storage.
 * Runs completely locally using the browser's native Web Crypto API.
 */

const Encryption = (() => {
  const ALGO = "AES-GCM";
  const KEY_LEN = 256;

  /**
   * Derive a CryptoKey from a password and salt using PBKDF2
   */
  async function deriveKey(password, salt) {
    const enc = new TextEncoder();
    const keyMaterial = await crypto.subtle.importKey(
      "raw",
      enc.encode(password),
      "PBKDF2",
      false,
      ["deriveKey"]
    );
    return crypto.subtle.deriveKey(
      {
        name: "PBKDF2",
        salt: salt,
        iterations: 100000,
        hash: "SHA-256"
      },
      keyMaterial,
      { name: ALGO, length: KEY_LEN },
      false,
      ["encrypt", "decrypt"]
    );
  }

  /**
   * Encrypt an object with a password
   */
  async function encrypt(obj, password) {
    const salt = crypto.getRandomValues(new Uint8Array(16));
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const key = await deriveKey(password, salt);
    const data = new TextEncoder().encode(JSON.stringify(obj));
    
    const ciphertext = await crypto.subtle.encrypt(
      { name: ALGO, iv: iv },
      key,
      data
    );

    // Pack: salt (16 bytes) + iv (12 bytes) + ciphertext
    const combined = new Uint8Array(salt.length + iv.length + ciphertext.byteLength);
    combined.set(salt, 0);
    combined.set(iv, salt.length);
    combined.set(new Uint8Array(ciphertext), salt.length + iv.length);

    return btoa(String.fromCharCode(...combined));
  }

  /**
   * Decrypt a base64 ciphertext with a password
   */
  async function decrypt(b64, password) {
    const combined = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
    const salt = combined.slice(0, 16);
    const iv = combined.slice(16, 28);
    const ciphertext = combined.slice(28);
    
    const key = await deriveKey(password, salt);
    
    const plaintext = await crypto.subtle.decrypt(
      { name: ALGO, iv: iv },
      key,
      ciphertext
    );

    return JSON.parse(new TextDecoder().decode(plaintext));
  }

  return { encrypt, decrypt };
})();

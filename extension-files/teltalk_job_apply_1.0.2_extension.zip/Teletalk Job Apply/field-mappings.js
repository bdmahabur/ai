/**
 * field-mappings.js-Teletalk Job Apply-Modified by Mahabur Hossain-01781040050
 * Standard field mapping configurations for Bangladesh Teletalk government job application portals.
 * Used by content.js to match and map DOM input elements with profile fields.
 */

const FIELD_MAP = {
  // ─── Personal Information ───────────────────────────────────────────────────
  applicant_name_en: {
    profileKey: "applicant_name_en",
    type: "text",
    patterns: {
      names: ["applicant_name", "full_name", "name_en", "applicant_name_en", "fullname", "applicantname"],
      ids: ["applicant_name", "full_name", "name_en", "fullname", "applicantname"],
      labels: ["applicant name", "full name", "name (english)", "name in english", "applicant's name"],
      placeholders: ["enter name", "full name", "applicant name"]
    }
  },
  applicant_name_bn: {
    profileKey: "applicant_name_bn",
    type: "text",
    patterns: {
      names: ["applicant_name_bn", "name_bn", "bangla_name", "name_bangla"],
      ids: ["applicant_name_bn", "name_bn", "bangla_name"],
      labels: ["নাম", "আবেদনকারীর নাম", "আবেদনকারীর নাম (বাংলা)", "পূর্ণ নাম", "name (bangla)", "name in bangla"],
      placeholders: ["বাংলায় নাম লিখুন", "নাম"]
    }
  },
  father_name_en: {
    profileKey: "father_name_en",
    type: "text",
    patterns: {
      names: ["father_name", "father_name_en", "fathers_name", "fname_en", "fathername"],
      ids: ["father_name", "father_name_en", "fathers_name"],
      labels: ["father's name", "father name", "father's name (english)", "name of father"],
      placeholders: ["father's name", "enter father name"]
    }
  },
  father_name_bn: {
    profileKey: "father_name_bn",
    type: "text",
    patterns: {
      names: ["father_name_bn", "fathers_name_bn", "fname_bn"],
      ids: ["father_name_bn", "fathers_name_bn"],
      labels: ["পিতার নাম", "বাবার নাম", "father's name (bangla)", "পিতা/অভিভাবকের নাম"],
      placeholders: ["পিতার নাম লিখুন"]
    }
  },
  mother_name_en: {
    profileKey: "mother_name_en",
    type: "text",
    patterns: {
      names: ["mother_name", "mother_name_en", "mothers_name", "mname_en", "mothername"],
      ids: ["mother_name", "mother_name_en", "mothers_name"],
      labels: ["mother's name", "mother name", "mother's name (english)", "name of mother"],
      placeholders: ["mother's name", "enter mother name"]
    }
  },
  mother_name_bn: {
    profileKey: "mother_name_bn",
    type: "text",
    patterns: {
      names: ["mother_name_bn", "mothers_name_bn", "mname_bn"],
      ids: ["mother_name_bn", "mothers_name_bn"],
      labels: ["মাতার নাম", "মায়ের নাম", "mother's name (bangla)", "মাতা/অভিভাবকের নাম"],
      placeholders: ["মাতার নাম লিখুন"]
    }
  },
  date_of_birth: {
    profileKey: "date_of_birth",
    type: "text",
    patterns: {
      names: ["dob", "date_of_birth", "birth_date", "birthdate", "dateofbirth"],
      ids: ["dob", "date_of_birth", "birth_date", "dateofbirth"],
      labels: ["date of birth", "birth date", "জন্ম তারিখ", "d.o.b", "dob"],
      placeholders: ["dd/mm/yyyy", "yyyy-mm-dd", "date of birth", "জন্ম তারিখ"]
    }
  },
  birth_reg_no: {
    profileKey: "birth_reg_no",
    type: "text",
    patterns: {
      names: ["birth_reg_no", "birth_registration", "birth_cert_no", "brn", "birthregno"],
      ids: ["birth_reg_no", "birth_registration", "birth_cert"],
      labels: ["birth registration number", "birth certificate number", "জন্ম নিবন্ধন নম্বর", "birth reg. no", "birth registration no"],
      placeholders: ["birth registration no", "enter birth reg no"]
    }
  },
  nid: {
    profileKey: "nid",
    type: "text",
    patterns: {
      names: ["nid", "national_id", "nid_no", "national_id_no", "voter_id", "nationalid"],
      ids: ["nid", "national_id", "nid_no", "voter_id"],
      labels: ["national id", "nid", "national identity", "জাতীয় পরিচয়পত্র নম্বর", "nid number", "voter id", "national id (nid)"],
      placeholders: ["enter nid", "national id no", "nid number"]
    }
  },
  gender: {
    profileKey: "gender",
    type: "select_radio",
    patterns: {
      names: ["gender", "sex"],
      ids: ["gender", "sex"],
      labels: ["gender", "লিঙ্গ", "sex"],
      placeholders: ["select gender"]
    },
    optionMap: {
      "male": ["male", "পুরুষ", "m", "1"],
      "female": ["female", "মহিলা", "নারী", "f", "2"],
      "other": ["other", "অন্যান্য", "3"]
    }
  },
  religion: {
    profileKey: "religion",
    type: "select_radio",
    patterns: {
      names: ["religion", "religion_id"],
      ids: ["religion", "religion_id"],
      labels: ["religion", "ধর্ম"],
      placeholders: ["select religion", "ধর্ম নির্বাচন করুন"]
    },
    optionMap: {
      "islam": ["islam", "ইসলাম", "muslim", "মুসলিম", "1"],
      "hinduism": ["hinduism", "hindu", "হিন্দু", "2"],
      "christianity": ["christianity", "christian", "খ্রিষ্টান", "3"],
      "buddhism": ["buddhism", "buddhist", "বৌদ্ধ", "4"],
      "other": ["other", "অন্যান্য", "5"]
    }
  },
  nationality: {
    profileKey: "nationality",
    type: "text_select",
    patterns: {
      names: ["nationality", "citizenship"],
      ids: ["nationality", "citizenship"],
      labels: ["nationality", "জাতীয়তা", "citizenship"],
      placeholders: ["nationality", "enter nationality"]
    },
    defaultValue: "Bangladeshi"
  },
  marital_status: {
    profileKey: "marital_status",
    type: "select_radio",
    patterns: {
      names: ["marital_status", "marital", "marriage_status"],
      ids: ["marital_status", "marital", "marriage_status"],
      labels: ["marital status", "বৈবাহিক অবস্থা", "marriage status"],
      placeholders: ["select marital status"]
    },
    optionMap: {
      "single": ["single", "অবিবাহিত", "unmarried", "1"],
      "married": ["married", "বিবাহিত", "2"],
      "divorced": ["divorced", "তালাকপ্রাপ্ত", "3"],
      "widowed": ["widowed", "বিধবা", "বিপত্নীক", "4"]
    }
  },
  mobile: {
    profileKey: "mobile",
    type: "text",
    patterns: {
      names: ["mobile", "mobile_no", "phone", "phone_no", "contact_no", "cell", "mobileno"],
      ids: ["mobile", "mobile_no", "phone", "contact_no"],
      labels: ["mobile", "মোবাইল", "mobile number", "মোবাইল নম্বর", "phone", "contact number"],
      placeholders: ["01xxxxxxxxx", "mobile no", "phone number", "মোবাইল নম্বর"]
    }
  },
  email: {
    profileKey: "email",
    type: "text",
    patterns: {
      names: ["email", "email_address", "e_mail"],
      ids: ["email", "email_address"],
      labels: ["email", "ইমেইল", "e-mail", "email address", "ইমেইল ঠিকানা"],
      placeholders: ["email@example.com", "enter email", "ইমেইল"]
    }
  },

  // ─── Present Address ────────────────────────────────────────────────────────
  present_care_of: {
    profileKey: "present_care_of",
    type: "text",
    patterns: {
      names: ["present_care_of", "care_of", "c_o", "care_of_present", "careof", "care", "co", "careofpresent"],
      ids: ["present_care_of", "care_of", "c_o", "careof", "care", "co"],
      labels: ["care of", "c/o", "যত্নে", "care of (present)", "careof", "care", "present care of"],
      placeholders: ["care of", "c/o", "careof"]
    }
  },
  present_village_town: {
    profileKey: "present_village_town",
    type: "text",
    patterns: {
      names: ["present_village", "village_town", "village_present", "town_present", "road_present", "village", "town", "road", "village_town_road", "area_present", "villagetown"],
      ids: ["present_village", "village_town", "village_present", "village", "town", "road"],
      labels: ["village", "গ্রাম", "town", "শহর", "village/town/road", "village/town", "road", "area", "এলাকা", "village / town / road"],
      placeholders: ["village/town/road", "village name", "town name", "road name"]
    }
  },
  present_house_flat: {
    profileKey: "present_house_flat",
    type: "text",
    patterns: {
      names: ["present_house", "house_flat", "house_present", "flat_present", "building_present", "house", "flat", "building", "house_no", "flat_no", "houseflat"],
      ids: ["present_house", "house_flat", "house_present", "house", "flat", "building"],
      labels: ["house", "বাড়ি", "flat", "ফ্ল্যাট", "house/flat", "building", "ভবন", "house no", "flat no", "house / flat"],
      placeholders: ["house/flat", "house no", "flat no", "building"]
    }
  },
  present_district: {
    profileKey: "present_district",
    type: "select_text",
    patterns: {
      names: ["present_district", "district_present", "district", "dist_present", "district_name", "present_dist"],
      ids: ["present_district", "district_present", "district", "dist", "district_name"],
      labels: ["district", "জেলা", "present district", "বর্তমান জেলা", "district name", "জেলার নাম"],
      placeholders: ["select district", "জেলা নির্বাচন করুন", "district"]
    }
  },
  present_upazila: {
    profileKey: "present_upazila",
    type: "text_select",
    patterns: {
      names: ["present_upazila", "upazila_present", "upazila", "thana_present", "ps_present", "thana", "police_station", "sub_district", "upazila_ps", "upazilaps"],
      ids: ["present_upazila", "upazila_present", "upazila", "thana", "ps", "police_station"],
      labels: ["upazila", "উপজেলা", "thana", "থানা", "p.s.", "police station", "upazila/p.s.", "sub district", "upazila/thana", "upazila/ps"],
      placeholders: ["upazila/p.s.", "উপজেলা", "thana", "police station"]
    }
  },
  present_post_office: {
    profileKey: "present_post_office",
    type: "text",
    patterns: {
      names: ["present_post_office", "post_office_present", "post_office", "po_present", "postoffice", "po", "post_office_name", "postofficepresent"],
      ids: ["present_post_office", "post_office_present", "post_office", "po", "postoffice"],
      labels: ["post office", "ডাকঘর", "p.o.", "present post office", "post office name", "ডাক অফিস"],
      placeholders: ["post office", "ডাকঘর", "p.o.", "post office name"]
    }
  },
  present_post_code: {
    profileKey: "present_post_code",
    type: "text",
    patterns: {
      names: ["present_post_code", "postal_code_present", "post_code", "zip_present", "postcode", "zip", "postal_code", "zip_code", "postcodepresent"],
      ids: ["present_post_code", "postal_code_present", "post_code", "postcode", "zip", "postal_code"],
      labels: ["post code", "পোস্ট কোড", "postal code", "zip code", "পোস্টাল কোড"],
      placeholders: ["post code", "postal code", "zip code", "পোস্ট কোড"]
    }
  },
  present_address_bn: {
    profileKey: "present_address_bn",
    type: "textarea_text",
    patterns: {
      names: ["present_address_bn", "present_address_bangla", "cur_address_bn", "address_bn_present", "present_addr_bn"],
      ids: ["present_address_bn", "present_address_bangla", "address_bn_present"],
      labels: ["বর্তমান ঠিকানা", "present address (bangla)", "present address (বাংলায়)", "ঠিকানা (বাংলা)", "বর্তমান ঠিকানা (বাংলা)"],
      placeholders: ["বর্তমান ঠিকানা লিখুন", "বর্তমান ঠিকানা", "ঠিকানা বাংলায়"]
    }
  },
  present_address_en: {
    profileKey: "present_address_en",
    type: "textarea_text",
    patterns: {
      names: ["present_address", "present_address_en", "present_address_english", "cur_address", "current_address", "present_addr", "address_present"],
      ids: ["present_address", "present_address_en", "present_address_english", "cur_address", "current_address"],
      labels: ["present address", "present address (english)", "বর্তমান ঠিকানা (ইংরেজি)", "current address", "address (english)"],
      placeholders: ["present address", "enter present address", "current address"]
    }
  },

  // ─── Permanent Address ──────────────────────────────────────────────────────
  permanent_care_of: {
    profileKey: "permanent_care_of",
    type: "text",
    patterns: {
      names: ["permanent_care_of", "care_of_permanent", "perm_care_of", "care_of_perm", "permanent_careof", "careofpermanent"],
      ids: ["permanent_care_of", "care_of_permanent", "perm_care_of", "permanent_careof"],
      labels: ["care of", "c/o", "যত্নে", "care of (permanent)", "permanent care of"],
      placeholders: ["care of", "c/o", "careof"]
    }
  },
  permanent_village_town: {
    profileKey: "permanent_village_town",
    type: "text",
    patterns: {
      names: ["permanent_village", "village_permanent", "town_permanent", "road_permanent", "perm_village", "perm_town", "village_perm", "permanentvillagetown"],
      ids: ["permanent_village", "village_permanent", "town_permanent", "perm_village"],
      labels: ["village", "গ্রাম", "town", "শহর", "village/town/road", "village/town", "road", "area", "স্থায়ী গ্রাম"],
      placeholders: ["village/town/road", "village name", "town name"]
    }
  },
  permanent_house_flat: {
    profileKey: "permanent_house_flat",
    type: "text",
    patterns: {
      names: ["permanent_house", "house_permanent", "flat_permanent", "building_permanent", "perm_house", "perm_flat", "house_perm", "permanenthouseflat"],
      ids: ["permanent_house", "house_permanent", "flat_permanent", "perm_house"],
      labels: ["house", "বাড়ি", "flat", "ফ্ল্যাট", "house/flat", "building", "স্থায়ী বাড়ি"],
      placeholders: ["house/flat", "house no", "flat no"]
    }
  },
  permanent_district: {
    profileKey: "permanent_district",
    type: "select_text",
    patterns: {
      names: ["permanent_district", "district_permanent", "perm_district", "district_perm", "permanent_dist"],
      ids: ["permanent_district", "district_permanent", "perm_district", "permanent_dist"],
      labels: ["district", "জেলা", "permanent district", "স্থায়ী জেলা", "district name"],
      placeholders: ["select district", "জেলা নির্বাচন করুন", "district"]
    }
  },
  permanent_upazila: {
    profileKey: "permanent_upazila",
    type: "text_select",
    patterns: {
      names: ["permanent_upazila", "upazila_permanent", "thana_permanent", "ps_permanent", "perm_upazila", "perm_thana", "upazila_perm", "permanentupazilaps"],
      ids: ["permanent_upazila", "upazila_permanent", "thana_permanent", "perm_upazila"],
      labels: ["upazila", "উপজেলা", "thana", "থানা", "p.s.", "police station", "upazila/p.s.", "permanent upazila"],
      placeholders: ["upazila/p.s.", "উপজেলা", "thana"]
    }
  },
  permanent_post_office: {
    profileKey: "permanent_post_office",
    type: "text",
    patterns: {
      names: ["permanent_post_office", "post_office_permanent", "perm_post_office", "postoffice_perm", "po_permanent", "permanentpostoffice"],
      ids: ["permanent_post_office", "post_office_permanent", "perm_post_office", "po_permanent"],
      labels: ["post office", "ডাকঘর", "p.o.", "permanent post office", "post office name"],
      placeholders: ["post office", "ডাকঘর", "p.o."]
    }
  },
  permanent_post_code: {
    profileKey: "permanent_post_code",
    type: "text",
    patterns: {
      names: ["permanent_post_code", "postal_code_permanent", "perm_post_code", "postcode_perm", "zip_permanent", "permanentpostcode"],
      ids: ["permanent_post_code", "postal_code_permanent", "perm_post_code", "zip_permanent"],
      labels: ["post code", "পোস্ট কোড", "postal code", "zip code", "স্থায়ী পোস্ট কোড"],
      placeholders: ["post code", "postal code", "পোস্ট কোড"]
    }
  },
  permanent_address_bn: {
    profileKey: "permanent_address_bn",
    type: "textarea_text",
    patterns: {
      names: ["permanent_address_bn", "perm_address_bn", "permanent_address_bangla", "address_bn_permanent", "perm_addr_bn"],
      ids: ["permanent_address_bn", "perm_address_bn", "address_bn_permanent"],
      labels: ["স্থায়ী ঠিকানা", "permanent address (bangla)", "permanent address (বাংলায়)", "ঠিকানা (বাংলা)", "স্থায়ী ঠিকানা (বাংলা)"],
      placeholders: ["স্থায়ী ঠিকানা লিখুন", "স্থায়ী ঠিকানা", "ঠিকানা বাংলায়"]
    }
  },
  permanent_address_en: {
    profileKey: "permanent_address_en",
    type: "textarea_text",
    patterns: {
      names: ["permanent_address", "permanent_address_en", "perm_address", "per_address", "permanent_address_english", "perm_addr"],
      ids: ["permanent_address", "permanent_address_en", "perm_address", "per_address"],
      labels: ["permanent address", "permanent address (english)", "স্থায়ী ঠিকানা (ইংরেজি)", "address (english)"],
      placeholders: ["permanent address", "enter permanent address", "permanent address in english"]
    }
  },

  // ─── Education — SSC Level ──────────────────────────────────────────────────
  ssc_examination: {
    profileKey: "ssc_examination",
    type: "select_text",
    patterns: {
      names: ["ssc_exam_name", "ssc_examination", "exam_name", "examination", "sscexamination"],
      ids: ["ssc_exam_name", "ssc_examination", "exam_name"],
      labels: ["examination", "exam name", "পরীক্ষার নাম", "ssc examination", "ssc exam"],
      placeholders: ["select examination", "exam name"]
    }
  },
  ssc_board: {
    profileKey: "ssc_board",
    type: "select_text",
    patterns: {
      names: ["ssc_board", "board", "board_name", "edu_board", "sscboard"],
      ids: ["ssc_board", "board", "board_name"],
      labels: ["board", "বোর্ড", "education board", "ssc board", "শিক্ষা বোর্ড"],
      placeholders: ["select board", "বোর্ড নির্বাচন করুন"]
    }
  },
  ssc_roll: {
    profileKey: "ssc_roll",
    type: "text",
    patterns: {
      names: ["ssc_roll", "roll_no", "roll", "roll_number", "sscroll"],
      ids: ["ssc_roll", "roll_no", "roll"],
      labels: ["roll no", "রোল নম্বর", "roll number", "ssc roll", "রোল নং"],
      placeholders: ["roll number", "রোল নম্বর"]
    }
  },
  ssc_result: {
    profileKey: "ssc_result",
    type: "text",
    patterns: {
      names: ["ssc_gpa", "ssc_result", "gpa", "result", "grade", "sscresult"],
      ids: ["ssc_gpa", "ssc_result", "gpa", "result"],
      labels: ["gpa", "result", "grade", "জিপিএ", "ফলাফল", "ssc result"],
      placeholders: ["gpa", "result", "5.00"]
    }
  },
  ssc_group: {
    profileKey: "ssc_group",
    type: "select_text",
    patterns: {
      names: ["ssc_group", "group", "subject_group", "group_subject", "sscgroup"],
      ids: ["ssc_group", "group", "subject_group"],
      labels: ["group", "গ্রুপ", "subject group", "group/subject", "ssc group"],
      placeholders: ["select group"]
    }
  },
  ssc_passing_year: {
    profileKey: "ssc_passing_year",
    type: "text_select",
    patterns: {
      names: ["ssc_passing_year", "ssc_year", "passing_year", "pass_year", "sscpassingyear"],
      ids: ["ssc_passing_year", "ssc_year", "passing_year"],
      labels: ["passing year", "পাসের সন", "ssc passing year", "পাসের বছর"],
      placeholders: ["passing year", "yyyy"]
    }
  },
  ssc_institution: {
    profileKey: "ssc_institution",
    type: "text",
    patterns: {
      names: ["ssc_institute", "ssc_institution", "institute", "school_name", "sscinstitution"],
      ids: ["ssc_institute", "ssc_institution", "institute"],
      labels: ["institution", "school", "institute name", "প্রতিষ্ঠান", "school name"],
      placeholders: ["institution name", "school name"]
    }
  },

  // ─── Education — HSC Level ──────────────────────────────────────────────────
  hsc_examination: {
    profileKey: "hsc_examination",
    type: "select_text",
    patterns: {
      names: ["hsc_exam_name", "hsc_examination", "exam_name", "examination", "hscexamination"],
      ids: ["hsc_exam_name", "hsc_examination"],
      labels: ["examination", "exam name", "পরীক্ষার নাম", "hsc examination", "hsc exam"],
      placeholders: ["select examination"]
    }
  },
  hsc_board: {
    profileKey: "hsc_board",
    type: "select_text",
    patterns: {
      names: ["hsc_board", "board", "board_name", "hscboard"],
      ids: ["hsc_board", "board", "board_name"],
      labels: ["board", "বোর্ড", "education board", "hsc board", "শিক্ষা বোর্ড"],
      placeholders: ["select board"]
    }
  },
  hsc_roll: {
    profileKey: "hsc_roll",
    type: "text",
    patterns: {
      names: ["hsc_roll", "roll_no", "roll", "roll_number", "hscroll"],
      ids: ["hsc_roll", "roll_no", "roll"],
      labels: ["roll no", "রোল নম্বর", "roll number", "hsc roll", "রোল নং"],
      placeholders: ["roll number"]
    }
  },
  hsc_result: {
    profileKey: "hsc_result",
    type: "text",
    patterns: {
      names: ["hsc_gpa", "hsc_result", "gpa", "result", "grade", "hscresult"],
      ids: ["hsc_gpa", "hsc_result", "gpa", "result"],
      labels: ["gpa", "result", "grade", "জিপিএ", "ফলাফল", "hsc result"],
      placeholders: ["gpa", "result"]
    }
  },
  hsc_group: {
    profileKey: "hsc_group",
    type: "select_text",
    patterns: {
      names: ["hsc_group", "group", "subject_group", "hscgroup"],
      ids: ["hsc_group", "group", "subject_group"],
      labels: ["group", "গ্রুপ", "subject group", "hsc group"],
      placeholders: ["select group"]
    }
  },
  hsc_passing_year: {
    profileKey: "hsc_passing_year",
    type: "text_select",
    patterns: {
      names: ["hsc_passing_year", "hsc_year", "passing_year", "pass_year", "hscpassingyear"],
      ids: ["hsc_passing_year", "hsc_year", "passing_year"],
      labels: ["passing year", "পাসের সন", "hsc passing year", "পাসের বছর"],
      placeholders: ["passing year", "yyyy"]
    }
  },
  hsc_institution: {
    profileKey: "hsc_institution",
    type: "text",
    patterns: {
      names: ["hsc_institute", "hsc_institution", "institute", "college_name", "hscinstitution"],
      ids: ["hsc_institute", "hsc_institution", "institute"],
      labels: ["institution", "college", "institute name", "প্রতিষ্ঠান", "college name"],
      placeholders: ["institution name", "college name"]
    }
  },

  // ─── Education — Honours/Bachelor Level ─────────────────────────────────────
  honours_examination: {
    profileKey: "honours_examination",
    type: "select_text",
    patterns: {
      names: ["honours_exam", "bachelor_exam", "graduation_exam", "examination", "honours_examination"],
      ids: ["honours_exam", "bachelor_exam", "graduation_exam"],
      labels: ["examination", "degree type", "graduation", "honours examination", "graduation examination"],
      placeholders: ["select examination"]
    }
  },
  honours_university: {
    profileKey: "honours_university",
    type: "text",
    patterns: {
      names: ["honours_university", "university", "university_name", "varsity", "honoursuniversity"],
      ids: ["honours_university", "university", "university_name"],
      labels: ["university", "বিশ্ববিদ্যালয়", "university name", "varsity", "honours university"],
      placeholders: ["university name"]
    }
  },
  honours_subject: {
    profileKey: "honours_subject",
    type: "text",
    patterns: {
      names: ["honours_subject", "subject", "degree", "major_subject", "honourssubject"],
      ids: ["honours_subject", "subject", "degree"],
      labels: ["subject", "বিষয়", "degree", "major subject", "subject/degree", "honours subject"],
      placeholders: ["subject name", "degree"]
    }
  },
  honours_result: {
    profileKey: "honours_result",
    type: "text",
    patterns: {
      names: ["honours_cgpa", "honours_result", "cgpa", "result", "grade", "honoursresult"],
      ids: ["honours_cgpa", "honours_result", "cgpa"],
      labels: ["cgpa", "result", "grade", "সিজিপিএ", "ফলাফল", "honours result"],
      placeholders: ["cgpa", "result"]
    }
  },
  honours_passing_year: {
    profileKey: "honours_passing_year",
    type: "text_select",
    patterns: {
      names: ["honours_year", "graduation_year", "passing_year", "pass_year", "honourspassingyear"],
      ids: ["honours_year", "graduation_year", "passing_year"],
      labels: ["passing year", "পাসের সন", "graduation year", "honours passing year"],
      placeholders: ["passing year", "yyyy"]
    }
  },
  honours_duration: {
    profileKey: "honours_duration",
    type: "select_text",
    patterns: {
      names: ["honours_duration", "course_duration", "duration", "honoursduration"],
      ids: ["honours_duration", "course_duration"],
      labels: ["course duration", "কোর্সের মেয়াদ", "duration", "honours duration"],
      placeholders: ["duration"]
    }
  },

  // ─── Education — Masters Level ──────────────────────────────────────────────
  masters_examination: {
    profileKey: "masters_examination",
    type: "select_text",
    patterns: {
      names: ["masters_exam", "master_exam", "post_graduation", "examination", "mastersexamination"],
      ids: ["masters_exam", "master_exam", "post_graduation"],
      labels: ["examination", "degree type", "masters", "post graduation", "masters examination"],
      placeholders: ["select examination"]
    }
  },
  masters_university: {
    profileKey: "masters_university",
    type: "text",
    patterns: {
      names: ["masters_university", "university", "university_name", "mastersuniversity"],
      ids: ["masters_university", "university", "university_name"],
      labels: ["university", "বিশ্ববিদ্যালয়", "university name", "masters university"],
      placeholders: ["university name"]
    }
  },
  masters_subject: {
    profileKey: "masters_subject",
    type: "text",
    patterns: {
      names: ["masters_subject", "subject", "degree", "major_subject", "masterssubject"],
      ids: ["masters_subject", "subject", "degree"],
      labels: ["subject", "বিষয়", "degree", "major subject", "masters subject"],
      placeholders: ["subject name", "degree"]
    }
  },
  masters_result: {
    profileKey: "masters_result",
    type: "text",
    patterns: {
      names: ["masters_cgpa", "masters_result", "cgpa", "result", "grade", "mastersresult"],
      ids: ["masters_cgpa", "masters_result", "cgpa"],
      labels: ["cgpa", "result", "grade", "সিজিপিএ", "ফলাফল", "masters result"],
      placeholders: ["cgpa", "result"]
    }
  },
  masters_passing_year: {
    profileKey: "masters_passing_year",
    type: "text_select",
    patterns: {
      names: ["masters_year", "post_grad_year", "passing_year", "pass_year", "masterspassingyear"],
      ids: ["masters_year", "post_grad_year", "passing_year"],
      labels: ["passing year", "পাসের সন", "masters passing year"],
      placeholders: ["passing year", "yyyy"]
    }
  },
  masters_duration: {
    profileKey: "masters_duration",
    type: "select_text",
    patterns: {
      names: ["masters_duration", "course_duration", "duration", "mastersduration"],
      ids: ["masters_duration", "course_duration"],
      labels: ["course duration", "কোর্সের মেয়াদ", "duration", "masters duration"],
      placeholders: ["duration"]
    }
  },

  // ─── Work Experience ────────────────────────────────────────────────────────
  experience: {
    profileKey: "experience",
    type: "textarea_text",
    patterns: {
      names: ["experience", "work_experience", "job_experience"],
      ids: ["experience", "work_experience"],
      labels: ["experience", "অভিজ্ঞতা", "work experience", "কাজের অভিজ্ঞতা"],
      placeholders: ["experience details", "অভিজ্ঞতা লিখুন"]
    }
  },

  // ─── Quota ──────────────────────────────────────────────────────────────────
  quota: {
    profileKey: "quota",
    type: "select_radio_checkbox",
    patterns: {
      names: ["quota", "quota_id", "freedom_fighter", "ff_quota"],
      ids: ["quota", "quota_id"],
      labels: ["quota", "কোটা", "freedom fighter quota", "মুক্তিযোদ্ধা কোটা"],
      placeholders: ["select quota"]
    },
    optionMap: {
      "none": ["none", "general", "সাধারণ", "0"],
      "freedom_fighter": ["freedom fighter", "মুক্তিযোদ্ধা", "ff", "1"],
      "district": ["district", "জেলা কোটা", "2"],
      "women": ["women", "নারী", "female quota", "3"],
      "tribal": ["tribal", "উপজাতি", "4"],
      "disabled": ["disabled", "প্রতিবন্ধী", "5"]
    }
  },

  // ─── Documents ──────────────────────────────────────────────────────────────
  profile_photo: {
    profileKey: "profilePhoto",
    type: "file_image",
    patterns: {
      names: ["photo", "image", "picture", "profile_photo", "profile_picture", "applicant_photo", "passport_photo"],
      ids: ["photo", "image", "picture", "profile_photo", "applicant_photo"],
      labels: ["photo", "ছবি", "image", "picture", "profile photo", "applicant photo", "পাসপোর্ট সাইজ ছবি", "আবেদনকারীর ছবি"],
      types: ["file"],
      accepts: ["image/*", ".jpg", ".jpeg", ".png", ".gif", ".webp"]
    }
  },
  signature: {
    profileKey: "signature",
    type: "file_image",
    patterns: {
      names: ["signature", "sign", "applicant_signature", "signature_image"],
      ids: ["signature", "sign", "applicant_signature"],
      labels: ["signature", "স্বাক্ষর", "sign", "applicant signature", "আবেদনকারীর স্বাক্ষর"],
      types: ["file"],
      accepts: ["image/*", ".jpg", ".jpeg", ".png", ".gif", ".webp"]
    }
  }
};

const SITE_CONFIGS = {
  "dnc.teletalk.com.bd": {
    siteId: "dnc",
    label: "DNC Teletalk",
    extraPatterns: {
      applicant_name_en: { names: ["ApplicantName", "applicant_name"] },
      mobile: { names: ["MobileNo", "mobile_no"] }
    }
  },
  "ejobs.teletalk.com.bd": {
    siteId: "ejobs",
    label: "eJobs Teletalk",
    extraPatterns: {}
  },
  "alljobs.teletalk.com.bd": {
    siteId: "alljobs",
    label: "AllJobs Teletalk",
    extraPatterns: {}
  }
};

if (typeof module !== "undefined") {
  module.exports = { FIELD_MAP, SITE_CONFIGS };
}

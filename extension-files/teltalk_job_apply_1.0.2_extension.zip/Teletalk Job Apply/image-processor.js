/**
 * image-processor.js-Teletalk Job Apply-Modified by Mahabur Hossain-01781040050
 * Image processing utilities for document uploads.
 * Handles resizing, cropping, dimension validation, and recursive compression
 * to satisfy strict Teletalk file size limits (Photo: <100KB, Signature: <60KB).
 */

const ImageProcessor = {
  /**
   * Resize and compress a canvas to JPEG, ensuring it fits under a strict byte size limit.
   * Runs recursive compression quality adjustments if the file size is too large.
   * @param {HTMLCanvasElement} canvas - The source canvas containing the image
   * @param {number} maxBytes - Maximum allowed size in bytes (e.g. 100 * 1024)
   * @param {number} initialQuality - Initial JPEG compression quality (0.1 to 1.0)
   * @returns {Promise<string>} Base64 JPEG data URL
   */
  async compressToTargetLimit(canvas, maxBytes, initialQuality = 0.9) {
    return new Promise((resolve) => {
      let quality = initialQuality;
      let dataURL = canvas.toDataURL("image/jpeg", quality);
      
      // Approximate bytes from base64 length
      const getApproxBytes = (str) => {
        const base64Content = str.split(",")[1] || "";
        return Math.round(base64Content.length * 0.75);
      };

      let currentBytes = getApproxBytes(dataURL);
      
      // Step-down quality iteratively if file is too large
      while (currentBytes > maxBytes && quality > 0.1) {
        quality -= 0.05;
        dataURL = canvas.toDataURL("image/jpeg", quality);
        currentBytes = getApproxBytes(dataURL);
      }
      
      resolve(dataURL);
    });
  },

  /**
   * Process a file and crop/resize it to strict dimensions and size limits.
   * This is used as a fallback if visual cropper is bypassed.
   * @param {File} file - Source file
   * @param {number} targetWidth - e.g. 300
   * @param {number} targetHeight - e.g. 300
   * @param {number} maxBytes - e.g. 100 * 1024
   * @returns {Promise<string>} Base64 encoded JPEG
   */
  async processImageDirectly(file, targetWidth, targetHeight, maxBytes) {
    return new Promise((resolve, reject) => {
      if (!file.type.startsWith("image/")) {
        reject(new Error("Unsupported file type. Please upload a valid image file."));
        return;
      }

      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = async () => {
          try {
            const canvas = document.createElement("canvas");
            const ctx = canvas.getContext("2d");

            canvas.width = targetWidth;
            canvas.height = targetHeight;

            // Fill canvas with white background (useful for transparent PNGs)
            ctx.fillStyle = "#ffffff";
            ctx.fillRect(0, 0, targetWidth, targetHeight);

            // Draw image covering the entire target canvas (aspect-fill crop style)
            const scale = Math.max(targetWidth / img.width, targetHeight / img.height);
            const w = img.width * scale;
            const h = img.height * scale;
            const x = (targetWidth - w) / 2;
            const y = (targetHeight - h) / 2;

            ctx.drawImage(img, x, y, w, h);

            // Compress to target limit
            const resultURL = await this.compressToTargetLimit(canvas, maxBytes);
            resolve(resultURL);
          } catch (err) {
            reject(new Error("Failed to process image: " + err.message));
          }
        };
        img.onerror = () => reject(new Error("Failed to load image contents."));
        img.src = e.target.result;
      };
      reader.onerror = () => reject(new Error("Failed to read image file."));
      reader.readAsDataURL(file);
    });
  },

  /**
   * Validate image dimensions
   */
  async getImageInfo(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => resolve({ width: img.width, height: img.height, size: file.size });
        img.onerror = () => reject(new Error("Invalid image file."));
        img.src = e.target.result;
      };
      reader.onerror = () => reject(new Error("Failed to read image."));
      reader.readAsDataURL(file);
    });
  },

  /**
   * Convert base64 data URL to a File object
   */
  dataURLToFile(dataURL, filename) {
    const arr = dataURL.split(",");
    const mime = arr[0].match(/:(.*?);/)[1];
    const bstr = atob(arr[1]);
    let n = bstr.length;
    const u8arr = new Uint8Array(n);
    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }
    return new File([u8arr], filename, { type: mime });
  },

  /**
   * Create a Blob URL from dataURL
   */
  createBlobURL(dataURL) {
    const arr = dataURL.split(",");
    const mime = arr[0].match(/:(.*?);/)[1];
    const bstr = atob(arr[1]);
    let n = bstr.length;
    const u8arr = new Uint8Array(n);
    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }
    const blob = new Blob([u8arr], { type: mime });
    return URL.createObjectURL(blob);
  }
};

if (typeof module !== "undefined") {
  module.exports = ImageProcessor;
}
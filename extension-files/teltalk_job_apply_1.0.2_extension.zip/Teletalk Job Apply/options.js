/**
 * options.js — Teletalk Job Apply-Modified by Mahabur Hossain-01781040050/ Profile Dashboard
 * Controls profile creation, tab layouts, storage updates, address copying,
 * and the visual canvas-based image crop/resize engine.
 */

document.addEventListener("DOMContentLoaded", () => {
  // ─── State variables ────────────────────────────────────────────────────────
  let profiles = [];
  let settings = {};
  let activeId = null;

  // Visual Cropper State
  let cropperState = {
    img: null,
    scale: 1,
    offsetX: 0,
    offsetY: 0,
    isDragging: false,
    dragStart: { x: 0, y: 0 },
    targetW: 300,
    targetH: 300,
    maxBytes: 100 * 1024, // 100KB for photo, 60KB for signature
    fieldKey: "",
    previewContainer: null,
    imageElement: null,
    removeBtn: null
  };

  // ─── DOM Elements ───────────────────────────────────────────────────────────
  const profileList = document.getElementById("profile-list");
  const profileEditor = document.getElementById("profile-editor");
  const noProfileMsg = document.getElementById("no-profile-msg");
  const profileNameInput = document.getElementById("profile-name-input");
  const saveStatus = document.getElementById("save-status");
  const toggleFab = document.getElementById("toggle-fab");
  const toggleEnc = document.getElementById("toggle-enc");
  const encPasswordRow = document.getElementById("enc-password-row");
  const encPassword = document.getElementById("enc-password");
  const btnSavePassword = document.getElementById("btn-save-password");

  const btnNewProfile = document.getElementById("btn-new-profile");
  const btnNewProfile2 = document.getElementById("btn-new-profile-2");
  const btnSave = document.getElementById("btn-save");
  const btnDelete = document.getElementById("btn-delete");
  const btnImport = document.getElementById("btn-import");
  const btnExport = document.getElementById("btn-export");
  const importFile = document.getElementById("import-file");

  // Tab buttons and panes
  const tabButtons = document.querySelectorAll(".tab-button");
  const tabPanes = document.querySelectorAll(".tab-pane-content");

  // Address copy helper
  const btnCopyToPermanent = document.getElementById("copy-to-permanent");

  // Media Document widgets
  const photoUpload = document.getElementById("photo-upload");
  const photoUploadBtn = document.getElementById("photo-upload-btn");
  const photoRemoveBtn = document.getElementById("photo-remove-btn");
  const photoPreview = document.getElementById("photo-preview");
  const photoImg = document.getElementById("photo-img");

  const signatureUpload = document.getElementById("signature-upload");
  const signatureUploadBtn = document.getElementById("signature-upload-btn");
  const signatureRemoveBtn = document.getElementById("signature-remove-btn");
  const signaturePreview = document.getElementById("signature-preview");
  const signatureImg = document.getElementById("signature-img");

  // Cropper Modal Elements
  const cropperModal = document.getElementById("cropper-modal");
  const cropperTitle = document.getElementById("cropper-title");
  const cropCanvas = document.getElementById("crop-canvas");
  const zoomSlider = document.getElementById("zoom-slider");
  const btnCloseCropper = document.getElementById("btn-close-cropper");
  const btnCancelCrop = document.getElementById("btn-cancel-crop");
  const btnConfirmCrop = document.getElementById("btn-confirm-crop");

  const ctx = cropCanvas.getContext("2d");

  // ─── Setup Startup State ────────────────────────────────────────────────────
  chrome.storage.local.get(["profiles", "settings", "optionsAction"], (data) => {
    profiles = data.profiles || [];
    settings = data.settings || {};

    toggleFab.checked = settings.showFloatingBtn !== false;
    toggleEnc.checked = settings.encryptionEnabled === true;
    if (settings.encryptionEnabled) {
      encPasswordRow.classList.remove("hidden");
    }

    renderProfileList();

    // Select active profile or default first
    const startupId = settings.activeProfileId || (profiles[0]?.id);
    if (startupId) {
      selectProfile(startupId);
    } else {
      showEmptyState();
    }

    // Trigger action from popup "New Profile" click
    if (data.optionsAction === "new_profile") {
      chrome.storage.local.remove("optionsAction");
      createNewProfile();
    }
  });

  // ─── Profile Navigation / Render ────────────────────────────────────────────
  function renderProfileList() {
    profileList.innerHTML = "";
    if (profiles.length === 0) {
      profileList.innerHTML = `<li class="profile-list-empty">No applicant profiles saved</li>`;
      return;
    }

    profiles.forEach((p) => {
      const li = document.createElement("li");
      li.className = "profile-item" + (p.id === activeId ? " active" : "");
      li.dataset.id = p.id;

      const lockIcon = p._enc ? '<span class="lock-icon" title="Encrypted Profile">🔒</span>' : "";
      
      li.innerHTML = `
        <div class="profile-icon">
        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M20 21C20 17.6863 17.3137 15 14 15H10C6.68629 15 4 17.6863 4 21"
                  stroke="currentColor"
                  stroke-width="2"
                  stroke-linecap="round"/>
            <circle cx="12" cy="7" r="4"
                    stroke="currentColor"
                    stroke-width="2"/>
        </svg>
        </div>
        <div class="profile-meta">
          <div class="profile-title-row">
            <span class="p-name">${escapeHtml(p.profileName || p.applicant_name_en || "Unnamed Profile")}</span>
            ${lockIcon}
          </div>
          <span class="p-subtitle">${escapeHtml(p.mobile || p.email || "No contact info")}</span>
        </div>
      `;

      li.addEventListener("click", () => selectProfile(p.id));
      profileList.appendChild(li);
    });
  }

  async function selectProfile(id) {
    const p = profiles.find((p) => p.id === id);
    if (!p) return;

    let profileToLoad = p;

    // Prompt for password if encrypted
    if (p._enc) {
      const decrypted = await decryptProfileWithPrompt(p);
      if (!decrypted) {
        // Decrypt cancelled, keep selection list highlighted at old active ID
        renderProfileList();
        return;
      }
      profileToLoad = decrypted;
    }

    activeId = id;

    // Update active highlight in list
    document.querySelectorAll(".profile-item").forEach((li) => {
      li.classList.toggle("active", li.dataset.id === id);
    });

    // Save active ID to settings
    settings.activeProfileId = id;
    chrome.storage.local.set({ settings });

    loadProfileIntoForm(profileToLoad);
    showEditorWorkspace();
  }

  async function decryptProfileWithPrompt(p) {
    if (!p._enc) return p;

    // Try utilizing entered password if available
    let password = encPassword.value.trim();
    if (password) {
      try {
        const decrypted = await Encryption.decrypt(p._enc, password);
        return { ...decrypted, id: p.id, profileName: p.profileName };
      } catch (e) {
        console.warn("Stored key decryption failed, asking user.");
      }
    }

    password = prompt(`Profile "${p.profileName || "Unnamed"}" is encrypted. Enter password to unlock:`);
    if (password === null) return null; // Cancelled
    if (!password.trim()) {
      alert("Password cannot be empty.");
      return null;
    }

    try {
      const decrypted = await Encryption.decrypt(p._enc, password.trim());
      encPassword.value = password.trim(); // Store in cached input box
      toggleEnc.checked = true;
      encPasswordRow.classList.remove("hidden");
      return { ...decrypted, id: p.id, profileName: p.profileName };
    } catch (e) {
      alert("Incorrect password. Decryption failed.");
      return null;
    }
  }

  function loadProfileIntoForm(p) {
    profileNameInput.value = p.profileName || "";

    // Fill all form elements with matching data-field keys
    document.querySelectorAll("[data-field]").forEach((el) => {
      const key = el.dataset.field;
      const val = p[key] !== undefined && p[key] !== null ? String(p[key]) : "";
      const tag = el.tagName.toLowerCase();

      if (tag === "select") {
        // Try to match by option value first
        let matched = false;
        for (const opt of el.options) {
          if (opt.value === val || opt.value.toLowerCase() === val.toLowerCase()) {
            el.value = opt.value;
            matched = true;
            break;
          }
        }
        // If no exact match, try partial text match
        if (!matched && val) {
          for (const opt of el.options) {
            if (opt.text.toLowerCase().includes(val.toLowerCase()) || 
                val.toLowerCase().includes(opt.text.toLowerCase().trim())) {
              el.value = opt.value;
              break;
            }
          }
        }
        if (!matched && !val) {
          el.selectedIndex = 0; // Reset to default
        }
      } else if (tag === "textarea") {
        el.value = val;
        // Also set textContent for textareas to be safe
        el.textContent = val;
      } else {
        el.value = val;
      }
    });

    // Load education tab toggles
    setupEducationToggles(p);

    // Load media files
    loadMediaImages(p);

    saveStatus.classList.add("hidden");
  }

  function showEditorWorkspace() {
    noProfileMsg.classList.add("hidden");
    profileEditor.classList.remove("hidden");
  }

  function showEmptyState() {
    noProfileMsg.classList.remove("hidden");
    profileEditor.classList.add("hidden");
    activeId = null;
    document.querySelectorAll(".profile-item").forEach(li => li.classList.remove("active"));
  }

  // ─── Profile Creation / Deletion ────────────────────────────────────────────
  function createNewProfile() {
    const newId = "profile_" + Date.now();
    const newProfile = {
      id: newId,
      profileName: "New Profile " + (profiles.length + 1),
      applicant_name_en: "",
      mobile: "",
      email: ""
    };

    profiles.push(newProfile);
    activeId = newId;

    chrome.storage.local.set({ profiles }, () => {
      renderProfileList();
      selectProfile(newId);
      profileNameInput.focus();
      profileNameInput.select();
    });
  }

  btnNewProfile.addEventListener("click", createNewProfile);
  btnNewProfile2.addEventListener("click", createNewProfile);

  btnSave.addEventListener("click", async () => {
    if (!activeId) return;

    // Construct profile object
    const profileName = profileNameInput.value.trim() || "Unnamed Profile";
    const profileData = {
      id: activeId,
      profileName
    };

    // Read standard fields from all data-field elements
    document.querySelectorAll("[data-field]").forEach((el) => {
      const key = el.dataset.field;
      const tag = el.tagName.toLowerCase();
      
      if (tag === "select") {
        profileData[key] = el.value || "";
      } else if (tag === "textarea") {
        profileData[key] = el.value || "";
      } else {
        // For text/email/tel/date inputs, trim whitespace
        profileData[key] = (el.value || "").trim();
      }
    });

    // Handle enabled education tags
    ["ssc", "hsc", "honours", "masters"].forEach((level) => {
      const isEnabled = document.getElementById(`${level}-enabled`).checked;
      profileData[`${level}_enabled`] = isEnabled;
    });

    // Read photo/signature base64 URLs directly from DOM preview elements
    // Only save if the img element is visible AND has a valid base64 data URL
    const photoSrc = photoImg.src || "";
    const sigSrc = signatureImg.src || "";
    profileData.profilePhoto = (!photoImg.classList.contains("hidden") && photoSrc.startsWith("data:image/")) ? photoSrc : "";
    profileData.signature = (!signatureImg.classList.contains("hidden") && sigSrc.startsWith("data:image/")) ? sigSrc : "";

    let savePayload = profileData;

    // Handle AES Encryption setting
    if (toggleEnc.checked) {
      const password = encPassword.value.trim();
      if (!password) {
        alert("Please set an encryption key password in the sidebar configurations first.");
        return;
      }
      try {
        const cipher = await Encryption.encrypt(profileData, password);
        savePayload = {
          id: activeId,
          profileName,
          _enc: cipher
        };
      } catch (err) {
        alert("Failed to encrypt profile data: " + err.message);
        return;
      }
    }

    // Save profile into local memory array
    const idx = profiles.findIndex((p) => p.id === activeId);
    if (idx >= 0) {
      profiles[idx] = savePayload;
    } else {
      profiles.push(savePayload);
    }

    chrome.storage.local.set({ profiles }, () => {
      renderProfileList();
      // Keep selection active
      document.querySelectorAll(".profile-item").forEach((li) => {
        li.classList.toggle("active", li.dataset.id === activeId);
      });
      displayStatusBanner("✓ Profile changes saved successfully!", "success");
    });
  });

  btnDelete.addEventListener("click", () => {
    if (!activeId) return;
    const p = profiles.find((p) => p.id === activeId);
    const confirmName = p ? (p.profileName || "this profile") : "this profile";

    if (confirm(`Are you sure you want to delete "${confirmName}"? This action cannot be undone.`)) {
      profiles = profiles.filter((p) => p.id !== activeId);
      
      chrome.storage.local.get("settings", (data) => {
        const settings = data.settings || {};
        if (settings.activeProfileId === activeId) {
          settings.activeProfileId = profiles[0]?.id || null;
        }
        chrome.storage.local.set({ profiles, settings }, () => {
          renderProfileList();
          if (settings.activeProfileId) {
            selectProfile(settings.activeProfileId);
          } else {
            showEmptyState();
          }
          displayStatusBanner("Profile deleted.", "warn");
        });
      });
    }
  });

  // ─── Education Toggles Handler ──────────────────────────────────────────────
  function setupEducationToggles(profile) {
    ["ssc", "hsc", "honours", "masters"].forEach((level) => {
      const toggle = document.getElementById(`${level}-enabled`);
      const container = document.getElementById(`${level}-fields`);
      const card = document.getElementById(`${level}-card-group`);

      // Check if profile property is set or check fields dynamically
      const isEnabled = profile[`${level}_enabled`] === true || checkLevelHasData(profile, level);
      
      toggle.checked = isEnabled;
      if (isEnabled) {
        container.classList.remove("hidden");
        card.classList.remove("disabled");
      } else {
        container.classList.add("hidden");
        card.classList.add("disabled");
      }

      // Handle checkbox change
      toggle.onchange = () => {
        if (toggle.checked) {
          container.classList.remove("hidden");
          card.classList.remove("disabled");
        } else {
          container.classList.add("hidden");
          card.classList.add("disabled");
          // Clear inputs on disable to avoid accidental submissions
          container.querySelectorAll("[data-field]").forEach(input => input.value = "");
        }
      };
    });
  }

  function checkLevelHasData(profile, level) {
    // Returns true if any field starting with level prefix has a value
    const keys = Object.keys(profile).filter(k => k.startsWith(`${level}_`));
    return keys.some(k => profile[k] !== undefined && profile[k] !== "");
  }

  // ─── Address copying ────────────────────────────────────────────────────────
  btnCopyToPermanent.addEventListener("click", () => {
    const fields = [
      "care_of",
      "village_town",
      "house_flat",
      "district",
      "upazila",
      "post_office",
      "post_code",
      "address_en",
      "address_bn"
    ];

    fields.forEach((f) => {
      const source = document.querySelector(`[data-field="present_${f}"]`);
      const target = document.querySelector(`[data-field="permanent_${f}"]`);
      if (source && target) {
        target.value = source.value;
      }
    });

    displayStatusBanner("✓ Copied Present address fields to Permanent Address fields.", "success");
  });

  // ─── Global Configurations Sync ─────────────────────────────────────────────
  toggleFab.addEventListener("change", () => {
    settings.showFloatingBtn = toggleFab.checked;
    chrome.storage.local.set({ settings });
  });

  toggleEnc.addEventListener("change", () => {
    if (toggleEnc.checked) {
      encPasswordRow.classList.remove("hidden");
      encPassword.focus();
    } else {
      encPasswordRow.classList.add("hidden");
      encPassword.value = "";
      settings.encryptionEnabled = false;
      chrome.storage.local.set({ settings });
      alert("Encryption disabled. Profiles will be decrypted and saved in plaintext next time you save.");
    }
  });

  btnSavePassword.addEventListener("click", () => {
    const pass = encPassword.value.trim();
    if (!pass) {
      alert("Password cannot be empty.");
      return;
    }
    settings.encryptionEnabled = true;
    chrome.storage.local.set({ settings }, () => {
      alert("Encryption password key successfully updated locally!");
    });
  });

  // ─── Tab Switch controls ────────────────────────────────────────────────────
  tabButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      tabButtons.forEach((b) => b.classList.remove("active"));
      tabPanes.forEach((p) => p.classList.remove("active"));

      btn.classList.add("active");
      const tabId = "tab-" + btn.dataset.tab;
      document.getElementById(tabId).classList.add("active");
    });
  });

  // ─── Load Media / Images Previews ───────────────────────────────────────────
  function loadMediaImages(p) {
    if (p.profilePhoto) {
      photoImg.src = p.profilePhoto;
      photoImg.classList.remove("hidden");
      photoPreview.querySelector(".upload-icon-placeholder").classList.add("hidden");
      photoRemoveBtn.classList.remove("hidden");
    } else {
      clearImgWidget(photoImg, photoPreview, photoRemoveBtn);
    }

    if (p.signature) {
      signatureImg.src = p.signature;
      signatureImg.classList.remove("hidden");
      signaturePreview.querySelector(".upload-icon-placeholder").classList.add("hidden");
      signatureRemoveBtn.classList.remove("hidden");
    } else {
      clearImgWidget(signatureImg, signaturePreview, signatureRemoveBtn);
    }
  }

  function clearImgWidget(imgEl, previewBox, removeBtn) {
    imgEl.src = "";
    imgEl.classList.add("hidden");
    previewBox.querySelector(".upload-icon-placeholder").classList.remove("hidden");
    removeBtn.classList.add("hidden");
  }

  // ─── Visual Cropper Engine Implementation ───────────────────────────────────
  function initCropperWidget(file, type) {
    const isPhoto = type === "photo";
    cropperState.fieldKey = isPhoto ? "profilePhoto" : "signature";
    cropperState.targetW = 300;
    cropperState.targetH = isPhoto ? 300 : 80;
    cropperState.maxBytes = isPhoto ? 100 * 1024 : 60 * 1024;
    cropperState.previewContainer = isPhoto ? photoPreview : signaturePreview;
    cropperState.imageElement = isPhoto ? photoImg : signatureImg;
    cropperState.removeBtn = isPhoto ? photoRemoveBtn : signatureRemoveBtn;

    cropperTitle.textContent = isPhoto ? "Crop Profile Photo (300×300)" : "Crop Signature (300×80)";

    // Read file and bind to image
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        cropperState.img = img;
        // Default cropper setups
        cropperState.scale = Math.max(cropCanvas.width / img.width, cropCanvas.height / img.height);
        cropperState.offsetX = 0;
        cropperState.offsetY = 0;

        zoomSlider.value = cropperState.scale;
        zoomSlider.min = cropperState.scale * 0.5;
        zoomSlider.max = cropperState.scale * 4;

        cropperModal.classList.remove("hidden");
        drawCropper();
      };
      img.src = e.target.result;
    };
    reader.readAsDataURL(file);
  }

  function drawCropper() {
    if (!cropperState.img) return;

    ctx.clearRect(0, 0, cropCanvas.width, cropCanvas.height);

    const canvasW = cropCanvas.width;
    const canvasH = cropCanvas.height;
    const img = cropperState.img;
    const scale = parseFloat(zoomSlider.value);
    
    // Width and height of scaled image
    const imgW = img.width * scale;
    const imgH = img.height * scale;

    // Center position
    const cx = canvasW / 2 + cropperState.offsetX;
    const cy = canvasH / 2 + cropperState.offsetY;

    // Draw image content
    ctx.drawImage(img, cx - imgW / 2, cy - imgH / 2, imgW, imgH);

    // Draw dark mask with transparent bounding crop frame
    ctx.fillStyle = "rgba(0, 0, 0, 0.55)";
    
    const cropW = cropperState.targetW;
    const cropH = cropperState.targetH;
    const rx = (canvasW - cropW) / 2;
    const ry = (canvasH - cropH) / 2;

    // Overlay pathing
    ctx.beginPath();
    ctx.rect(0, 0, canvasW, canvasH); // outer
    ctx.rect(rx, ry, cropW, cropH); // inner window
    ctx.closePath();
    ctx.fill("evenodd");

    // Draw crop boundary border
    ctx.strokeStyle = "#00b074";
    ctx.lineWidth = 2;
    ctx.strokeRect(rx, ry, cropW, cropH);
  }

  // Bind mouse / touch drag events on Crop Canvas
  cropCanvas.addEventListener("mousedown", (e) => {
    cropperState.isDragging = true;
    cropperState.dragStart = { x: e.clientX, y: e.clientY };
  });

  window.addEventListener("mousemove", (e) => {
    if (!cropperState.isDragging || !cropperState.img) return;
    const dx = e.clientX - cropperState.dragStart.x;
    const dy = e.clientY - cropperState.dragStart.y;
    cropperState.offsetX += dx;
    cropperState.offsetY += dy;
    cropperState.dragStart = { x: e.clientX, y: e.clientY };
    drawCropper();
  });

  window.addEventListener("mouseup", () => {
    cropperState.isDragging = false;
  });

  zoomSlider.addEventListener("input", drawCropper);

  // Close modals
  const closeModal = () => {
    cropperModal.classList.add("hidden");
    cropperState.img = null;
    photoUpload.value = "";
    signatureUpload.value = "";
  };

  btnCloseCropper.addEventListener("click", closeModal);
  btnCancelCrop.addEventListener("click", closeModal);

  btnConfirmCrop.addEventListener("click", async () => {
    if (!cropperState.img) return;

    // Create a hidden canvas for precise crop extraction at target dimensions
    const exportCanvas = document.createElement("canvas");
    exportCanvas.width = cropperState.targetW;
    exportCanvas.height = cropperState.targetH;
    const exportCtx = exportCanvas.getContext("2d");

    const scale = parseFloat(zoomSlider.value);
    const img = cropperState.img;

    // Position of image in center coordinates
    const canvasCenterX = cropCanvas.width / 2;
    const canvasCenterY = cropCanvas.height / 2;

    const imgCenterX = canvasCenterX + cropperState.offsetX;
    const imgCenterY = canvasCenterY + cropperState.offsetY;

    // Crop box coordinates in Canvas scope
    const cropBoxX = (cropCanvas.width - cropperState.targetW) / 2;
    const cropBoxY = (cropCanvas.height - cropperState.targetH) / 2;

    // Translate crop box back to image coordinate space
    const sourceX = (cropBoxX - (imgCenterX - (img.width * scale) / 2)) / scale;
    const sourceY = (cropBoxY - (imgCenterY - (img.height * scale) / 2)) / scale;
    
    const sourceW = cropperState.targetW / scale;
    const sourceH = cropperState.targetH / scale;

    exportCtx.fillStyle = "#ffffff";
    exportCtx.fillRect(0, 0, cropperState.targetW, cropperState.targetH);

    exportCtx.drawImage(
      img,
      sourceX,
      sourceY,
      sourceW,
      sourceH,
      0,
      0,
      cropperState.targetW,
      cropperState.targetH
    );

    // Dynamic recursive quality compressor limit check
    const compressedUrl = await ImageProcessor.compressToTargetLimit(
      exportCanvas,
      cropperState.maxBytes
    );

    // Render Preview
    cropperState.imageElement.src = compressedUrl;
    cropperState.imageElement.classList.remove("hidden");
    cropperState.previewContainer.querySelector(".upload-icon-placeholder").classList.add("hidden");
    cropperState.removeBtn.classList.remove("hidden");

    closeModal();
  });

  // Setup Visual Canvas sizes
  cropCanvas.width = 500;
  cropCanvas.height = 400;

  // ─── Setup Upload Event Handlers ────────────────────────────────────────────
  [
    { trigger: photoUploadBtn, fileEl: photoUpload, previewBox: photoPreview },
    { trigger: signatureUploadBtn, fileEl: signatureUpload, previewBox: signaturePreview }
  ].forEach((item) => {
    item.trigger.addEventListener("click", () => item.fileEl.click());
    item.previewBox.addEventListener("click", (e) => {
      // Prevent double trigger when buttons inside preview are clicked
      if (e.target.tagName !== "BUTTON" && e.target.parentElement.tagName !== "BUTTON") {
        item.fileEl.click();
      }
    });

    item.fileEl.addEventListener("change", (e) => {
      const file = e.target.files[0];
      if (file) {
        const type = item.fileEl === photoUpload ? "photo" : "signature";
        initCropperWidget(file, type);
      }
    });
  });

  photoRemoveBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    if (confirm("Remove applicant photo?")) {
      clearImgWidget(photoImg, photoPreview, photoRemoveBtn);
    }
  });

  signatureRemoveBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    if (confirm("Remove applicant signature?")) {
      clearImgWidget(signatureImg, signaturePreview, signatureRemoveBtn);
    }
  });

  // ─── Import / Export Configurations ─────────────────────────────────────────
  btnExport.addEventListener("click", () => {
    if (profiles.length === 0) {
      alert("No profiles to export.");
      return;
    }
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(profiles));
    const dlAnchor = document.createElement("a");
    dlAnchor.setAttribute("href", dataStr);
    dlAnchor.setAttribute("download", `teletalk_job_apply_profiles_${Date.now()}.json`);
    document.body.appendChild(dlAnchor);
    dlAnchor.click();
    dlAnchor.remove();
  });

  btnImport.addEventListener("click", () => importFile.click());

  importFile.addEventListener("change", (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const imported = JSON.parse(evt.target.result);
        if (!Array.isArray(imported)) {
          alert("Invalid import format. JSON file must contain a profiles list.");
          return;
        }

        // Validate basic properties
        const cleaned = imported.filter((p) => p && typeof p === "object" && (p.profileName || p.applicant_name_en));
        if (cleaned.length === 0) {
          alert("No valid profiles found inside imported JSON.");
          return;
        }

        if (confirm(`Import ${cleaned.length} profiles? This will merge with your current profiles list.`)) {
          // Verify unique IDs
          cleaned.forEach((p) => {
            if (!p.id || profiles.some((existing) => existing.id === p.id)) {
              p.id = "profile_" + Date.now() + "_" + Math.floor(Math.random() * 1000);
            }
            profiles.push(p);
          });

          chrome.storage.local.set({ profiles }, () => {
            renderProfileList();
            alert(`Successfully imported ${cleaned.length} profiles!`);
            if (profiles[0]) {
              selectProfile(profiles[profiles.length - 1].id);
            }
          });
        }
      } catch (err) {
        alert("Failed to parse JSON file: " + err.message);
      }
      importFile.value = "";
    };
    reader.readAsText(file);
  });

  // ─── Notification banner helper ─────────────────────────────────────────────
  function displayStatusBanner(text, type = "success") {
    saveStatus.textContent = text;
    saveStatus.className = `save-status-banner banner-${type}`;
    saveStatus.classList.remove("hidden");
    
    setTimeout(() => {
      saveStatus.classList.add("hidden");
    }, 4000);
  }

  function escapeHtml(str) {
    if (!str) return "";
    return str
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }
});

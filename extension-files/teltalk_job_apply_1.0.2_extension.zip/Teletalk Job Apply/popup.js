/**
 * popup.js — Teletalk Job Apply-Modified by Mahabur Hossain-01781040050
 */

document.addEventListener("DOMContentLoaded", () => {
  const profileSelect = document.getElementById("profile-select");
  const btnAutofill = document.getElementById("btn-autofill");
  const btnClear = document.getElementById("btn-clear");
  const statusMsg = document.getElementById("status-msg");
  const profilePreview = document.getElementById("profile-preview");
  const previewBadges = document.getElementById("preview-badges");
  const btnOpenOptions = document.getElementById("btn-open-options");
  const btnNewProfile = document.getElementById("btn-new-profile");
  const btnManage = document.getElementById("btn-manage");

  let profiles = [];
  let settings = {};

  // ─── Load Profiles and Active Settings ──────────────────────────────────────
  function initPopup() {
    chrome.runtime.sendMessage({ action: "GET_PROFILES" }, (res) => {
      if (chrome.runtime.lastError) {
        console.warn("Teletalk Job Apply Message Error:", chrome.runtime.lastError.message);
        return;
      }
      profiles = res.profiles || [];
      settings = res.settings || {};
      renderProfiles();
    });
  }

  function renderProfiles() {
    profileSelect.innerHTML = '<option value="">-- Choose Profile --</option>';
    
    if (profiles.length === 0) {
      profilePreview.classList.add("hidden");
      return;
    }

    profiles.forEach((p) => {
      const opt = document.createElement("option");
      opt.value = p.id;
      const prefix = p._enc ? "🔐 " : "👨‍💼 ";
      opt.textContent = prefix + (p.profileName || p.applicant_name_en || "Unnamed Profile");
      
      if (p.id === settings.activeProfileId) {
        opt.selected = true;
      }
      profileSelect.appendChild(opt);
    });

    updatePreview();
  }

  function updatePreview() {
    const selId = profileSelect.value;
    const p = profiles.find((p) => p.id === selId);
    
    if (!p) {
      profilePreview.classList.add("hidden");
      return;
    }
    
    profilePreview.classList.remove("hidden");
    previewBadges.innerHTML = "";

    if (p._enc) {
      document.getElementById("prev-name-en").textContent = "[🔐 Encrypted]";
      document.getElementById("prev-name-bn").textContent = "[🔐 Encrypted]";
      document.getElementById("prev-mobile").textContent = "[🔐 Encrypted]";
      document.getElementById("prev-email").textContent = "[🔐 Encrypted]";
      
      const badge = document.createElement("span");
      badge.className = "preview-badge badge-locked";
      badge.textContent = "🔐 Encrypted Profile";
      previewBadges.appendChild(badge);
    } else {
      document.getElementById("prev-name-en").textContent = p.applicant_name_en || "—";
      document.getElementById("prev-name-bn").textContent = p.applicant_name_bn || "—";
      document.getElementById("prev-mobile").textContent = p.mobile || "—";
      document.getElementById("prev-email").textContent = p.email || "—";

      if (p.profilePhoto) {
        const badge = document.createElement("span");
        badge.className = "preview-badge badge-photo";
        badge.innerHTML = "📷 Photo Added";
        previewBadges.appendChild(badge);
      }
      if (p.signature) {
        const badge = document.createElement("span");
        badge.className = "preview-badge badge-signature";
        badge.innerHTML = "✍️ Signature Added";
        previewBadges.appendChild(badge);
      }
      if (!p.profilePhoto && !p.signature) {
        const badge = document.createElement("span");
        badge.className = "preview-badge badge-warn";
        badge.innerHTML = "⚠ No Media Attached";
        previewBadges.appendChild(badge);
      }
    }
  }

  // ─── Dropdown Event Listener ────────────────────────────────────────────────
  profileSelect.addEventListener("change", () => {
    chrome.runtime.sendMessage({
      action: "SET_ACTIVE_PROFILE",
      profileId: profileSelect.value
    }, () => {
      updatePreview();
    });
  });

  // ─── Autofill Trigger ───────────────────────────────────────────────────────
  btnAutofill.addEventListener("click", () => {
    const profileId = profileSelect.value;
    if (!profileId) {
      showStatus("⚠ Select an applicant profile first.", "warn");
      return;
    }

    btnAutofill.disabled = true;
    showStatus("Filling form fields...", "ok");

    chrome.runtime.sendMessage({ action: "AUTOFILL_PAGE", profileId }, (res) => {
      btnAutofill.disabled = false;
      if (chrome.runtime.lastError) {
        showStatus("⚠ Error interacting with form page.", "warn");
        return;
      }
      
      if (res && res.ok) {
        if (res.filled > 0) {
          showStatus(`✓ Autofilled ${res.filled} form fields!`, "ok");
        } else {
          showStatus("⚠ No matching form inputs detected on page.", "warn");
        }
      } else {
        const errMsg = (res && res.error) ? `: ${res.error}` : "";
        showStatus(`⚠ Autofill action failed${errMsg}`, "warn");
      }
    });
  });

  // ─── Clear Form Trigger ─────────────────────────────────────────────────────
  btnClear.addEventListener("click", () => {
    chrome.runtime.sendMessage({ action: "CLEAR_FORM" }, (res) => {
      if (chrome.runtime.lastError) {
        showStatus("⚠ Error clearing form.", "warn");
        return;
      }
      if (res && res.ok) {
        showStatus("✓ Form cleared successfully.", "ok");
      }
    });
  });

  // ─── Navigation Triggers ────────────────────────────────────────────────────
  [btnOpenOptions, btnManage].forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      chrome.runtime.openOptionsPage();
    });
  });

  btnNewProfile.addEventListener("click", (e) => {
    e.preventDefault();
    chrome.storage.local.set({ optionsAction: "new_profile" }, () => {
      chrome.runtime.openOptionsPage();
    });
  });

  // Status indicator message toast
  function showStatus(msg, type = "ok") {
    statusMsg.textContent = msg;
    statusMsg.className = `status-msg status-${type}`;
    statusMsg.classList.remove("hidden");
    
    clearTimeout(statusMsg._timer);
    statusMsg._timer = setTimeout(() => {
      statusMsg.classList.add("hidden");
    }, 4000);
  }

  // Load state on startup
  initPopup();
});
